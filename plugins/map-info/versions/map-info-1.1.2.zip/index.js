"use strict";
(() => {
  // @tmcontrolpanel/plugin-sdk/src/index.ts
  function definePlugin(definition) {
    const register = globalThis.__tmcpRegister;
    if (typeof register === "function") register(definition);
    return definition;
  }

  // plugins/map-info/src/index.ts
  var UNKNOWN = { name: "-", author: "-" };
  function resetTrailingWhite(name) {
    let last = null;
    for (let i = 0; i < name.length; i++) {
      if (name[i] !== "$") continue;
      const next = name[i + 1] ?? "";
      if (next === "$") {
        i++;
        continue;
      }
      const color = /^[0-9a-f]{3}/i.exec(name.slice(i + 1, i + 4));
      if (color) {
        last = { index: i, code: color[0] };
        i += 3;
      } else if (/[gz>]/i.test(next)) {
        last = { index: i, code: next };
        i++;
      }
    }
    if (!last || last.code.toLowerCase() !== "fff") return name;
    return `${name.slice(0, last.index)}$g${name.slice(last.index + 4)}`;
  }
  var MapInfoPlugin = class {
    constructor(ctx) {
      this.ctx = ctx;
      this.widget = ctx.ui.widget({
        id: "map-info-widget",
        template: "widgets/map-info/map-info",
        position: { x: 100, y: 85 },
        hideWhileDriving: true
      });
      ctx.on("beginMap", () => this.refresh());
    }
    widget;
    async start() {
      this.widget.display();
      await this.refresh();
    }
    async refresh() {
      const info = await this.resolve();
      this.widget.setData({ mapJson: JSON.stringify(info) });
      this.widget.update();
    }
    async resolve() {
      const map = await this.ctx.gbx.call("GetCurrentMapInfo");
      if (!map) return UNKNOWN;
      if (map.Name && map.AuthorNickname) {
        return { name: resetTrailingWhite(map.Name), author: map.AuthorNickname };
      }
      if (!map.UId) return UNKNOWN;
      const record = await this.ctx.maps.findByUid(map.UId);
      return record ? {
        name: resetTrailingWhite(record.name),
        author: record.authorNickname || "-"
      } : UNKNOWN;
    }
  };
  var index_default = definePlugin({
    create: (ctx) => new MapInfoPlugin(ctx)
  });
})();
