"use strict";
(() => {
  // maniatsx/dist/client/contract.js
  var CLIENT = /* @__PURE__ */ Symbol.for("maniatsx.client");

  // maniatsx/dist/maniascript/client-only.js
  function clientOnly(name) {
    return new Proxy(() => {
    }, {
      get(_target, property) {
        if (property === Symbol.toPrimitive)
          return () => `[client-only ${name}]`;
        if (typeof property === "symbol" || property === "then")
          return void 0;
        throw new Error(`${name}.${property} is client-only: use it inside maniatsx client code`);
      },
      apply() {
        throw new Error(`${name} is client-only: use it inside maniatsx client code`);
      }
    });
  }

  // maniatsx/dist/client/authoring.js
  var ml = clientOnly("ml");
  function notCompiled(api) {
    throw new Error(`${api} was not compiled: add the maniatsx build transform (Bun plugin or \`maniatsx compile\`)`);
  }
  function action(name) {
    if (!/^[\w.:-]+$/.test(name))
      throw new Error(`action(): invalid name ${JSON.stringify(name)}`);
    return {
      $$typeof: CLIENT,
      kind: "action",
      name,
      trigger: () => notCompiled(`action("${name}").trigger`)
    };
  }

  // maniatsx/dist/vnode.js
  var VNODE = /* @__PURE__ */ Symbol.for("maniatsx.vnode");
  var Fragment = /* @__PURE__ */ Symbol.for("maniatsx.fragment");
  var MS_CODE = /* @__PURE__ */ Symbol.for("maniatsx.ms");
  var RAW_XML = /* @__PURE__ */ Symbol.for("maniatsx.raw");

  // maniatsx/dist/ms.js
  function code(text) {
    return Object.freeze({ $$typeof: MS_CODE, code: text });
  }
  function isMsCode(value) {
    return typeof value === "object" && value !== null && value.$$typeof === MS_CODE;
  }
  function decimal(n) {
    const s = String(n);
    const m = /^(-?)(\d)(?:\.(\d+))?e([+-]\d+)$/.exec(s);
    if (!m)
      return s;
    const digits = m[2] + (m[3] ?? "");
    const point = 1 + Number(m[4]);
    let body;
    if (point <= 0)
      body = "0." + "0".repeat(-point) + digits;
    else if (point >= digits.length)
      body = digits + "0".repeat(point - digits.length);
    else
      body = digits.slice(0, point) + "." + digits.slice(point);
    return m[1] + body;
  }
  function finite(n, where2) {
    if (typeof n !== "number")
      throw new TypeError(`${where2} expects a number, got ${typeof n}`);
    if (!Number.isFinite(n))
      throw new RangeError(`${where2} expects a finite number, got ${n}`);
    return n;
  }
  function realText(n, where2) {
    const s = decimal(finite(n, where2));
    return s.includes(".") ? s : s + ".";
  }
  function intText(n, where2) {
    if (!Number.isInteger(finite(n, where2)))
      throw new RangeError(`${where2} expects an integer, got ${n}`);
    if (!Number.isSafeInteger(n))
      throw new RangeError(`${where2} is outside the safe Integer range: ${n}`);
    return decimal(n);
  }
  function stringText(s) {
    const escaped = s.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\t/g, "\\t").replace(/-(?=-)/g, '-" ^ "');
    return `"${escaped}"`;
  }
  function kindOf(value) {
    if (isMsCode(value))
      return "code";
    if (Array.isArray(value))
      return "array";
    return typeof value;
  }
  function literal(value, where2) {
    if (typeof value === "number") {
      return Number.isInteger(finite(value, where2)) ? intText(value, where2) : decimal(value);
    }
    if (typeof value === "string")
      return stringText(value);
    if (typeof value === "boolean")
      return value ? "True" : "False";
    if (isMsCode(value))
      return value.code;
    if (Array.isArray(value)) {
      if (value.length === 0)
        throw new TypeError(`${where2} is an empty array; ManiaScript needs a typed literal`);
      const first = kindOf(value[0]);
      const items = value.map((item, i) => {
        if (kindOf(item) !== first) {
          throw new TypeError(`${where2} mixes ${first} and ${kindOf(item)} items (item ${i})`);
        }
        return literal(item, `${where2}[${i}]`);
      });
      return `[${items.join(", ")}]`;
    }
    const what = value === null ? "null" : typeof value;
    throw new TypeError(`${where2} cannot be turned into ManiaScript: got ${what}`);
  }
  function dedentParts(parts) {
    if (!parts.some((p) => p.includes("\n")))
      return [...parts];
    let min = Infinity;
    parts.forEach((part, k) => {
      const lines = part.split("\n");
      lines.forEach((line, j) => {
        if (j === 0 && k > 0)
          return;
        const lastOfOpen = j === lines.length - 1 && k < parts.length - 1;
        if (line.trim() === "" && !lastOfOpen)
          return;
        min = Math.min(min, line.length - line.trimStart().length);
      });
    });
    if (min === Infinity)
      min = 0;
    const out = parts.map((part, k) => part.split("\n").map((line, j) => j === 0 && k > 0 ? line : line.slice(Math.min(min, line.length - line.trimStart().length))).join("\n"));
    out[0] = out[0].replace(/^([ \t]*\n)+/, "");
    const last = out.length - 1;
    out[last] = out[last].replace(/(\n[ \t]*)+$/, "");
    return out;
  }
  function dedent(text) {
    return dedentParts([text.replace(/\r\n?/g, "\n")])[0];
  }
  function tag(strings, ...values) {
    const parts = dedentParts(strings.raw);
    let text = parts[0];
    values.forEach((value, i) => {
      text += literal(value, `ms\`\` interpolation ${i}`) + parts[i + 1];
    });
    return code(text);
  }
  var ms = Object.assign(tag, {
    real: (n) => code(realText(n, "ms.real()")),
    int: (n) => code(intText(n, "ms.int()")),
    vec2: (x, y) => code(`<${realText(x, "ms.vec2() x")}, ${realText(y, "ms.vec2() y")}>`),
    raw(text) {
      if (typeof text !== "string")
        throw new TypeError("ms.raw() expects a string");
      return code(text);
    }
  });

  // maniatsx/dist/context.js
  var providers = /* @__PURE__ */ new WeakMap();
  var contextRuntime = { stack: null };
  function createContext(defaultValue) {
    const id = /* @__PURE__ */ Symbol("maniatsx.context");
    const Provider = ({ children }) => children;
    const ctx = { id, defaultValue, Provider };
    providers.set(Provider, ctx);
    return ctx;
  }
  function useContext(ctx) {
    const stack = contextRuntime.stack;
    if (!stack)
      throw new Error("useContext() can only be called while rendering");
    for (let i = stack.length - 1; i >= 0; i--) {
      if (stack[i].id === ctx.id)
        return stack[i].value;
    }
    return ctx.defaultValue;
  }

  // maniatsx/dist/serialize.js
  function formatNumber(n) {
    if (!Number.isFinite(n))
      throw new RangeError(`Cannot serialise non-finite number ${n}`);
    if (Math.abs(n) >= 1e21)
      return BigInt(n).toString();
    let s = n.toFixed(4);
    if (s.includes("."))
      s = s.replace(/0+$/, "").replace(/\.$/, "");
    return s === "-0" ? "0" : s;
  }
  var ATTR_ESCAPES = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&apos;",
    "\n": "&#10;",
    "\r": "&#13;",
    "	": "&#9;"
  };
  function escapeAttribute(s) {
    return s.replace(/[&<>"'\n\r\t]/g, (c) => ATTR_ESCAPES[c]);
  }
  function escapeText(s) {
    return s.replace(/[&<>]/g, (c) => ATTR_ESCAPES[c]);
  }
  function num(n, element, name) {
    if (!Number.isFinite(n)) {
      throw new RangeError(`<${element}> attribute "${name}": non-finite number ${n}`);
    }
    return formatNumber(n);
  }
  function serializeValue(element, name, value) {
    if (value === null || value === void 0)
      return null;
    switch (typeof value) {
      case "string":
        return value;
      case "number":
        return num(value, element, name);
      case "boolean":
        return value ? "1" : "0";
    }
    if (Array.isArray(value)) {
      if (name === "class") {
        const parts = [];
        for (const part of value) {
          if (part === null || part === void 0 || part === false)
            continue;
          if (typeof part !== "string") {
            throw new TypeError(`<${element}> attribute "class": array items must be strings`);
          }
          if (part !== "")
            parts.push(part);
        }
        return parts.length > 0 ? parts.join(" ") : null;
      }
      if (value.length > 0 && value.every((v) => typeof v === "number")) {
        return value.map((v) => num(v, element, name)).join(" ");
      }
    }
    throw new TypeError(`<${element}> attribute "${name}": unsupported value of type ${describeType(value)}`);
  }
  function describeType(value) {
    if (Array.isArray(value))
      return "array";
    return typeof value;
  }

  // maniatsx/dist/render.js
  var CLIENT_HANDLE = /* @__PURE__ */ Symbol.for("maniatsx.client");
  var MANIALINK_SCOPE = /* @__PURE__ */ Symbol.for("maniatsx.manialink");
  function isClientHandle(value) {
    return typeof value === "object" && value !== null && value.$$typeof === CLIENT_HANDLE;
  }
  var NAME = /^[A-Za-z_][\w.:-]*$/;
  var STYLE_TEXT = /* @__PURE__ */ new Set(["style", "stylesheet"]);
  var TIMEOUT_MAX = 2147483647;
  var current = null;
  function render(node, options = {}) {
    const st = {
      out: [],
      pretty: options.pretty ?? false,
      depth: 0,
      element: null,
      contexts: (options.contexts ?? []).map(([ctx, value]) => ({ id: ctx.id, value })),
      scopes: [],
      ids: /* @__PURE__ */ new Set(),
      warn: options.onWarning ?? ((m) => console.warn(m))
    };
    const prev = current;
    const prevStack = contextRuntime.stack;
    current = st;
    contextRuntime.stack = st.contexts;
    try {
      walk(node, st);
    } finally {
      current = prev;
      contextRuntime.stack = prevStack;
    }
    let xml = st.out.join("");
    if (st.pretty && xml.endsWith("\n"))
      xml = xml.slice(0, -1);
    if (options.warnBytes !== void 0 && xml.length * 3 > options.warnBytes) {
      const bytes = new TextEncoder().encode(xml).length;
      if (bytes > options.warnBytes) {
        st.warn(`Output is ${bytes} bytes, over the warnBytes limit of ${options.warnBytes}`);
      }
    }
    return xml;
  }
  function renderChildren(node, scope3) {
    const st = requireState("renderChildren()");
    const saved = {
      out: st.out,
      ids: st.ids,
      depth: st.depth,
      element: st.element,
      contexts: st.contexts.length,
      scopes: st.scopes.length
    };
    st.out = [];
    if (scope3) {
      st.scopes.push(scope3);
      st.ids = /* @__PURE__ */ new Set();
    }
    try {
      walk(node, st);
      return st.out.join("");
    } finally {
      st.out = saved.out;
      st.ids = saved.ids;
      st.depth = saved.depth;
      st.element = saved.element;
      st.contexts.length = saved.contexts;
      st.scopes.length = saved.scopes;
    }
  }
  function useRenderScope(key) {
    const st = requireState("useRenderScope()");
    for (let i = st.scopes.length - 1; i >= 0; i--) {
      if (st.scopes[i].key === key)
        return st.scopes[i].value;
    }
    return void 0;
  }
  function reportRawScript(st) {
    for (let i = st.scopes.length - 1; i >= 0; i--) {
      const value = st.scopes[i].value;
      if (typeof value?.onRawScript === "function") {
        value.onRawScript();
        return;
      }
    }
  }
  function requireState(fn) {
    if (!current)
      throw new Error(`${fn} can only be called while rendering`);
    return current;
  }
  function describe(node) {
    if (typeof node === "object" && node !== null && node.$$typeof === VNODE) {
      const type = node.type;
      if (typeof type === "string")
        return `<${type}>`;
      if (typeof type === "function")
        return `component ${type.name || "(anonymous)"}`;
      return "<Fragment>";
    }
    return typeof node;
  }
  function where(st) {
    return st.element ? `inside <${st.element}>` : "at the top level";
  }
  function push(st, text) {
    if (text !== "")
      st.out.push(text);
  }
  function pushText(st, text) {
    if (st.pretty)
      push(st, "  ".repeat(st.depth) + text + "\n");
    else
      push(st, text);
  }
  function walk(node, st) {
    if (node === null || node === void 0 || typeof node === "boolean")
      return;
    if (typeof node === "string" || typeof node === "number") {
      if (typeof node === "number" && st.element === "timeout") {
        if (!Number.isInteger(node) || node < 0 || node > TIMEOUT_MAX) {
          throw new Error(`<timeout> must contain an integer from 0 to ${TIMEOUT_MAX}, got ${node}`);
        }
        pushText(st, String(node));
        return;
      }
      const text = typeof node === "number" ? formatNumber(node) : node;
      if (st.element !== null && STYLE_TEXT.has(st.element)) {
        pushText(st, escapeText(text));
        return;
      }
      const preview = JSON.stringify(text.length > 30 ? text.slice(0, 30) + "..." : text);
      throw new Error(`Text ${preview} is not allowed ${where(st)}; only <script>, <style> and <stylesheet> take text`);
    }
    if (Array.isArray(node)) {
      for (const child of node)
        walk(child, st);
      return;
    }
    const obj = node;
    if (obj.$$typeof === RAW_XML) {
      const xml = obj.xml;
      push(st, st.pretty && xml !== "" && !xml.endsWith("\n") ? xml + "\n" : xml);
      return;
    }
    if (obj.$$typeof === MS_CODE) {
      throw new Error(`ManiaScript code is only allowed inside <script>, found ${where(st)}`);
    }
    if (obj.$$typeof !== VNODE) {
      throw new Error(`Cannot render a value of type ${typeof node} ${where(st)}`);
    }
    const vnode = node;
    const { type, props } = vnode;
    if (type === Fragment) {
      walk(props.children, st);
    } else if (typeof type === "function") {
      const ctx = providers.get(type);
      if (ctx) {
        st.contexts.push({ id: ctx.id, value: props.value });
        try {
          walk(props.children, st);
        } finally {
          st.contexts.pop();
        }
      } else {
        walk(type(props), st);
      }
    } else if (typeof type === "string") {
      writeElement(type, props, st);
    } else {
      throw new Error(`Invalid element type ${String(type)} ${where(st)}`);
    }
  }
  function writeAttributes(tag2, props, st) {
    let attrs = "";
    for (const name of Object.keys(props)) {
      if (name === "children" || name === "key")
        continue;
      const value = props[name];
      if (Array.isArray(value) && value.length === 0 && name !== "class") {
        st.warn(`<${tag2}> attribute "${name}" is an empty array and was omitted`);
        continue;
      }
      const text = serializeValue(tag2, name, value);
      if (text === null)
        continue;
      if (!NAME.test(name))
        throw new Error(`<${tag2}>: invalid attribute name "${name}"`);
      if (name === "id") {
        if (st.ids.has(text))
          st.warn(`Duplicate id "${text}" on <${tag2}>`);
        else
          st.ids.add(text);
      }
      attrs += ` ${name}="${escapeAttribute(text)}"`;
    }
    return attrs;
  }
  function collectScriptText(node, out) {
    if (node === null || node === void 0 || typeof node === "boolean")
      return;
    if (typeof node === "string")
      out.push(node);
    else if (typeof node === "number")
      out.push(formatNumber(node));
    else if (Array.isArray(node))
      for (const child of node)
        collectScriptText(child, out);
    else if (node.$$typeof === MS_CODE) {
      out.push(node.code);
    } else {
      throw new Error(`<script> only takes text or ManiaScript code, found ${describe(node)}`);
    }
  }
  function writeElement(tag2, props, st) {
    if (!NAME.test(tag2))
      throw new Error(`Invalid element name "${tag2}"`);
    if (Object.values(props).some(isClientHandle)) {
      const scope3 = useRenderScope(MANIALINK_SCOPE);
      if (!scope3)
        throw new Error(`<${tag2}> client handles can only be used inside <Manialink>`);
      const client3 = scope3.client;
      if (!client3)
        throw new Error(`<${tag2}> client handles need the runtime: import "maniatsx/client"`);
      props = client3.element(tag2, props);
    }
    for (const name of ["onClick", "onRightClick", "onMouseOver", "onMouseOut", "onSubmit"]) {
      if (props[name] != null)
        throw new Error(`<${tag2}> attribute "${name}" requires a ClientHandler`);
    }
    const indent = st.pretty ? "  ".repeat(st.depth) : "";
    const nl = st.pretty ? "\n" : "";
    const open = `<${tag2}${writeAttributes(tag2, props, st)}`;
    if (tag2 === "script") {
      reportRawScript(st);
      const parts = [];
      collectScriptText(props.children, parts);
      const code2 = parts.join("");
      const dash = code2.split("\n").findIndex((line) => line.includes("--"));
      if (dash !== -1) {
        throw new Error(`<script> content must not contain "--" (line ${dash + 1}: ${JSON.stringify(code2.split("\n")[dash].trim())})`);
      }
      push(st, code2 === "" ? `${indent}${open} />${nl}` : `${indent}${open}><!--
${code2}
--></script>${nl}`);
      return;
    }
    const slot2 = st.out.length;
    st.out.push("");
    const prevElement = st.element;
    st.element = tag2;
    st.depth++;
    try {
      walk(props.children, st);
    } finally {
      st.depth--;
      st.element = prevElement;
    }
    if (st.out.length === slot2 + 1) {
      st.out[slot2] = `${indent}${open} />${nl}`;
    } else {
      st.out[slot2] = `${indent}${open}>${nl}`;
      st.out.push(`${indent}</${tag2}>${nl}`);
    }
  }

  // maniatsx/dist/raw.js
  function raw(xml) {
    if (typeof xml !== "string")
      throw new TypeError("raw() expects a string");
    return Object.freeze({ $$typeof: RAW_XML, xml });
  }

  // maniatsx/dist/jsx-runtime.js
  function jsx(type, props, key) {
    return Object.freeze({ $$typeof: VNODE, type, props, key: key ?? null });
  }
  var jsxs = jsx;

  // maniatsx/dist/manialink.js
  var PROLOG = '<?xml version="1.0" encoding="utf-8" standalone="yes"?>';
  var SCOPE_KEY = /* @__PURE__ */ Symbol.for("maniatsx.manialink");
  var LIB = /^[\w./-]+$/;
  var ALIAS = /^[A-Za-z_]\w*$/;
  var DIRTY_MARK = "\0dirty\0";
  var clientFactory;
  function installClientExtension(factory) {
    clientFactory = factory;
  }
  function createScope() {
    const scope3 = {
      client: void 0,
      includes: /* @__PURE__ */ new Map(),
      libs: /* @__PURE__ */ new Set(),
      dirtyWrites: false,
      slots: {
        structs: [],
        globals: [],
        functions: [],
        refInit: [],
        stateInit: [],
        main: [],
        events: [],
        sync: [],
        loop: []
      },
      rawScript: false,
      onRawScript() {
        this.rawScript = true;
      }
    };
    const host = {
      part(slot2, code2, id) {
        const parts = scope3.slots[slot2];
        if (id !== void 0 && parts.some((part) => part.id === id))
          return;
        parts.push({ id, code: code2 });
      },
      lib(lib) {
        if (!LIB.test(lib))
          throw new Error(`invalid ManiaScript lib ${JSON.stringify(lib)}`);
        scope3.libs.add(lib);
        return `\0lib:${lib}\0`;
      },
      dirty: () => DIRTY_MARK,
      dirtyWrites(on) {
        scope3.dirtyWrites = on;
      }
    };
    scope3.client = clientFactory?.(host);
    return scope3;
  }
  function requireScope(name) {
    const scope3 = useRenderScope(SCOPE_KEY);
    if (!scope3)
      throw new Error(`<${name}> can only be used inside <Manialink>`);
    return scope3;
  }
  function flatten(src, name, out) {
    if (src === null || src === void 0 || src === false)
      return;
    if (typeof src === "string")
      out.push(dedent(src));
    else if (Array.isArray(src))
      for (const item of src)
        flatten(item, name, out);
    else if (src.$$typeof === MS_CODE)
      out.push(src.code);
    else
      throw new Error(`<${name}> children must be strings or ms code, got ${typeof src}`);
  }
  function trimBlankEdges(text) {
    return text.replace(/^([ \t]*\n)+/, "").replace(/(\n[ \t]*)+$/, "");
  }
  function makePart(slot2, name) {
    return function ScriptPart(props) {
      const scope3 = requireScope(name);
      if (props.id !== void 0 && typeof props.id !== "string") {
        throw new Error(`<${name}> id must be a string`);
      }
      const pieces = [];
      flatten(props.children, name, pieces);
      const code2 = trimBlankEdges(pieces.join("\n"));
      if (code2.trim() === "")
        return null;
      const parts = scope3.slots[slot2];
      if (props.id !== void 0 && parts.some((p) => p.id === props.id))
        return null;
      parts.push({ id: props.id, code: code2 });
      return null;
    };
  }
  function Include(props) {
    addInclude(requireScope("Script.Include"), props.lib, props.as);
    return null;
  }
  function addInclude(scope3, lib, alias) {
    if (typeof lib !== "string" || !LIB.test(lib)) {
      throw new Error(`<Script.Include> invalid lib ${JSON.stringify(lib)}`);
    }
    if (typeof alias !== "string" || !ALIAS.test(alias)) {
      throw new Error(`<Script.Include lib="${lib}"> invalid alias ${JSON.stringify(alias)}`);
    }
    const existing = scope3.includes.get(lib);
    if (existing !== void 0) {
      if (existing !== alias) {
        throw new Error(`<Script.Include> lib "${lib}" is already included as "${existing}", not "${alias}"`);
      }
      return;
    }
    for (const [otherLib, otherAlias] of scope3.includes) {
      if (otherAlias === alias) {
        throw new Error(`<Script.Include> alias "${alias}" is already used for lib "${otherLib}", not "${lib}"`);
      }
    }
    scope3.includes.set(lib, alias);
  }
  var Script = {
    Include,
    Globals: makePart("globals", "Script.Globals"),
    Functions: makePart("functions", "Script.Functions"),
    Main: makePart("main", "Script.Main"),
    Events: makePart("events", "Script.Events"),
    Loop: makePart("loop", "Script.Loop")
  };
  function indentBlock(parts, spaces) {
    const pad = " ".repeat(spaces);
    return parts.flatMap((p) => p.code.split("\n").map((line) => line.trim() === "" ? "" : pad + line));
  }
  function assemble(scope3, manialinkId) {
    for (const lib of scope3.libs)
      if (!scope3.includes.has(lib))
        addInclude(scope3, lib, lib);
    const { structs, globals, functions, refInit, stateInit, main, events, sync, loop } = scope3.slots;
    const count = scope3.includes.size + structs.length + globals.length + functions.length + refInit.length + stateInit.length + main.length + events.length + sync.length + loop.length;
    if (count === 0)
      return null;
    if (scope3.rawScript) {
      throw new Error(`<Manialink id="${manialinkId}"> mixes Script.* parts with a raw <script>; a page has one script`);
    }
    const lines = [];
    for (const [lib, alias] of scope3.includes)
      lines.push(`#Include "${lib}" as ${alias}`);
    lines.push(...indentBlock(structs, 0), ...indentBlock(globals, 0), ...indentBlock(functions, 0));
    if (functions.length === 0 && (globals.length > 0 || structs.length > 0))
      lines.push("Void Mtx_Noop() {}");
    lines.push("main() {", ...indentBlock(refInit, 2), ...indentBlock(stateInit, 2), ...indentBlock(main, 2), "  while (True) {", "    yield;");
    if (events.length > 0) {
      lines.push("    foreach (Event in PendingEvents) {", ...indentBlock(events, 6), "    }");
    }
    lines.push(...indentBlock(sync, 4), ...indentBlock(loop, 4), "  }", "}");
    const kept = scope3.dirtyWrites ? lines : lines.filter((line) => line.trim() !== DIRTY_MARK);
    return kept.join("\n").replaceAll(DIRTY_MARK, scope3.dirtyWrites ? "Mtx_Dirty = True;" : "").replace(/\0lib:(\w+)\0/g, (_, lib) => scope3.includes.get(lib));
  }
  function ManialinkBody(props) {
    const scope3 = createScope();
    const xml = renderChildren(props.children, { key: SCOPE_KEY, value: scope3 });
    scope3.client?.finish();
    const script = assemble(scope3, props.manialinkId);
    return [raw(xml), script === null ? null : jsx("script", { children: ms.raw(script) })];
  }
  function Manialink(props) {
    if (useRenderScope(SCOPE_KEY))
      throw new Error("<Manialink> cannot be nested inside another <Manialink>");
    if (typeof props.id !== "string" || props.id === "")
      throw new Error("<Manialink> requires an id");
    const element = jsx("manialink", {
      id: props.id,
      name: props.name,
      version: 3,
      layer: props.layer,
      children: jsx(ManialinkBody, { manialinkId: props.id, children: props.children })
    });
    return [props.prolog === false ? null : raw(PROLOG), element];
  }

  // maniatsx/dist/client/runtime.js
  var CLIENT_SCOPE = /* @__PURE__ */ Symbol.for("maniatsx.manialink");
  var literalText = (value) => ms`${value}`.code;
  function typeName(type) {
    if (typeof type === "string")
      return type;
    if ("array" in type)
      return `${typeName(type.array)}[]`;
    if ("record" in type)
      return `${typeName(type.record.value)}[${type.record.key}]`;
    return type.struct;
  }
  function emptyCollection(type, inner) {
    if (inner)
      throw new TypeError(`An empty ${typeName(type)} cannot be written inside an array or record literal`);
    return typeName(type);
  }
  var isEmptyCollection = (value, type) => typeof type === "object" && ("array" in type && Array.isArray(value) && value.length === 0 || "record" in type && !!value && typeof value === "object" && !Array.isArray(value) && Object.keys(value).length === 0);
  function literal2(value, type, inner = false) {
    if (typeof type !== "string") {
      if ("struct" in type) {
        if (!type.fields)
          throw new Error("struct values are not supported yet");
        if (!value || typeof value !== "object" || Array.isArray(value))
          throw new TypeError(`Expected ${type.struct} value`);
        const fields = type.fields.map((f) => [f, value[f.name]]).filter(([f, v]) => !isEmptyCollection(v, f.type)).map(([f, v]) => `${f.name} = ${literal2(v, f.type)}`);
        return fields.length ? `${type.struct} { ${fields.join(", ")} }` : `${type.struct} {}`;
      }
      if ("array" in type) {
        if (!Array.isArray(value))
          throw new TypeError("Expected an array");
        if (!value.length)
          return emptyCollection(type, inner);
        return `[${value.map((v) => literal2(v, type.array, true)).join(", ")}]`;
      }
      if (!value || typeof value !== "object" || Array.isArray(value))
        throw new TypeError("Expected a record");
      if (!Object.keys(value).length)
        return emptyCollection(type, inner);
      return `[${Object.entries(value).map(([k, v]) => `${literal2(type.record.key === "Integer" ? Number(k) : k, type.record.key)} => ${literal2(v, type.record.value, true)}`).join(", ")}]`;
    }
    switch (type) {
      case "Integer":
        return ms.int(value).code;
      case "Real":
        return ms.real(value).code;
      case "Boolean":
        if (typeof value === "boolean")
          return value ? "True" : "False";
        break;
      case "Text":
        if (typeof value === "string")
          return literalText(value);
        break;
      case "Ident":
        throw new TypeError("Ident values are not supported yet");
      case "Vec2":
      case "Vec3":
      case "Int2":
      case "Int3": {
        if (!value || typeof value !== "object")
          break;
        const v = value;
        const component = type.startsWith("Int") ? ms.int : ms.real;
        return `<${["X", "Y", ...type.endsWith("3") ? ["Z"] : []].map((k) => component(v[k]).code).join(", ")}>`;
      }
    }
    throw new TypeError(`Expected ${type} value`);
  }
  function hash(text) {
    let h = 2166136261;
    for (let i = 0; i < text.length; i++)
      h = Math.imul(h ^ text.charCodeAt(i), 16777619);
    return (h >>> 0).toString(16).padStart(8, "0");
  }
  var SHARED_KEY = /^[A-Za-z]\w*$/;
  var SHARED_SUFFIX = /_(V|Seen)$/;
  function checkSharedKey(key, site) {
    if (!SHARED_KEY.test(key) || SHARED_SUFFIX.test(key))
      throw new Error(`client.shared at ${site}: invalid key ${JSON.stringify(key)}; use letters, digits and "_", starting with a letter and not ending in _V or _Seen`);
  }
  var DIRTY_WRITE = /\bMtx_Dirty = True;/g;
  var ClientScope = class {
    host;
    states = /* @__PURE__ */ new Map();
    persistedNames = /* @__PURE__ */ new Set();
    stateCount = 0;
    // Persisted states read by the code being filled: each function body must re-bind them
    used = [];
    shareds = /* @__PURE__ */ new Map();
    refs = /* @__PURE__ */ new Map();
    attached = /* @__PURE__ */ new Map();
    functions = /* @__PURE__ */ new Set();
    handlers = /* @__PURE__ */ new Map();
    eventHandlers = /* @__PURE__ */ new Map();
    elementCount = 0;
    controlCount = 0;
    dirty = false;
    constructor(host) {
      this.host = host;
    }
    // Bindings are the only readers of the flag, so only they turn it on
    ensureDirty() {
      if (!this.dirty) {
        this.dirty = true;
        this.host.part("globals", "declare Boolean Mtx_Dirty;");
      }
    }
    // Fills code that becomes a function body and returns the declarations that re-bind its persisted states
    body(code2, indent = "") {
      const used = /* @__PURE__ */ new Set();
      this.used.push(used);
      try {
        const text = this.fill(code2);
        const declares = [...used].map((s) => s.kind === "shared" ? `${indent}declare ${typeName(s.type)} ${this.shareds.get(s.key).name} for This;
` : `${indent}declare ${typeName(s.type)} ${this.states.get(s)} for Page;
`).join("");
        return { text, declares };
      } finally {
        this.used.pop();
      }
    }
    fill(code2) {
      if (code2.code.length !== code2.holes.length + 1)
        throw new Error(`Invalid compiled code at ${code2.site}`);
      for (const struct of code2.structs)
        this.host.part("structs", struct, struct);
      let result = code2.code[0];
      code2.holes.forEach((hole, i) => {
        let value;
        switch (hole.kind) {
          case "value":
            value = literal2(hole.get(), hole.type);
            break;
          case "state":
            value = this.state(hole.get());
            break;
          case "shared":
            value = this.read(hole.get());
            break;
          case "ref":
            value = this.ref(hole.get());
            break;
          case "action":
            value = literalText(hole.get().name);
            break;
          case "fn":
            value = this.fn(hole.get());
            break;
          case "lib":
            value = this.host.lib(hole.lib);
            break;
        }
        result += value + code2.code[i + 1];
      });
      return result.replace(DIRTY_WRITE, () => this.host.dirty());
    }
    state(state) {
      if (state.persist)
        this.used.at(-1)?.add(state);
      let name = this.states.get(state);
      if (name)
        return name;
      if (state.persist)
        return this.persisted(state);
      name = `Mtx_S${++this.stateCount}`;
      this.states.set(state, name);
      this.host.part("globals", `declare ${typeName(state.type)} ${name};`);
      this.host.part("stateInit", `${name} = ${this.fill(state.initial)};`, `state:${name}`);
      return name;
    }
    sharedInfo(shared) {
      checkSharedKey(shared.key, shared.site);
      let info = this.shareds.get(shared.key);
      if (!info) {
        info = {
          shared,
          name: `Mtx_X_${shared.key}`,
          read: false,
          published: false,
          watchers: []
        };
        this.shareds.set(shared.key, info);
      } else if (typeName(info.shared.type) !== typeName(shared.type))
        throw new Error(`client.shared key "${shared.key}" is declared with two types (${typeName(info.shared.type)} at ${info.shared.site}, ${typeName(shared.type)} at ${shared.site}); a key has one type`);
      return info;
    }
    // Reading code (bindings, handlers, lifecycle, fns); function bodies re-declare it like persisted state
    read(shared) {
      const info = this.sharedInfo(shared);
      info.read = true;
      this.used.at(-1)?.add(shared);
      return info.name;
    }
    watch(shared, code2) {
      const info = this.sharedInfo(shared);
      info.read = true;
      const { text, declares } = this.body(code2);
      const body = declares + text;
      const name = this.handler(body);
      if (!info.watchers.includes(name))
        info.watchers.push(name);
    }
    publish(shared, value) {
      const info = this.sharedInfo(shared);
      info.published = true;
      this.host.part("main", `${info.name} = ${literal2(value, shared.type)};
${info.name}_V += 1;`);
    }
    // Deduped function for a handler or watcher body
    handler(body) {
      let name = this.handlers.get(body);
      if (!name) {
        name = `Mtx_H${this.handlers.size + 1}`;
        this.handlers.set(body, name);
        this.host.part("functions", `Void ${name}() {
${body}
}`);
      }
      return name;
    }
    // Deduped function for an on* handler body; it receives the event
    eventHandler(body) {
      let name = this.eventHandlers.get(body);
      if (!name) {
        name = `Mtx_E${this.eventHandlers.size + 1}`;
        this.eventHandlers.set(body, name);
        this.host.part("functions", `Void ${name}(CMlScriptEvent Event) {
${body}
}`);
      }
      return name;
    }
    // Declarations and version tracking, emitted once the page's bindings are known
    finishShared() {
      for (const info of this.shareds.values()) {
        const type = typeName(info.shared.type);
        const tracked = info.read && (info.watchers.length > 0 || this.dirty);
        for (const struct of info.shared.initial.structs)
          this.host.part("structs", struct, struct);
        this.host.part("stateInit", info.read ? `declare ${type} ${info.name} for This = ${this.fill(info.shared.initial)};` : `declare ${type} ${info.name} for This;`, `shared:${info.name}`);
        if (!tracked && !info.published)
          continue;
        this.host.part("stateInit", `declare Integer ${info.name}_V for This;`);
        if (!tracked)
          continue;
        this.host.part("globals", `declare Integer ${info.name}_Seen;`);
        this.host.part("sync", [
          `if (${info.name}_V != ${info.name}_Seen) {`,
          `  ${info.name}_Seen = ${info.name}_V;`,
          `  ${this.host.dirty()}`,
          ...info.watchers.map((w) => `  ${w}();`),
          "}"
        ].join("\n"));
      }
    }
    // `declare … for Page = init;` in main applies init once; function bodies re-bind it without a value
    persisted(state) {
      const { key, keyPrefix } = state.persist;
      let name;
      if (key !== void 0) {
        if (!/^[A-Za-z]\w*$/.test(key))
          throw new Error(`client.state at ${state.site}: invalid persist key ${JSON.stringify(key)}`);
        name = `Mtx_P_${keyPrefix ? `${keyPrefix}_${key}`.replace(/\W/g, "") : key}`;
        if (this.persistedNames.has(name))
          throw new Error(`client.state at ${state.site}: persist key "${key}" is used twice on this page; keys must be unique`);
      } else {
        const stem = state.site.replace(/:\d+:\d+$/, "").split("/").pop().replace(/\.\w+$/, "");
        const base = `Mtx_P_${keyPrefix ? `${keyPrefix}_`.replace(/\W/g, "") : ""}${stem.replace(/\W/g, "") || "state"}_${hash(state.site)}`;
        name = base;
        for (let n = 2; this.persistedNames.has(name); n++)
          name = `${base}_${n}`;
      }
      this.persistedNames.add(name);
      this.states.set(state, name);
      this.used.push(/* @__PURE__ */ new Set());
      try {
        this.host.part("stateInit", `declare ${typeName(state.type)} ${name} for Page = ${this.fill(state.initial)};`, `state:${name}`);
      } finally {
        this.used.pop();
      }
      return name;
    }
    // Global of a ref used in client code; its init is emitted in finish(), once attachment is known
    ref(ref) {
      let name = this.refs.get(ref);
      if (name)
        return name;
      if (!/^[A-Za-z]\w*$/.test(ref.cls))
        throw new Error(`Invalid control class at ${ref.site}`);
      name = `Mtx_R${this.refs.size + 1}`;
      this.refs.set(ref, name);
      this.host.part("globals", `declare ${ref.cls} ${name};`);
      return name;
    }
    fn(fn) {
      if (!this.functions.has(fn.name)) {
        this.functions.add(fn.name);
        const { text, declares } = this.body(fn.declaration, "  ");
        const open = text.indexOf("{\n") + 2;
        this.host.part("functions", declares && open > 1 ? text.slice(0, open) + declares + text.slice(open) : text, `fn:${fn.name}`);
      }
      return fn.name;
    }
    lifecycle(slot2, code2) {
      this.host.part(slot2, this.fill(code2));
    }
    element(tag2, props) {
      const entries = Object.entries(props).filter((entry) => isClient(entry[1]));
      if (!entries.length)
        return props;
      const out = { ...props };
      const id = out.id === void 0 ? `mtx-${++this.elementCount}` : out.id;
      if (typeof id !== "string" || !id)
        throw new Error(`<${tag2}> client props require a string id`);
      out.id = id;
      const events = {
        onClick: "MouseClick",
        onRightClick: "MouseRightClick",
        onMouseOver: "MouseOver",
        onMouseOut: "MouseOut",
        onSubmit: "EntrySubmit"
      };
      const bindings = {
        label: { text: "Value", hidden: "Visible", pos: "RelativePosition_V3", opacity: "Opacity" },
        quad: {
          hidden: "Visible",
          pos: "RelativePosition_V3",
          opacity: "Opacity",
          image: "ChangeImageUrl",
          bgcolor: "BgColor"
        },
        gauge: { hidden: "Visible", pos: "RelativePosition_V3", ratio: "Ratio" },
        entry: { hidden: "Visible", pos: "RelativePosition_V3", default: "Value" }
      };
      let control;
      for (const [attr, handle] of entries) {
        delete out[attr];
        if (handle.kind === "ref" && attr === "ref") {
          const ref = handle;
          const prior = this.attached.get(ref);
          if (prior)
            throw new Error(`client.ref declared at ${ref.site} is attached to two elements (<${prior.tag} id="${prior.id}"> and <${tag2} id="${id}">); a ref points at one control`);
          this.attached.set(ref, { tag: tag2, id });
        } else if (handle.kind === "handler" && events[attr] && (attr !== "onSubmit" || tag2 === "entry" || tag2 === "textedit")) {
          out.scriptevents = true;
          const { text, declares } = this.body(handle.body);
          const name = this.eventHandler(declares + text);
          this.host.part("events", `if (Event.Type == CMlScriptEvent::Type::${events[attr]} && Event.ControlId == ${literalText(id)}) ${name}(Event);`);
        } else if (handle.kind === "bind" && bindings[tag2]?.[attr]) {
          this.ensureDirty();
          if (!control) {
            control = `Mtx_C${++this.controlCount}`;
            const cls = `CMl${tag2[0].toUpperCase()}${tag2.slice(1)}`;
            this.host.part("main", `declare ${cls} ${control} <=> (Page.GetFirstChild(${literalText(id)}) as ${cls});`);
          }
          const binding = handle;
          let expr = this.fill(binding.expr);
          if (attr === "bgcolor" && binding.type === "Text") {
            expr = `${this.host.lib("ColorLib")}::HexToRgb(${expr})`;
          }
          const property = bindings[tag2][attr];
          const update = property === "ChangeImageUrl" ? `${control}.${property}(${expr});` : `${control}.${property} = ${attr === "hidden" ? `!(${expr})` : expr};`;
          this.host.part("main", update);
          this.host.part("loop", `if (Mtx_Dirty) { ${update} }`);
        } else
          throw new Error(`<${tag2}> attribute "${attr}": unsupported client ${handle.kind}`);
      }
      return out;
    }
    finish() {
      for (const [ref, name] of this.refs) {
        const target = this.attached.get(ref);
        if (!target)
          throw new Error(`client.ref declared at ${ref.site} is used in client code but never attached to an element in this <Manialink>; add ref={...} to one`);
        this.host.part("refInit", `${name} <=> (Page.MainFrame.GetFirstChild(${literalText(target.id)}) as ${ref.cls});`);
      }
      this.finishShared();
      this.host.dirtyWrites(this.dirty);
      if (this.dirty) {
        this.host.part("main", "Mtx_Dirty = True;");
        this.host.part("loop", "Mtx_Dirty = False;");
      }
    }
  };
  function isClient(value) {
    return typeof value === "object" && value !== null && value.$$typeof === CLIENT;
  }
  function scope() {
    const found = useRenderScope(CLIENT_SCOPE)?.client;
    if (!found)
      throw new Error("Client handles can only be used inside <Manialink>");
    return found;
  }
  function Publish(props) {
    if (!isClient(props.to) || props.to.kind !== "shared")
      throw new Error("<Publish> `to` must be a client.shared handle");
    scope().publish(props.to, props.value);
    return null;
  }
  var __mtx = {
    shared: (key, type, initial, site) => ({
      $$typeof: CLIENT,
      kind: "shared",
      key,
      type,
      initial,
      site,
      value: void 0
    }),
    watch: (shared, body) => scope().watch(shared, body),
    ref: (cls, site) => ({ $$typeof: CLIENT, kind: "ref", cls, site, control: void 0 }),
    state: (type, initial, site, options) => ({
      $$typeof: CLIENT,
      kind: "state",
      type,
      initial,
      site,
      ...options?.persist && {
        persist: {
          ...options.key === void 0 ? {} : { key: options.key },
          ...options.keyPrefix && { keyPrefix: options.keyPrefix }
        }
      },
      value: void 0
    }),
    handler: (body) => ({ $$typeof: CLIENT, kind: "handler", body }),
    bind: (type, expr) => ({ $$typeof: CLIENT, kind: "bind", type, expr }),
    fn: (name, declaration) => ({ $$typeof: CLIENT, kind: "fn", name, declaration }),
    onInit: (body) => scope().lifecycle("main", body),
    onFrame: (body) => scope().lifecycle("loop", body)
  };
  installClientExtension((host) => new ClientScope(host));

  // @tmcontrolpanel/plugin-sdk/src/index.ts
  function definePlugin(definition) {
    const register = globalThis.__tmcpRegister;
    if (typeof register === "function") register(definition);
    return definition;
  }

  // @tmcontrolpanel/shared/src/themes/registry.ts
  var DEFAULT_TOKENS = {
    color: {
      surface: "222",
      surfaceAlt: "333",
      content: "DDD",
      contentAlt: "CCC",
      text: "DDD",
      textMuted: "CCC",
      contentText: "222",
      contentTextMuted: "333",
      accent: "DDD"
    },
    font: { body: "GameFontRegular", title: "GameFontSemiBold" },
    opacity: { panel: 0.85 }
  };
  var registry = [
    { id: "default", name: "Default", tokens: DEFAULT_TOKENS }
  ];
  var DEFAULT_PRESET_ID = "default";
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function clone(value) {
    if (Array.isArray(value)) return value.map(clone);
    if (isRecord(value))
      return Object.fromEntries(
        Object.entries(value).map(([key, item]) => [key, clone(item)])
      );
    return value;
  }
  function deepMerge(base, patch) {
    if (Array.isArray(patch)) return clone(patch);
    if (!isRecord(base) || !isRecord(patch)) return clone(patch);
    const result = { ...base };
    for (const [key, value] of Object.entries(patch)) {
      result[key] = key in base ? deepMerge(base[key], value) : clone(value);
    }
    return result;
  }
  function resolveFrom(definitions, id) {
    const byId = new Map(
      definitions.map((definition) => [definition.id, definition])
    );
    const selected = byId.get(id) ?? byId.get(DEFAULT_PRESET_ID);
    const lineage = [];
    let current3 = selected;
    const seen = /* @__PURE__ */ new Set();
    while (current3) {
      if (seen.has(current3.id))
        throw new Error(`Theme preset cycle at "${current3.id}"`);
      seen.add(current3.id);
      lineage.push(current3);
      current3 = current3.extends ? byId.get(current3.extends) : void 0;
    }
    if (lineage.at(-1)?.id !== DEFAULT_PRESET_ID)
      throw new Error(`Theme preset "${id}" must extend "${DEFAULT_PRESET_ID}"`);
    let tokens = clone(DEFAULT_TOKENS);
    const text = {};
    const layout = {};
    for (const definition of lineage.reverse()) {
      tokens = deepMerge(tokens, definition.tokens);
      Object.assign(text, definition.text);
      for (const [key, value] of Object.entries(definition.layout ?? {}))
        layout[key] = { ...layout[key], ...value };
    }
    return {
      id: selected.id,
      name: selected.name,
      chain: lineage.map((item) => item.id).reverse(),
      tokens,
      text,
      layout
    };
  }
  function resolvePreset(id) {
    return resolveFrom(registry, id);
  }

  // maniatsx/dist/theme.js
  var slotContext = createContext(null);
  var namedSlots = /* @__PURE__ */ new Set();
  function cloneMerge(base, patch) {
    if (Array.isArray(patch))
      return patch.map((value) => cloneValue(value));
    if (Array.isArray(base) || !isRecord2(base) || !isRecord2(patch)) {
      return cloneValue(patch);
    }
    const result = { ...base };
    for (const [key, value] of Object.entries(patch)) {
      result[key] = key in base ? cloneMerge(base[key], value) : cloneValue(value);
    }
    return result;
  }
  function cloneValue(value) {
    if (Array.isArray(value))
      return value.map(cloneValue);
    if (isRecord2(value))
      return Object.fromEntries(Object.entries(value).map(([key, child]) => [key, cloneValue(child)]));
    return value;
  }
  function isRecord2(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function freeze(value) {
    if (isRecord2(value) || Array.isArray(value)) {
      for (const child of Object.values(value))
        freeze(child);
      Object.freeze(value);
    }
    return value;
  }
  function mergeKeyed(base, patch) {
    return { ...base, ...patch };
  }
  function mergeLayout(base, patch) {
    const result = { ...base };
    for (const [key, value] of Object.entries(patch ?? {}))
      result[key] = { ...result[key], ...value };
    return result;
  }
  function mergeComponents(parent, child = []) {
    const result = new Map(parent.map((entry) => [entry.slotId, entry]));
    for (const entry of child)
      result.set(entry.slotId, entry);
    return [...result.values()];
  }
  function slot(name, Default, variants = {}) {
    if (namedSlots.has(name))
      throw new Error(`Duplicate theme slot name "${name}"`);
    namedSlots.add(name);
    const slotId = Symbol(name);
    const Slot = Object.assign((props) => {
      const active = useContext(slotContext);
      const custom = active?.components.find((entry) => entry.slotId === slotId);
      if (custom)
        return custom.component({ ...props, Default });
      const variant = active?.chain.map((id) => variants[id]).find((value) => value !== void 0);
      return (variant ?? Default)(props);
    }, { slotName: name, slotId, Default, variants });
    return Slot;
  }
  function createThemeKit(definition) {
    const themes = /* @__PURE__ */ new Map();
    const make = (def, parent) => {
      if (themes.has(def.id))
        throw new Error(`Duplicate theme id "${def.id}"`);
      if (def.extends && themes.get(def.extends.id) !== def.extends) {
        throw new Error(`Theme "${def.id}" extends a theme from another kit`);
      }
      const actualParent = def.extends ?? parent;
      const theme = freeze({
        id: def.id,
        name: def.name,
        chain: Object.freeze([def.id, ...actualParent?.chain ?? []]),
        tokens: cloneMerge(actualParent?.tokens ?? def.tokens, def.tokens ?? {}),
        text: mergeKeyed(actualParent?.text ?? {}, def.text),
        layout: mergeLayout(actualParent?.layout ?? {}, def.layout),
        components: mergeComponents(actualParent?.components ?? [], def.components)
      });
      themes.set(def.id, theme);
      return theme;
    };
    const base = make(definition);
    const themeContext = createContext(base);
    const wrappedProvider = ({ theme, children }) => {
      const isData = !("components" in theme);
      if (isData && (typeof theme.id !== "string" || !Array.isArray(theme.chain) || theme.chain[0] !== theme.id))
        throw new Error("Invalid ThemeData: expected a string id and a chain starting with that id.");
      const components = isData ? [] : theme.components;
      return jsx(themeContext.Provider, {
        value: theme,
        children: jsx(slotContext.Provider, {
          value: { chain: theme.chain, components, layout: theme.layout },
          children
        })
      });
    };
    return {
      base,
      toData: (theme) => structuredClone({
        id: theme.id,
        name: theme.name,
        chain: theme.chain,
        tokens: theme.tokens,
        text: theme.text,
        layout: theme.layout
      }),
      defineTheme: (def) => make(def, def.extends ?? base),
      themes: () => Object.freeze([...themes.values()]),
      useTokens: () => useContext(themeContext).tokens,
      useText: (key, fallback = key) => useContext(themeContext).text[key] ?? fallback,
      useTheme: () => useContext(themeContext),
      ThemeProvider: wrappedProvider
    };
  }

  // @tmcontrolpanel/plugin-sdk/src/ui/theme.ts
  var defaultTheme = resolvePreset("default");
  var kit = createThemeKit({
    id: defaultTheme.id,
    name: defaultTheme.name,
    tokens: defaultTheme.tokens,
    text: defaultTheme.text
  });
  var toKitTheme = (theme) => theme;

  // @tmcontrolpanel/plugin-sdk/src/render.tsx
  function renderComponent(Component, props, theme) {
    return render(
      /* @__PURE__ */ jsx(kit.ThemeProvider, { theme: toKitTheme(theme), children: /* @__PURE__ */ jsx(Component, { ...props }) })
    );
  }

  // @tmcontrolpanel/plugin-sdk/src/ui/install.ts
  var scope2 = globalThis;
  if (typeof scope2.__tmcpRegister === "function" && !scope2.__tmcpUiInstalled) {
    scope2.__tmcpUiInstalled = true;
    const register = scope2.__tmcpRegister;
    scope2.__tmcpRegister = (value) => {
      const definition = value;
      register({
        ...definition,
        create(ctx) {
          const theme = () => ctx.ui.themeData();
          const toRender = ({ component, updateComponent, ...rest }) => ({
            ...rest,
            render: (props) => renderComponent(component, props, theme()),
            renderUpdate: updateComponent ? (props) => renderComponent(updateComponent, props, theme()) : void 0
          });
          const ui = {
            ...ctx.ui,
            action: (name) => action(`${ctx.ui.actionPrefix()}${name}`),
            widget(options) {
              if (!options.component) return ctx.ui.widget(options);
              return ctx.ui.widget(toRender(options));
            },
            window(options) {
              if (!options.component) return ctx.ui.window(options);
              return ctx.ui.window(toRender(options));
            }
          };
          return definition.create({ ...ctx, ui });
        }
      });
    };
  }

  // @tmcontrolpanel/plugin-sdk/src/ui/label.tsx
  var Label = slot("ui/label", ({ tone, font, ...rest }) => {
    const tokens = kit.useTokens();
    return /* @__PURE__ */ jsx(
      "label",
      {
        ...rest,
        textcolor: tokens.color[tone],
        textfont: font ? tokens.font[font] : void 0
      }
    );
  });

  // @tmcontrolpanel/plugin-sdk/src/ui/page.tsx
  function Page(props) {
    return /* @__PURE__ */ jsx(Manialink, { id: props.id, name: `TMCP:${props.id}`, children: props.children });
  }
  function ScriptPrelude() {
    return /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx(Script.Include, { lib: "MathLib", as: "ML" }),
      /* @__PURE__ */ jsx(Script.Include, { lib: "TextLib", as: "TL" }),
      /* @__PURE__ */ jsx(Script.Include, { lib: "TimeLib", as: "TimeLib" }),
      /* @__PURE__ */ jsx(Script.Include, { lib: "ColorLib", as: "CL" }),
      /* @__PURE__ */ jsx(Script.Events, { id: "skip-controlless-events", children: "if (Event.Control == Null) continue;" })
    ] });
  }

  // @tmcontrolpanel/plugin-sdk/src/ui/panel.tsx
  var Panel = slot("ui/panel", ({ tone, ...rest }) => {
    const { color } = kit.useTokens();
    return /* @__PURE__ */ jsx("quad", { ...rest, bgcolor: color[tone] });
  });

  // @tmcontrolpanel/plugin-sdk/src/ui/table.tsx
  var PREV = " Prev";
  var NEXT = "Next ";
  var UiTable = slot(
    "ui/table",
    ({ table, prevAction, nextAction, pos }) => {
      const { color, font } = kit.useTokens();
      const { width, rowHeight, textY, pagerY } = table;
      const height = -(pagerY - 6);
      return /* @__PURE__ */ jsxs("frame", { pos: pos ?? [0, 0], size: [width, height], children: [
        /* @__PURE__ */ jsx(Panel, { tone: "surface", pos: [0, 0], size: [width, rowHeight] }),
        table.columns.map((column) => /* @__PURE__ */ jsx(
          Label,
          {
            tone: "text",
            font: "title",
            pos: [column.x, textY],
            size: [column.width, rowHeight],
            text: column.title,
            halign: column.halign,
            valign: "center2",
            textsize: 0.9
          }
        )),
        table.rows.length === 0 ? /* @__PURE__ */ jsx(
          Label,
          {
            tone: "contentText",
            font: "body",
            pos: [width / 2, -rowHeight * 2],
            size: [width, rowHeight],
            text: table.empty,
            halign: "center",
            valign: "center2",
            textsize: 1,
            opacity: 0.6
          }
        ) : table.rows.map((row) => /* @__PURE__ */ jsxs("frame", { pos: [0, row.y], size: [width, rowHeight], children: [
          row.odd && /* @__PURE__ */ jsx(
            Panel,
            {
              tone: "contentAlt",
              pos: [0, 0],
              size: [width, rowHeight],
              opacity: 0.6
            }
          ),
          row.cells.map((cell) => /* @__PURE__ */ jsx(
            "label",
            {
              pos: [cell.x, textY],
              size: [cell.width, rowHeight],
              text: cell.text,
              halign: cell.halign,
              valign: "center2",
              textsize: 0.9,
              textfont: font.body,
              textcolor: cell.color ?? color.contentText
            }
          ))
        ] })),
        table.pages !== 1 && /* @__PURE__ */ jsxs("frame", { pos: [0, pagerY], size: [width, 5], children: [
          /* @__PURE__ */ jsx(
            Panel,
            {
              tone: "surface",
              pos: [0, 0],
              size: [width, 0.25],
              opacity: 0.4
            }
          ),
          /* @__PURE__ */ jsx(
            Label,
            {
              tone: "contentText",
              font: "body",
              pos: [1, -3],
              size: [width - 30, 4],
              text: `${table.from}-${table.to} of ${table.total}`,
              valign: "center2",
              textsize: 0.9,
              opacity: 0.7
            }
          ),
          /* @__PURE__ */ jsx(
            Label,
            {
              tone: "contentText",
              font: "title",
              pos: [width - 22, -3],
              size: [10, 4],
              text: PREV,
              halign: "center",
              valign: "center2",
              textsize: 0.9,
              ...table.hasPrev ? {
                action: prevAction,
                focusareacolor1: color.textMuted,
                focusareacolor2: color.text
              } : { opacity: 0.3 }
            }
          ),
          /* @__PURE__ */ jsx(
            Label,
            {
              tone: "contentText",
              font: "body",
              pos: [width - 14, -3],
              size: [6, 4],
              text: `${table.page}/${table.pages}`,
              halign: "center",
              valign: "center2",
              textsize: 0.9
            }
          ),
          /* @__PURE__ */ jsx(
            Label,
            {
              tone: "contentText",
              font: "title",
              pos: [width - 6, -3],
              size: [10, 4],
              text: NEXT,
              halign: "center",
              valign: "center2",
              textsize: 0.9,
              ...table.hasNext ? {
                action: nextAction,
                focusareacolor1: color.textMuted,
                focusareacolor2: color.text
              } : { opacity: 0.3 }
            }
          )
        ] })
      ] });
    }
  );

  // @tmcontrolpanel/plugin-sdk/src/ui/widget-hide.tsx
  function HideWhileDriving(props) {
    return /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx(Script.Globals, { id: "hide-while-driving", children: ms`
        declare Vec2 widgetBasePosition;
        declare CMlFrame HS_Target;
        declare Boolean HS_Hidden;
      ` }),
      /* @__PURE__ */ jsx(Script.Functions, { id: "hide-while-driving", children: ms`
        Void hs_hide(Integer duration) {
          HS_Hidden = True;
          declare Real x;
          if (widgetBasePosition[0] < 0.0) {
            x = (HS_Target.Size[0] * -HS_Target.RelativeScale) - 322.0;
          } else {
            x = 322.0;
          }
          AnimMgr.Add(HS_Target, "<frame pos='" ^ x ^ " " ^ widgetBasePosition[1] ^ "' />", duration, CAnimManager::EAnimManagerEasing::ExpInOut);
        }

        Void hs_show(Integer duration) {
          HS_Hidden = False;
          AnimMgr.Add(HS_Target, "<frame pos='" ^ widgetBasePosition[0] ^ " " ^ widgetBasePosition[1] ^ "' />", duration, CAnimManager::EAnimManagerEasing::CircOut);
        }

        Void hidescript() {
          if (HS_Target == Null) {
            HS_Target <=> (Page.MainFrame.GetFirstChild(${props.target}) as CMlFrame);
          }

          declare hideSpeed = 10;

          if (InputPlayer == Null) {
            if (HS_Hidden) {
              hs_show(600);
            }
            return;
          }

          declare Boolean overHidespeed = ML::Abs(InputPlayer.Speed * 3.6) > hideSpeed;

          if (overHidespeed && !HS_Hidden) {
            hs_hide(1000);

            while (InputPlayer.Speed * 3.6 > hideSpeed) {
              yield;
              hidescript();
            }
          }

          if (!overHidespeed && HS_Hidden) {
            sleep(1000);
            hs_show(600);
          }
        }
      ` }),
      props.active !== false && /* @__PURE__ */ jsx(Script.Loop, { id: "hide-while-driving", children: "hidescript();" })
    ] });
  }

  // @tmcontrolpanel/plugin-sdk/src/ui/widget.tsx
  function WidgetFrame(props) {
    const p = props.position;
    const pos = "x" in p ? [p.x, p.y] : p;
    return /* @__PURE__ */ jsxs(Page, { id: props.id, children: [
      /* @__PURE__ */ jsx(ScriptPrelude, {}),
      /* @__PURE__ */ jsx(Script.Globals, { id: "widget", children: "declare CMlFrame widget;" }),
      /* @__PURE__ */ jsx(Script.Main, { id: "widget", children: `
        widget <=> (Page.MainFrame.GetFirstChild("widget") as CMlFrame);
        widgetBasePosition = widget.AbsolutePosition_V3;

        sleep(300);
        widget.Show();
      ` }),
      /* @__PURE__ */ jsx("frame", { id: "widget", pos, "z-index": 10, hidden: true, children: props.children }),
      /* @__PURE__ */ jsx(HideWhileDriving, { target: "widget", active: props.hideWhileDriving })
    ] });
  }

  // @tmcontrolpanel/plugin-sdk/src/ui/window.tsx
  var CLOSE_ICON = "";
  var WindowFrame = slot("ui/window", (props) => {
    const [width, height] = props.size;
    const color = kit.useTokens().color;
    return /* @__PURE__ */ jsxs(
      "frame",
      {
        id: "window",
        pos: [-width / 2, height / 2],
        size: [width, height + 5],
        "z-index": 20,
        children: [
          /* @__PURE__ */ jsx(Panel, { tone: "surface", pos: [0, 0], size: [width, 5] }),
          /* @__PURE__ */ jsx(
            Label,
            {
              tone: "text",
              font: "title",
              pos: [1.5, -2.25],
              text: props.title,
              size: [width - 9.5, 5],
              valign: "center",
              halign: "left",
              textsize: 1
            }
          ),
          /* @__PURE__ */ jsx(
            Label,
            {
              tone: "text",
              pos: [width - 1.5, -2.25],
              text: CLOSE_ICON,
              size: [5, 5],
              valign: "center",
              halign: "right",
              textsize: 1,
              action: `close-window-${props.id}`,
              focusareacolor2: `${color.text}0`
            }
          ),
          /* @__PURE__ */ jsx(Panel, { tone: "content", pos: [0, -5], size: [width, height] }),
          /* @__PURE__ */ jsx("frame", { pos: [0, -5], size: [width, height], children: props.children })
        ]
      }
    );
  });

  // plugins/map-info/src/names.ts
  function resetTrailingWhite(name) {
    let last = null;
    for (let i = 0; i < name.length; i++) {
      if (name[i] !== "$") continue;
      const next = name[i + 1] ?? "";
      if (next === "$") {
        i++;
        continue;
      }
      const color = /^[0-9a-f]{3}/i.exec(name.slice(i + 1, i + 4));
      if (color) {
        last = { index: i, code: color[0] };
        i += 3;
      } else if (/[gz>]/i.test(next)) {
        last = { index: i, code: next };
        i++;
      }
    }
    if (!last || last.code.toLowerCase() !== "fff") return name;
    return `${name.slice(0, last.index)}$g${name.slice(last.index + 4)}`;
  }

  // plugins/map-info/src/index.tsx
  var UNKNOWN = { name: "-", author: "-" };
  var current2 = __mtx.shared("mapinfo_map", { "struct": "K_MapInfo", "fields": [{ "name": "name", "type": "Text" }, { "name": "author", "type": "Text" }] }, { code: ["", ""], holes: [{ kind: "value", type: { "struct": "K_MapInfo", "fields": [{ "name": "name", "type": "Text" }, { "name": "author", "type": "Text" }] }, get: () => UNKNOWN }], structs: ["#Struct K_MapInfo {\n  Text name;\n  Text author;\n}"], site: "src/index.tsx:23:17" }, "src/index.tsx:23:17");
  function MapInfoWidget(props) {
    return /* @__PURE__ */ jsxs(WidgetFrame, { ...props, children: [
      /* @__PURE__ */ jsx(Panel, { tone: "surface", size: [10, 10] }),
      /* @__PURE__ */ jsx(Panel, { tone: "content", pos: [10, 0], size: [45, 10] }),
      /* @__PURE__ */ jsx(
        Label,
        {
          tone: "text",
          font: "body",
          pos: [5, -4.75],
          size: [10, 10],
          text: "",
          halign: "center",
          valign: "center",
          textsize: 2.5
        }
      ),
      /* @__PURE__ */ jsx(
        Label,
        {
          tone: "contentText",
          font: "title",
          pos: [12, -5.25],
          size: [41, 5],
          text: __mtx.bind("Text", { code: ["", ".name"], holes: [{ kind: "shared", get: () => current2 }], structs: ["#Struct K_MapInfo {\n  Text name;\n  Text author;\n}"], site: "src/index.tsx:45:15" }),
          textsize: 1.75,
          valign: "bottom"
        }
      ),
      /* @__PURE__ */ jsx(
        Label,
        {
          tone: "contentText",
          font: "body",
          pos: [11.75, -5.5],
          size: [41, 5],
          text: __mtx.bind("Text", { code: ["", ".author"], holes: [{ kind: "shared", get: () => current2 }], structs: [], site: "src/index.tsx:54:15" }),
          textprefix: "$i",
          textsize: 1,
          valign: "top"
        }
      )
    ] });
  }
  function MapInfoUpdate(props) {
    const info = props.data ?? UNKNOWN;
    return /* @__PURE__ */ jsx(Manialink, { id: props.id, children: /* @__PURE__ */ jsx(Publish, { to: current2, value: info }) });
  }
  var MapInfoPlugin = class {
    constructor(ctx) {
      this.ctx = ctx;
      this.widget = ctx.ui.widget({
        id: "map-info-widget",
        component: MapInfoWidget,
        updateComponent: MapInfoUpdate,
        position: { x: 100, y: 85 },
        hideWhileDriving: true
      });
      ctx.on("beginMap", () => this.refresh());
    }
    widget;
    async start() {
      this.widget.display();
      await this.refresh();
    }
    async refresh() {
      this.widget.setData(await this.resolve());
      this.widget.update();
    }
    async resolve() {
      const map = await this.ctx.gbx.call("GetCurrentMapInfo");
      if (!map) return UNKNOWN;
      if (map.Name && map.AuthorNickname) {
        return { name: resetTrailingWhite(map.Name), author: map.AuthorNickname };
      }
      if (!map.UId) return UNKNOWN;
      const record = await this.ctx.maps.findByUid(map.UId);
      return record ? {
        name: resetTrailingWhite(record.name),
        author: record.authorNickname || "-"
      } : UNKNOWN;
    }
  };
  var index_default = definePlugin({
    create: (ctx) => new MapInfoPlugin(ctx)
  });
})();
