"use strict";
(() => {
  // @tmcontrolpanel/plugin-sdk/src/helpers.ts
  function buildTable(options) {
    const rowHeight = options.rowHeight ?? 4;
    const pageSize = Math.max(1, Math.floor(options.pageSize ?? 10));
    const total = options.rows.length;
    const pages = Math.max(1, Math.ceil(total / pageSize));
    const page = Math.min(Math.max(1, Math.floor(options.page ?? 1)), pages);
    const start = (page - 1) * pageSize;
    let offset = 0;
    const layout = options.columns.map((column) => {
      const x = offset;
      offset += column.width;
      const halign = column.align ?? "left";
      const labelX = halign === "left" ? x + 1 : halign === "right" ? x + column.width - 1 : x + column.width / 2;
      return { column, x: labelX, width: Math.max(1, column.width - 2), halign };
    });
    const rows = options.rows.slice(start, start + pageSize).map((row, index) => ({
      y: -(rowHeight + index * rowHeight),
      odd: index % 2 === 1,
      cells: layout.map(({ column, x, width, halign }) => {
        const value = column.text ? column.text(row) : column.key ? row[column.key] : "";
        return {
          text: value === null || value === void 0 ? "" : String(value),
          color: column.color?.(row) ?? null,
          x,
          width,
          halign
        };
      })
    }));
    return {
      width: offset,
      rowHeight,
      textY: -rowHeight / 2,
      // The pager stays put on short pages, below a full page of rows
      pagerY: -(rowHeight * (pageSize + 1) + 1),
      columns: layout.map(({ column, x, width, halign }) => ({
        title: column.title,
        x,
        width,
        halign
      })),
      rows,
      page,
      pages,
      total,
      from: total === 0 ? 0 : start + 1,
      to: start + rows.length,
      hasPrev: page > 1,
      hasNext: page < pages,
      empty: options.empty ?? "Nothing to show"
    };
  }

  // @tmcontrolpanel/plugin-sdk/src/index.ts
  function definePlugin(definition) {
    const register = globalThis.__tmcpRegister;
    if (typeof register === "function") register(definition);
    return definition;
  }

  // plugins/openplanet/src/help.ts
  var HELP_WIDTH = 110;
  var STEP_HEIGHT = 4.5;
  var FOOTER_HEIGHT = 4;
  var DISABLE_STEPS = [
    "Close the game.",
    "Hold Pause/Break and click Play in Ubisoft Connect, Epic Games or Steam.",
    "Keep holding it until the game window opens, then let go.",
    "No Pause/Break key? Rename dinput8.dll in the game folder to something else."
  ];
  function sectionsFor(input) {
    const disable = {
      question: "How do I start the game without Openplanet?",
      steps: DISABLE_STEPS
    };
    const orDisable = { ...disable, question: "Or: play without Openplanet" };
    const signature = {
      question: "How do I switch signature mode?",
      steps: [
        "Press F3 to open the Openplanet overlay.",
        "In the top menu click Openplanet, then Signature Mode.",
        `Pick an allowed mode: ${input.allowed.join(", ") || "none"}.`
      ]
    };
    const update = {
      question: "How do I update Openplanet?",
      steps: [
        "Close the game.",
        `Download the latest version from $<$l[https://openplanet.dev/download]openplanet.dev/download$l$>.`,
        "Run the installer and start the game again."
      ]
    };
    switch (input.violation) {
      case "openplanet":
        return [disable];
      case "signature":
        return [signature, orDisable];
      case "version":
        return [update, orDisable];
    }
    if (input.info && !input.info.hasOpenplanet) return [];
    if (!input.allowOpenplanet) return [disable];
    const sections = [];
    if (input.enforceSignatures) sections.push(signature);
    if (input.minimumVersion.trim()) sections.push(update);
    return sections;
  }
  function rulesLine(input) {
    if (!input.allowOpenplanet) return "Rules: Openplanet is not allowed.";
    const rules = [
      input.enforceSignatures ? `signature ${input.allowed.join(", ") || "none"}` : "any signature"
    ];
    if (input.minimumVersion.trim())
      rules.push(`version ${input.minimumVersion.trim()} or newer`);
    return `Rules: Openplanet allowed with ${rules.join(", ")}. Playing without it is always fine.`;
  }
  function status(input) {
    const info = input.info;
    switch (input.violation) {
      case "openplanet":
        return {
          headline: "Openplanet is not allowed on this server",
          detail: "Start the game without Openplanet to play here."
        };
      case "signature":
        return {
          headline: "Your Openplanet signature mode is not allowed",
          detail: `You use ${info?.signature || "UNKNOWN"}. Allowed: ${input.allowed.join(", ") || "none"}.`
        };
      case "version":
        return {
          headline: "Your Openplanet version is too old",
          detail: `You use ${info?.version || "an unknown version"}. Required: ${input.minimumVersion.trim()} or newer.`
        };
    }
    if (!info)
      return {
        headline: "Openplanet check",
        detail: "Your game has not reported its Openplanet status yet."
      };
    if (!info.hasOpenplanet)
      return {
        headline: "No Openplanet detected",
        detail: "You can play here as you are."
      };
    return {
      headline: "Your Openplanet setup is allowed",
      detail: `You use Openplanet ${info.version || "(unknown version)"} with ${info.signature || "UNKNOWN"}.`
    };
  }
  function helpData(input) {
    const { headline, detail } = status(input);
    const flagged = input.violation !== null;
    const headlineColor = flagged ? "F00" : input.info ? "0A4" : "";
    const rules = flagged ? "" : rulesLine(input);
    let cursor = rules ? -17 : -13;
    const sections = sectionsFor(input).map((section) => {
      const height = 7 + section.steps.length * STEP_HEIGHT;
      const placed = {
        question: section.question,
        y: cursor,
        height,
        steps: section.steps.map((text, i) => ({
          number: i + 1,
          text,
          y: -8.5 - i * STEP_HEIGHT
        }))
      };
      cursor -= height + 2;
      return placed;
    });
    const footerText = [];
    if (!flagged) {
      if (input.rechecks)
        footerText.push("This window updates when your setup changes.");
    } else if (input.enforcement === "kick")
      footerText.push(
        `You will be kicked ${Math.max(5, Math.round(input.kickDelay))} seconds after this warning.`
      );
    else if (input.enforcement === "spectator")
      footerText.push("You stay in spectator mode until the check passes.");
    if (flagged)
      footerText.push(
        input.rechecks ? "This window closes by itself once the check passes." : "Rejoin the server once you have fixed it."
      );
    const footer = footerText.map((text, i) => ({
      text,
      y: cursor - 1.5 - i * FOOTER_HEIGHT
    }));
    return {
      data: { headline, headlineColor, detail, rules, sections, footer },
      height: Math.ceil(-cursor + footer.length * FOOTER_HEIGHT)
    };
  }

  // plugins/openplanet/src/openplanet.ts
  var PREFIX = /^Openplanet\s+(\d+(?:\.\d+)*)/;
  var TAG = /\s\[([A-Za-z0-9_]+)\]$/;
  function parseToolInfo(input) {
    const raw = input.trim().slice(0, 200);
    if (!/^Openplanet\b/.test(raw))
      return { hasOpenplanet: false, version: "", signature: "", raw };
    const version = PREFIX.exec(raw)?.[1] ?? "";
    const tag = TAG.exec(raw)?.[1];
    const signature = tag ? tag.toUpperCase() : version ? "REGULAR" : "UNKNOWN";
    return { hasOpenplanet: true, version, signature, raw };
  }
  function compareVersions(a, b) {
    const left = a.split(".").map((part) => Number.parseInt(part, 10) || 0);
    const right = b.split(".").map((part) => Number.parseInt(part, 10) || 0);
    for (let i = 0; i < Math.max(left.length, right.length); i++) {
      const diff = (left[i] ?? 0) - (right[i] ?? 0);
      if (diff !== 0) return diff;
    }
    return 0;
  }
  function normalizeSignature(value) {
    return value.trim().toUpperCase();
  }
  function checkRules(info, rules) {
    if (!info.hasOpenplanet) return null;
    if (!rules.allowOpenplanet) return "openplanet";
    const minimum = rules.minimumVersion.trim();
    if (minimum && (!info.version || compareVersions(info.version, minimum) < 0))
      return "version";
    if (rules.enforceSignatures) {
      const allowed = new Set(
        rules.allowedSignatures.map(normalizeSignature).filter(Boolean)
      );
      if (!allowed.has(info.signature)) return "signature";
    }
    return null;
  }

  // plugins/openplanet/src/index.ts
  var ICON = "https://plugins.tmcontrolpanel.com/packages/openplanet/icon.png";
  var MIN_CHECK_GAP_MS = 1e3;
  var PAGE_SIZE = 13;
  var STATUS_TEXT = {
    openplanet: "Openplanet not allowed",
    signature: "Signature not allowed",
    version: "Outdated Openplanet"
  };
  function explain(violation, config) {
    switch (violation) {
      case "openplanet":
        return "Openplanet is not allowed on this server. Close the game, start it without Openplanet and rejoin.";
      case "version":
        return `This server requires Openplanet ${config.minimumVersion.trim()} or newer. Update Openplanet and rejoin.`;
      case "signature":
        return `Your Openplanet signature mode is not allowed here. Allowed: ${allowedSignatures(config).join(", ") || "none"}. Change it in Openplanet > Signature mode.`;
    }
  }
  function allowedSignatures(config) {
    return [
      ...new Set(
        [...config.allowedSignatures, ...config.customSignatures].map(normalizeSignature).filter(Boolean)
      )
    ];
  }
  function decode(value) {
    if (!value) return "";
    try {
      return decodeURIComponent(value.replace(/\+/g, " "));
    } catch {
      return "";
    }
  }
  var OpenplanetPlugin = class {
    constructor(ctx) {
      this.ctx = ctx;
      ctx.action("check", (answer) => this.onCheck(answer.login, ""));
      ctx.action(
        "check-{info}",
        (answer, params) => this.onCheck(answer.login, decode(params.info))
      );
      ctx.action("open", (answer) => this.onCommand(answer.login));
      ctx.command("openplanet", (_args, login) => this.onCommand(login));
      ctx.action("page-prev", (answer) => this.turnPage(answer.login, -1));
      ctx.action("page-next", (answer) => this.turnPage(answer.login, 1));
      ctx.on("playerDisconnect", (login) => this.forget(login));
    }
    players = /* @__PURE__ */ new Map();
    jails = /* @__PURE__ */ new Map();
    lastCheck = /* @__PURE__ */ new Map();
    windows = /* @__PURE__ */ new Map();
    pages = /* @__PURE__ */ new Map();
    helpWindows = /* @__PURE__ */ new Map();
    detector = null;
    start() {
      this.showDetector();
      this.ctx.ui.addButton({
        name: "openplanet",
        icon: ICON,
        type: "image",
        action: "open",
        adminOnly: true
      });
    }
    async onConfigUpdate() {
      this.showDetector();
      for (const login of [...this.players.keys()]) await this.evaluate(login);
      for (const login of [...this.helpWindows.keys()]) this.showHelp(login);
      this.refreshWindows();
    }
    stop() {
      for (const jail of this.jails.values()) jail.cancelKick?.();
      this.jails.clear();
    }
    config() {
      return this.ctx.config();
    }
    // One public page: the manialink service replays it to players who join later
    showDetector() {
      this.detector ??= this.ctx.ui.widget({
        id: "detector",
        template: "widgets/detector",
        withUpdate: false,
        position: { x: 0, y: 0 }
      });
      this.detector.setData({
        interval: Math.max(0, Math.round(this.config().checkInterval)) * 1e3
      });
      this.detector.display();
    }
    async onCheck(login, toolInfo) {
      const now = Date.now();
      const previous = this.players.get(login);
      if (previous && previous.info.raw === toolInfo.trim() && now - (this.lastCheck.get(login) ?? 0) < MIN_CHECK_GAP_MS)
        return;
      this.lastCheck.set(login, now);
      const player = await this.ctx.players.get(login).catch(() => null);
      const info = parseToolInfo(toolInfo);
      if (info.signature === "UNKNOWN")
        this.ctx.log.warn("Unrecognised Openplanet tool info", {
          login,
          raw: info.raw
        });
      this.players.set(login, {
        login,
        nickName: player?.nickName ?? previous?.nickName ?? login,
        info,
        violation: null,
        checkedAt: now
      });
      await this.evaluate(login);
      this.refreshWindows();
    }
    async evaluate(login) {
      const state = this.players.get(login);
      if (!state) return;
      const config = this.config();
      let violation = checkRules(state.info, {
        allowOpenplanet: config.allowOpenplanet,
        enforceSignatures: config.enforceSignatures,
        allowedSignatures: allowedSignatures(config),
        minimumVersion: config.minimumVersion
      });
      if (violation && config.exemptAdmins && await this.ctx.players.isAdmin(login))
        violation = null;
      state.violation = violation;
      if (violation) {
        await this.jail(login, violation);
        this.showHelp(login);
      } else {
        await this.release(login);
        if (this.helpWindows.has(login)) this.showHelp(login);
      }
    }
    async jail(login, violation) {
      const config = this.config();
      const existing = this.jails.get(login);
      if (existing?.violation === violation && existing.enforcement === config.enforcement)
        return;
      existing?.cancelKick?.();
      const jail = {
        violation,
        enforcement: config.enforcement,
        cancelKick: null
      };
      this.jails.set(login, jail);
      if (config.enforcement !== "warn")
        await this.gbx("ForceSpectator", login, 1);
      else if (existing && existing.enforcement !== "warn")
        await this.unforce(login);
      let message = `$f00Openplanet check: ${explain(violation, config)} Type /openplanet for help.`;
      if (config.enforcement === "kick") {
        const delay = Math.max(5, Math.round(config.kickDelay));
        message += ` You will be kicked in ${delay} seconds.`;
        jail.cancelKick = this.ctx.setTimeout(() => {
          if (this.jails.get(login) !== jail) return;
          void this.gbx("Kick", login, STATUS_TEXT[violation]);
        }, delay * 1e3);
      }
      await this.ctx.chat.sendTo(login, message).catch(() => void 0);
    }
    async release(login) {
      const jail = this.jails.get(login);
      if (!jail) return;
      jail.cancelKick?.();
      this.jails.delete(login);
      this.closeHelp(login);
      if (jail.enforcement !== "warn") await this.unforce(login);
      await this.ctx.chat.sendTo(login, "$0f0Openplanet check passed, thanks!").catch(() => void 0);
    }
    // Forcing player then selectable puts them back on track instead of leaving them in spectator
    async unforce(login) {
      await this.gbx("ForceSpectator", login, 2);
      await this.gbx("ForceSpectator", login, 0);
    }
    async gbx(method, ...params) {
      try {
        await this.ctx.gbx.call(method, ...params);
      } catch (error) {
        this.ctx.log.warn(`${method} failed`, { params, error: String(error) });
      }
    }
    forget(login) {
      this.jails.get(login)?.cancelKick?.();
      this.jails.delete(login);
      this.players.delete(login);
      this.lastCheck.delete(login);
      this.windows.get(login)?.destroy();
      this.windows.delete(login);
      this.pages.delete(login);
      this.closeHelp(login);
      this.refreshWindows();
    }
    // Admins get the signatures overview, everyone else their own status and help
    async onCommand(login) {
      if (await this.ctx.players.isAdmin(login)) await this.openWindow(login);
      else this.showHelp(login);
    }
    // Shows a player their Openplanet status, the rules and how to fix a violation
    showHelp(login) {
      const config = this.config();
      const { data, height } = helpData({
        violation: this.jails.get(login)?.violation ?? null,
        info: this.players.get(login)?.info ?? null,
        allowOpenplanet: config.allowOpenplanet,
        enforceSignatures: config.enforceSignatures,
        allowed: allowedSignatures(config),
        minimumVersion: config.minimumVersion,
        enforcement: config.enforcement,
        kickDelay: config.kickDelay,
        rechecks: config.checkInterval > 0
      });
      const size = { x: HELP_WIDTH, y: height };
      let window = this.helpWindows.get(login);
      if (!window) {
        window = this.ctx.ui.window({
          id: "help",
          template: "windows/help",
          title: "Openplanet check",
          login,
          size,
          withUpdate: false,
          data,
          onClose: () => this.helpWindows.delete(login)
        });
        this.helpWindows.set(login, window);
      } else {
        window.setSize(size);
        window.setData(data);
      }
      window.display();
    }
    closeHelp(login) {
      this.helpWindows.get(login)?.destroy();
      this.helpWindows.delete(login);
    }
    // Callers check that the login is an admin
    async openWindow(login) {
      if (this.windows.has(login)) return;
      const window = this.ctx.ui.window({
        id: "signatures",
        template: "windows/signatures",
        title: "Openplanet signatures",
        login,
        size: { x: 120, y: 75 },
        withUpdate: false,
        data: this.windowData(login),
        onClose: () => {
          this.windows.delete(login);
          this.pages.delete(login);
        }
      });
      this.windows.set(login, window);
      window.display();
    }
    refreshWindows() {
      for (const [login, window] of this.windows) {
        window.setData(this.windowData(login));
        window.display();
      }
    }
    turnPage(login, delta) {
      const window = this.windows.get(login);
      if (!window) return;
      this.pages.set(login, (this.pages.get(login) ?? 1) + delta);
      window.setData(this.windowData(login));
      window.display();
    }
    windowData(login) {
      const config = this.config();
      const players = [...this.players.values()].sort(
        (a, b) => Number(b.violation !== null) - Number(a.violation !== null) || a.nickName.localeCompare(b.nickName)
      );
      const table = buildTable({
        rows: players,
        page: this.pages.get(login) ?? 1,
        pageSize: PAGE_SIZE,
        empty: "No players checked yet",
        columns: [
          { title: "Player", width: 38, text: (p) => p.nickName },
          {
            title: "Openplanet",
            width: 16,
            align: "center",
            text: (p) => p.info.hasOpenplanet ? "" : "",
            color: (p) => p.info.hasOpenplanet ? "0A4" : "F00"
          },
          { title: "Version", width: 18, text: (p) => p.info.version || "-" },
          { title: "Signature", width: 20, text: (p) => p.info.signature || "-" },
          {
            title: "Status",
            width: 24,
            text: (p) => p.violation ? STATUS_TEXT[p.violation] : "OK",
            color: (p) => p.violation ? "F00" : "0A4"
          }
        ]
      });
      this.pages.set(login, table.page);
      const allowed = !config.allowOpenplanet ? "Openplanet not allowed" : config.enforceSignatures ? `Signatures: ${allowedSignatures(config).join(", ") || "none"}` : "Any signature";
      const enforcement = [
        config.minimumVersion.trim() && `Min ${config.minimumVersion.trim()}`,
        `Action: ${config.enforcement}`
      ];
      return {
        table,
        rules: [allowed, enforcement.filter(Boolean).join("  ·  ")],
        stats: [
          { label: "Players", value: players.length },
          {
            label: "Openplanet",
            value: players.filter((p) => p.info.hasOpenplanet).length
          },
          {
            label: "Violations",
            value: players.filter((p) => p.violation !== null).length,
            alert: players.some((p) => p.violation !== null)
          }
        ]
      };
    }
  };
  var index_default = definePlugin({
    create(ctx) {
      const plugin = new OpenplanetPlugin(ctx);
      return {
        start: () => plugin.start(),
        stop: () => plugin.stop(),
        onConfigUpdate: () => plugin.onConfigUpdate()
      };
    }
  });
})();
