"use strict";
(() => {
  // @tmcontrolpanel/plugin-sdk/src/helpers.ts
  var BASE64URL = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
  function loginToAccountId(login) {
    if (login.includes("fakeplayer") || !/^[A-Za-z0-9_-]{22}$/.test(login)) return null;
    const bytes = [];
    let buffer = 0;
    let bits = 0;
    for (const char of login) {
      buffer = buffer << 6 | BASE64URL.indexOf(char);
      bits += 6;
      if (bits >= 8) {
        bits -= 8;
        bytes.push(buffer >> bits & 255);
      }
    }
    if (bytes.length !== 16) return null;
    const hex = bytes.map((byte) => byte.toString(16).padStart(2, "0")).join("");
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
  }
  var MapList = class {
    constructor(ctx) {
      this.ctx = ctx;
    }
    async getAll() {
      const pageSize = 100;
      let all = [];
      for (let start = 0; ; start += pageSize) {
        const batch = await this.ctx.gbx.call("GetMapList", pageSize, start);
        if (!Array.isArray(batch) || batch.length === 0) break;
        all = all.concat(batch);
        if (batch.length < pageSize) break;
      }
      if (all.length === 0) throw new Error("Failed to retrieve the map list from the server");
      return all;
    }
    // Unknown files are skipped
    async getInfos(fileNames) {
      const infos = [];
      for (const fileName of fileNames) {
        try {
          const info = await this.ctx.gbx.call("GetMapInfo", fileName);
          if (info) infos.push(info);
        } catch (error) {
          this.ctx.log.warn(`Failed to get map info for ${fileName}`, { error: String(error) });
        }
      }
      return infos;
    }
    // Makes the map list exactly fileNames, in that order
    async replace(fileNames) {
      await this.ctx.gbx.call("RemoveMapList", fileNames);
      const added = await this.ctx.gbx.call("AddMapList", fileNames);
      if (typeof added !== "number") throw new Error("Failed to add maps to the map list");
      const others = (await this.getAll()).map((map) => map.FileName).filter((fileName) => !fileNames.includes(fileName));
      const removed = await this.ctx.gbx.call("RemoveMapList", others);
      if (typeof removed !== "number") throw new Error("Failed to remove maps from the map list");
    }
    async jumpTo(index) {
      await this.ctx.gbx.call("JumpToMapIndex", index);
    }
    async restart() {
      await this.ctx.gbx.call("RestartMap");
    }
  };

  // @tmcontrolpanel/plugin-sdk/src/index.ts
  function definePlugin(definition) {
    const register = globalThis.__tmcpRegister;
    if (typeof register === "function") register(definition);
    return definition;
  }

  // plugins/match/src/pickban.ts
  function stringToPickAndBan(str) {
    if (!str) return [];
    return str.split(",").map((item) => {
      const [action2, seed] = item.trim().split(":");
      if (action2 === "p") return { action: "pick", seed: parseInt(seed, 10) };
      if (action2 === "b") return { action: "ban", seed: parseInt(seed, 10) };
      if (action2 === "r") return { action: "random" };
      throw new Error(`Invalid pick and ban item: ${item}`);
    });
  }
  function applySeedsOverride(order, seeds) {
    if (seeds.length === 0) return order;
    const uniqueSeeds = [
      ...new Set(
        order.flatMap((item) => item.action === "random" ? [] : [item.seed])
      )
    ].sort((a, b) => a - b);
    const replacements = /* @__PURE__ */ new Map();
    seeds.forEach((seed, i) => {
      if (i < uniqueSeeds.length) replacements.set(uniqueSeeds[i], seed);
    });
    return order.map(
      (item) => item.action === "random" ? item : { ...item, seed: replacements.get(item.seed) ?? item.seed }
    );
  }
  function availablePositions(order) {
    return order.filter((item) => item.action === "pick" || item.action === "random").map((_, i) => i + 1);
  }
  var PickBan = class {
    constructor(setup, nickNameOf, random = Math.random) {
      this.nickNameOf = nickNameOf;
      this.random = random;
      this.mode = setup.mode;
      this.choosePosition = setup.choosePosition;
      this.maps = setup.maps;
      this.order = setup.order;
      this.players = setup.players;
      this.teams = setup.teams;
      this.positionsAvailable = availablePositions(setup.order);
      this.turn = this.computeTurn();
    }
    mode;
    choosePosition;
    maps;
    positionsAvailable;
    order;
    players;
    teams;
    picked = /* @__PURE__ */ new Map();
    currentIndex = 0;
    turn;
    // Map waiting for its position (choosePosition mode)
    pendingMapUid = null;
    get currentTurn() {
      return this.turn;
    }
    get isDone() {
      return this.currentIndex >= this.maps.length || this.turn === null;
    }
    // Final map list in position order
    pickedFileNames() {
      return [...this.picked.entries()].sort(([a], [b]) => a - b).map(([, file]) => file);
    }
    advance() {
      this.currentIndex += 1;
      this.pendingMapUid = null;
      this.turn = this.computeTurn();
      return this.turn;
    }
    select(login, uid, activeLogins) {
      const turn2 = this.turn;
      if (!turn2) return { kind: "noTurn" };
      if (this.mode === "player" && turn2.login !== login)
        return { kind: "notYourTurn" };
      if (this.mode === "team" && !turn2.players.includes(login))
        return { kind: "notYourTurn" };
      const map = this.maps.find((m) => m.uid === uid);
      if (!map) return { kind: "mapNotFound" };
      if (map.pickedBy || map.bannedBy) return { kind: "mapUnavailable" };
      if (this.mode === "team") {
        if (!map.selectedBy.includes(login)) map.selectedBy.push(login);
        for (const other of this.maps) {
          if (other !== map && !other.pickedBy && !other.bannedBy) {
            other.selectedBy = other.selectedBy.filter((l) => l !== login);
          }
        }
        const votes = map.selectedBy.filter(
          (l) => turn2.players.includes(l)
        ).length;
        const activeTeamPlayers = activeLogins.filter(
          (l) => turn2.players.includes(l)
        ).length;
        if (votes <= activeTeamPlayers / 2) return { kind: "voteRegistered" };
      } else if (turn2.action === "pick" && this.choosePosition) {
        this.pendingMapUid = map.uid;
        return { kind: "choosePosition" };
      }
      if (turn2.action === "pick") {
        this.pickAt(map, turn2.nickName, this.picked.size + 1);
      } else if (turn2.action === "ban") {
        map.bannedBy = turn2.nickName;
      }
      return { kind: "applied", map };
    }
    // Completes a choosePosition pick; false when the position is not available
    choosePositionFor(position) {
      const turn2 = this.turn;
      const map = this.maps.find((m) => m.uid === this.pendingMapUid);
      const slot2 = this.positionsAvailable.indexOf(position);
      if (!turn2 || !map || slot2 === -1) return null;
      this.positionsAvailable.splice(slot2, 1);
      this.pickAt(map, turn2.nickName, position);
      this.pendingMapUid = null;
      return map;
    }
    // Explicit "random" step: always a pick, by "random"
    pickRandom() {
      const map = this.randomAvailableMap();
      if (!map) return null;
      this.pickAt(map, "random", this.nextAutoPosition());
      return map;
    }
    // Timed-out turn: apply the turn's own action to a random map on the player's behalf
    resolveTimeout() {
      const turn2 = this.turn;
      if (!turn2) return null;
      const map = this.randomAvailableMap();
      if (!map) return null;
      if (turn2.action === "ban") {
        map.bannedBy = turn2.nickName;
      } else {
        this.pickAt(map, turn2.nickName, this.nextAutoPosition());
      }
      return map;
    }
    pickAt(map, by, position) {
      this.picked.set(position - 1, map.filename);
      map.pickedBy = by;
      map.index = position;
    }
    nextAutoPosition() {
      if (this.mode === "player" && this.choosePosition) {
        const next = this.positionsAvailable.shift();
        if (next !== void 0) return next;
      }
      return this.picked.size + 1;
    }
    randomAvailableMap() {
      const available = this.maps.filter((m) => !m.pickedBy && !m.bannedBy);
      if (available.length === 0) return null;
      return available[Math.floor(this.random() * available.length)] ?? null;
    }
    computeTurn() {
      const step = this.order[this.currentIndex];
      if (!step) return null;
      if (step.action === "random") {
        return { action: "random", login: "", players: [], nickName: "" };
      }
      if (this.mode === "player") {
        const player = this.players.find((p) => p.seed === step.seed);
        if (!player)
          return { action: step.action, login: "", players: [], nickName: "" };
        return {
          action: step.action,
          login: player.login,
          players: [],
          nickName: this.nickNameOf(player.login) || player.login
        };
      }
      const team = this.teams.find((t) => t.seed === step.seed);
      if (!team)
        return { action: step.action, login: "", players: [], nickName: "" };
      return {
        action: step.action,
        login: "",
        players: team.players,
        nickName: team.name || `Team ${step.seed}`
      };
    }
  };

  // ../gocontrolpanel/packages/maniatsx/dist/client/contract.js
  var CLIENT = /* @__PURE__ */ Symbol.for("maniatsx.client");

  // ../gocontrolpanel/packages/maniatsx/dist/maniascript/client-only.js
  function clientOnly(name) {
    return new Proxy(() => {
    }, {
      get(_target, property) {
        if (property === Symbol.toPrimitive)
          return () => `[client-only ${name}]`;
        if (typeof property === "symbol" || property === "then")
          return void 0;
        throw new Error(`${name}.${property} is client-only: use it inside maniatsx client code`);
      },
      apply() {
        throw new Error(`${name} is client-only: use it inside maniatsx client code`);
      }
    });
  }

  // ../gocontrolpanel/packages/maniatsx/dist/client/authoring.js
  var ml = clientOnly("ml");
  function notCompiled(api) {
    throw new Error(`${api} was not compiled: add the maniatsx build transform (Bun plugin or \`maniatsx compile\`)`);
  }
  function action(name) {
    if (!/^[\w.:-]+$/.test(name))
      throw new Error(`action(): invalid name ${JSON.stringify(name)}`);
    return {
      $$typeof: CLIENT,
      kind: "action",
      name,
      trigger: () => notCompiled(`action("${name}").trigger`)
    };
  }

  // ../gocontrolpanel/packages/maniatsx/dist/vnode.js
  var VNODE = /* @__PURE__ */ Symbol.for("maniatsx.vnode");
  var Fragment = /* @__PURE__ */ Symbol.for("maniatsx.fragment");
  var MS_CODE = /* @__PURE__ */ Symbol.for("maniatsx.ms");
  var RAW_XML = /* @__PURE__ */ Symbol.for("maniatsx.raw");

  // ../gocontrolpanel/packages/maniatsx/dist/ms.js
  function code(text) {
    return Object.freeze({ $$typeof: MS_CODE, code: text });
  }
  function isMsCode(value) {
    return typeof value === "object" && value !== null && value.$$typeof === MS_CODE;
  }
  function decimal(n) {
    const s = String(n);
    const m = /^(-?)(\d)(?:\.(\d+))?e([+-]\d+)$/.exec(s);
    if (!m)
      return s;
    const digits = m[2] + (m[3] ?? "");
    const point = 1 + Number(m[4]);
    let body;
    if (point <= 0)
      body = "0." + "0".repeat(-point) + digits;
    else if (point >= digits.length)
      body = digits + "0".repeat(point - digits.length);
    else
      body = digits.slice(0, point) + "." + digits.slice(point);
    return m[1] + body;
  }
  function finite(n, where2) {
    if (typeof n !== "number")
      throw new TypeError(`${where2} expects a number, got ${typeof n}`);
    if (!Number.isFinite(n))
      throw new RangeError(`${where2} expects a finite number, got ${n}`);
    return n;
  }
  function realText(n, where2) {
    const s = decimal(finite(n, where2));
    return s.includes(".") ? s : s + ".";
  }
  function intText(n, where2) {
    if (!Number.isInteger(finite(n, where2)))
      throw new RangeError(`${where2} expects an integer, got ${n}`);
    if (!Number.isSafeInteger(n))
      throw new RangeError(`${where2} is outside the safe Integer range: ${n}`);
    return decimal(n);
  }
  function stringText(s) {
    const escaped = s.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\t/g, "\\t").replace(/-(?=-)/g, '-" ^ "');
    return `"${escaped}"`;
  }
  function kindOf(value) {
    if (isMsCode(value))
      return "code";
    if (Array.isArray(value))
      return "array";
    return typeof value;
  }
  function literal(value, where2) {
    if (typeof value === "number") {
      return Number.isInteger(finite(value, where2)) ? intText(value, where2) : decimal(value);
    }
    if (typeof value === "string")
      return stringText(value);
    if (typeof value === "boolean")
      return value ? "True" : "False";
    if (isMsCode(value))
      return value.code;
    if (Array.isArray(value)) {
      if (value.length === 0)
        throw new TypeError(`${where2} is an empty array; ManiaScript needs a typed literal`);
      const first = kindOf(value[0]);
      const items = value.map((item, i) => {
        if (kindOf(item) !== first) {
          throw new TypeError(`${where2} mixes ${first} and ${kindOf(item)} items (item ${i})`);
        }
        return literal(item, `${where2}[${i}]`);
      });
      return `[${items.join(", ")}]`;
    }
    const what = value === null ? "null" : typeof value;
    throw new TypeError(`${where2} cannot be turned into ManiaScript: got ${what}`);
  }
  function dedentParts(parts) {
    if (!parts.some((p) => p.includes("\n")))
      return [...parts];
    let min = Infinity;
    parts.forEach((part, k) => {
      const lines = part.split("\n");
      lines.forEach((line, j) => {
        if (j === 0 && k > 0)
          return;
        const lastOfOpen = j === lines.length - 1 && k < parts.length - 1;
        if (line.trim() === "" && !lastOfOpen)
          return;
        min = Math.min(min, line.length - line.trimStart().length);
      });
    });
    if (min === Infinity)
      min = 0;
    const out = parts.map((part, k) => part.split("\n").map((line, j) => j === 0 && k > 0 ? line : line.slice(Math.min(min, line.length - line.trimStart().length))).join("\n"));
    out[0] = out[0].replace(/^([ \t]*\n)+/, "");
    const last = out.length - 1;
    out[last] = out[last].replace(/(\n[ \t]*)+$/, "");
    return out;
  }
  function dedent(text) {
    return dedentParts([text.replace(/\r\n?/g, "\n")])[0];
  }
  function tag(strings, ...values) {
    const parts = dedentParts(strings.raw);
    let text = parts[0];
    values.forEach((value, i) => {
      text += literal(value, `ms\`\` interpolation ${i}`) + parts[i + 1];
    });
    return code(text);
  }
  var ms = Object.assign(tag, {
    real: (n) => code(realText(n, "ms.real()")),
    int: (n) => code(intText(n, "ms.int()")),
    vec2: (x, y) => code(`<${realText(x, "ms.vec2() x")}, ${realText(y, "ms.vec2() y")}>`),
    raw(text) {
      if (typeof text !== "string")
        throw new TypeError("ms.raw() expects a string");
      return code(text);
    }
  });

  // ../gocontrolpanel/packages/maniatsx/dist/context.js
  var providers = /* @__PURE__ */ new WeakMap();
  var contextRuntime = { stack: null };
  function createContext(defaultValue) {
    const id = /* @__PURE__ */ Symbol("maniatsx.context");
    const Provider = ({ children }) => children;
    const ctx = { id, defaultValue, Provider };
    providers.set(Provider, ctx);
    return ctx;
  }
  function useContext(ctx) {
    const stack = contextRuntime.stack;
    if (!stack)
      throw new Error("useContext() can only be called while rendering");
    for (let i = stack.length - 1; i >= 0; i--) {
      if (stack[i].id === ctx.id)
        return stack[i].value;
    }
    return ctx.defaultValue;
  }

  // ../gocontrolpanel/packages/maniatsx/dist/serialize.js
  function formatNumber(n) {
    if (!Number.isFinite(n))
      throw new RangeError(`Cannot serialise non-finite number ${n}`);
    if (Math.abs(n) >= 1e21)
      return BigInt(n).toString();
    let s = n.toFixed(4);
    if (s.includes("."))
      s = s.replace(/0+$/, "").replace(/\.$/, "");
    return s === "-0" ? "0" : s;
  }
  var ATTR_ESCAPES = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&apos;",
    "\n": "&#10;",
    "\r": "&#13;",
    "	": "&#9;"
  };
  function escapeAttribute(s) {
    return s.replace(/[&<>"'\n\r\t]/g, (c) => ATTR_ESCAPES[c]);
  }
  function escapeText(s) {
    return s.replace(/[&<>]/g, (c) => ATTR_ESCAPES[c]);
  }
  function num(n, element, name) {
    if (!Number.isFinite(n)) {
      throw new RangeError(`<${element}> attribute "${name}": non-finite number ${n}`);
    }
    return formatNumber(n);
  }
  function serializeValue(element, name, value) {
    if (value === null || value === void 0)
      return null;
    switch (typeof value) {
      case "string":
        return value;
      case "number":
        return num(value, element, name);
      case "boolean":
        return value ? "1" : "0";
    }
    if (Array.isArray(value)) {
      if (name === "class") {
        const parts = [];
        for (const part of value) {
          if (part === null || part === void 0 || part === false)
            continue;
          if (typeof part !== "string") {
            throw new TypeError(`<${element}> attribute "class": array items must be strings`);
          }
          if (part !== "")
            parts.push(part);
        }
        return parts.length > 0 ? parts.join(" ") : null;
      }
      if (value.length > 0 && value.every((v) => typeof v === "number")) {
        return value.map((v) => num(v, element, name)).join(" ");
      }
    }
    throw new TypeError(`<${element}> attribute "${name}": unsupported value of type ${describeType(value)}`);
  }
  function describeType(value) {
    if (Array.isArray(value))
      return "array";
    return typeof value;
  }

  // ../gocontrolpanel/packages/maniatsx/dist/render.js
  var CLIENT_HANDLE = /* @__PURE__ */ Symbol.for("maniatsx.client");
  var MANIALINK_SCOPE = /* @__PURE__ */ Symbol.for("maniatsx.manialink");
  function isClientHandle(value) {
    return typeof value === "object" && value !== null && value.$$typeof === CLIENT_HANDLE;
  }
  var NAME = /^[A-Za-z_][\w.:-]*$/;
  var STYLE_TEXT = /* @__PURE__ */ new Set(["style", "stylesheet"]);
  var TIMEOUT_MAX = 2147483647;
  var current = null;
  function render(node, options = {}) {
    const st = {
      out: [],
      pretty: options.pretty ?? false,
      depth: 0,
      element: null,
      contexts: (options.contexts ?? []).map(([ctx, value]) => ({ id: ctx.id, value })),
      scopes: [],
      ids: /* @__PURE__ */ new Set(),
      warn: options.onWarning ?? ((m) => console.warn(m))
    };
    const prev = current;
    const prevStack = contextRuntime.stack;
    current = st;
    contextRuntime.stack = st.contexts;
    try {
      walk(node, st);
    } finally {
      current = prev;
      contextRuntime.stack = prevStack;
    }
    let xml = st.out.join("");
    if (st.pretty && xml.endsWith("\n"))
      xml = xml.slice(0, -1);
    if (options.warnBytes !== void 0 && xml.length * 3 > options.warnBytes) {
      const bytes = new TextEncoder().encode(xml).length;
      if (bytes > options.warnBytes) {
        st.warn(`Output is ${bytes} bytes, over the warnBytes limit of ${options.warnBytes}`);
      }
    }
    return xml;
  }
  function renderChildren(node, scope3) {
    const st = requireState("renderChildren()");
    const saved = {
      out: st.out,
      ids: st.ids,
      depth: st.depth,
      element: st.element,
      contexts: st.contexts.length,
      scopes: st.scopes.length
    };
    st.out = [];
    if (scope3) {
      st.scopes.push(scope3);
      st.ids = /* @__PURE__ */ new Set();
    }
    try {
      walk(node, st);
      return st.out.join("");
    } finally {
      st.out = saved.out;
      st.ids = saved.ids;
      st.depth = saved.depth;
      st.element = saved.element;
      st.contexts.length = saved.contexts;
      st.scopes.length = saved.scopes;
    }
  }
  function useRenderScope(key) {
    const st = requireState("useRenderScope()");
    for (let i = st.scopes.length - 1; i >= 0; i--) {
      if (st.scopes[i].key === key)
        return st.scopes[i].value;
    }
    return void 0;
  }
  function reportRawScript(st) {
    for (let i = st.scopes.length - 1; i >= 0; i--) {
      const value = st.scopes[i].value;
      if (typeof value?.onRawScript === "function") {
        value.onRawScript();
        return;
      }
    }
  }
  function requireState(fn) {
    if (!current)
      throw new Error(`${fn} can only be called while rendering`);
    return current;
  }
  function describe(node) {
    if (typeof node === "object" && node !== null && node.$$typeof === VNODE) {
      const type = node.type;
      if (typeof type === "string")
        return `<${type}>`;
      if (typeof type === "function")
        return `component ${type.name || "(anonymous)"}`;
      return "<Fragment>";
    }
    return typeof node;
  }
  function where(st) {
    return st.element ? `inside <${st.element}>` : "at the top level";
  }
  function push(st, text) {
    if (text !== "")
      st.out.push(text);
  }
  function pushText(st, text) {
    if (st.pretty)
      push(st, "  ".repeat(st.depth) + text + "\n");
    else
      push(st, text);
  }
  function walk(node, st) {
    if (node === null || node === void 0 || typeof node === "boolean")
      return;
    if (typeof node === "string" || typeof node === "number") {
      if (typeof node === "number" && st.element === "timeout") {
        if (!Number.isInteger(node) || node < 0 || node > TIMEOUT_MAX) {
          throw new Error(`<timeout> must contain an integer from 0 to ${TIMEOUT_MAX}, got ${node}`);
        }
        pushText(st, String(node));
        return;
      }
      const text = typeof node === "number" ? formatNumber(node) : node;
      if (st.element !== null && STYLE_TEXT.has(st.element)) {
        pushText(st, escapeText(text));
        return;
      }
      const preview = JSON.stringify(text.length > 30 ? text.slice(0, 30) + "..." : text);
      throw new Error(`Text ${preview} is not allowed ${where(st)}; only <script>, <style> and <stylesheet> take text`);
    }
    if (Array.isArray(node)) {
      for (const child of node)
        walk(child, st);
      return;
    }
    const obj = node;
    if (obj.$$typeof === RAW_XML) {
      const xml = obj.xml;
      push(st, st.pretty && xml !== "" && !xml.endsWith("\n") ? xml + "\n" : xml);
      return;
    }
    if (obj.$$typeof === MS_CODE) {
      throw new Error(`ManiaScript code is only allowed inside <script>, found ${where(st)}`);
    }
    if (obj.$$typeof !== VNODE) {
      throw new Error(`Cannot render a value of type ${typeof node} ${where(st)}`);
    }
    const vnode = node;
    const { type, props } = vnode;
    if (type === Fragment) {
      walk(props.children, st);
    } else if (typeof type === "function") {
      const ctx = providers.get(type);
      if (ctx) {
        st.contexts.push({ id: ctx.id, value: props.value });
        try {
          walk(props.children, st);
        } finally {
          st.contexts.pop();
        }
      } else {
        walk(type(props), st);
      }
    } else if (typeof type === "string") {
      writeElement(type, props, st);
    } else {
      throw new Error(`Invalid element type ${String(type)} ${where(st)}`);
    }
  }
  function writeAttributes(tag2, props, st) {
    let attrs = "";
    for (const name of Object.keys(props)) {
      if (name === "children" || name === "key")
        continue;
      const value = props[name];
      if (Array.isArray(value) && value.length === 0 && name !== "class") {
        st.warn(`<${tag2}> attribute "${name}" is an empty array and was omitted`);
        continue;
      }
      const text = serializeValue(tag2, name, value);
      if (text === null)
        continue;
      if (!NAME.test(name))
        throw new Error(`<${tag2}>: invalid attribute name "${name}"`);
      if (name === "id") {
        if (st.ids.has(text))
          st.warn(`Duplicate id "${text}" on <${tag2}>`);
        else
          st.ids.add(text);
      }
      attrs += ` ${name}="${escapeAttribute(text)}"`;
    }
    return attrs;
  }
  function collectScriptText(node, out) {
    if (node === null || node === void 0 || typeof node === "boolean")
      return;
    if (typeof node === "string")
      out.push(node);
    else if (typeof node === "number")
      out.push(formatNumber(node));
    else if (Array.isArray(node))
      for (const child of node)
        collectScriptText(child, out);
    else if (node.$$typeof === MS_CODE) {
      out.push(node.code);
    } else {
      throw new Error(`<script> only takes text or ManiaScript code, found ${describe(node)}`);
    }
  }
  function writeElement(tag2, props, st) {
    if (!NAME.test(tag2))
      throw new Error(`Invalid element name "${tag2}"`);
    if (Object.values(props).some(isClientHandle)) {
      const scope3 = useRenderScope(MANIALINK_SCOPE);
      if (!scope3)
        throw new Error(`<${tag2}> client handles can only be used inside <Manialink>`);
      const client3 = scope3.client;
      if (!client3)
        throw new Error(`<${tag2}> client handles need the runtime: import "maniatsx/client"`);
      props = client3.element(tag2, props);
    }
    for (const name of ["onClick", "onRightClick", "onMouseOver", "onMouseOut", "onSubmit"]) {
      if (props[name] != null)
        throw new Error(`<${tag2}> attribute "${name}" requires a ClientHandler`);
    }
    const indent = st.pretty ? "  ".repeat(st.depth) : "";
    const nl = st.pretty ? "\n" : "";
    const open = `<${tag2}${writeAttributes(tag2, props, st)}`;
    if (tag2 === "script") {
      reportRawScript(st);
      const parts = [];
      collectScriptText(props.children, parts);
      const code2 = parts.join("");
      const dash = code2.split("\n").findIndex((line) => line.includes("--"));
      if (dash !== -1) {
        throw new Error(`<script> content must not contain "--" (line ${dash + 1}: ${JSON.stringify(code2.split("\n")[dash].trim())})`);
      }
      push(st, code2 === "" ? `${indent}${open} />${nl}` : `${indent}${open}><!--
${code2}
--></script>${nl}`);
      return;
    }
    const slot2 = st.out.length;
    st.out.push("");
    const prevElement = st.element;
    st.element = tag2;
    st.depth++;
    try {
      walk(props.children, st);
    } finally {
      st.depth--;
      st.element = prevElement;
    }
    if (st.out.length === slot2 + 1) {
      st.out[slot2] = `${indent}${open} />${nl}`;
    } else {
      st.out[slot2] = `${indent}${open}>${nl}`;
      st.out.push(`${indent}</${tag2}>${nl}`);
    }
  }

  // ../gocontrolpanel/packages/maniatsx/dist/raw.js
  function raw(xml) {
    if (typeof xml !== "string")
      throw new TypeError("raw() expects a string");
    return Object.freeze({ $$typeof: RAW_XML, xml });
  }

  // ../gocontrolpanel/packages/maniatsx/dist/jsx-runtime.js
  function jsx(type, props, key) {
    return Object.freeze({ $$typeof: VNODE, type, props, key: key ?? null });
  }
  var jsxs = jsx;

  // ../gocontrolpanel/packages/maniatsx/dist/manialink.js
  var PROLOG = '<?xml version="1.0" encoding="utf-8" standalone="yes"?>';
  var SCOPE_KEY = /* @__PURE__ */ Symbol.for("maniatsx.manialink");
  var LIB = /^[\w./-]+$/;
  var ALIAS = /^[A-Za-z_]\w*$/;
  var DIRTY_MARK = "\0dirty\0";
  var clientFactory;
  function installClientExtension(factory) {
    clientFactory = factory;
  }
  function createScope() {
    const scope3 = {
      client: void 0,
      includes: /* @__PURE__ */ new Map(),
      libs: /* @__PURE__ */ new Set(),
      dirtyWrites: false,
      slots: {
        structs: [],
        globals: [],
        functions: [],
        refInit: [],
        stateInit: [],
        main: [],
        events: [],
        sync: [],
        loop: []
      },
      rawScript: false,
      onRawScript() {
        this.rawScript = true;
      }
    };
    const host = {
      part(slot2, code2, id) {
        const parts = scope3.slots[slot2];
        if (id !== void 0 && parts.some((part) => part.id === id))
          return;
        parts.push({ id, code: code2 });
      },
      lib(lib) {
        if (!LIB.test(lib))
          throw new Error(`invalid ManiaScript lib ${JSON.stringify(lib)}`);
        scope3.libs.add(lib);
        return `\0lib:${lib}\0`;
      },
      dirty: () => DIRTY_MARK,
      dirtyWrites(on) {
        scope3.dirtyWrites = on;
      }
    };
    scope3.client = clientFactory?.(host);
    return scope3;
  }
  function requireScope(name) {
    const scope3 = useRenderScope(SCOPE_KEY);
    if (!scope3)
      throw new Error(`<${name}> can only be used inside <Manialink>`);
    return scope3;
  }
  function flatten(src, name, out) {
    if (src === null || src === void 0 || src === false)
      return;
    if (typeof src === "string")
      out.push(dedent(src));
    else if (Array.isArray(src))
      for (const item of src)
        flatten(item, name, out);
    else if (src.$$typeof === MS_CODE)
      out.push(src.code);
    else
      throw new Error(`<${name}> children must be strings or ms code, got ${typeof src}`);
  }
  function trimBlankEdges(text) {
    return text.replace(/^([ \t]*\n)+/, "").replace(/(\n[ \t]*)+$/, "");
  }
  function makePart(slot2, name) {
    return function ScriptPart(props) {
      const scope3 = requireScope(name);
      if (props.id !== void 0 && typeof props.id !== "string") {
        throw new Error(`<${name}> id must be a string`);
      }
      const pieces = [];
      flatten(props.children, name, pieces);
      const code2 = trimBlankEdges(pieces.join("\n"));
      if (code2.trim() === "")
        return null;
      const parts = scope3.slots[slot2];
      if (props.id !== void 0 && parts.some((p) => p.id === props.id))
        return null;
      parts.push({ id: props.id, code: code2 });
      return null;
    };
  }
  function Include(props) {
    addInclude(requireScope("Script.Include"), props.lib, props.as);
    return null;
  }
  function addInclude(scope3, lib, alias) {
    if (typeof lib !== "string" || !LIB.test(lib)) {
      throw new Error(`<Script.Include> invalid lib ${JSON.stringify(lib)}`);
    }
    if (typeof alias !== "string" || !ALIAS.test(alias)) {
      throw new Error(`<Script.Include lib="${lib}"> invalid alias ${JSON.stringify(alias)}`);
    }
    const existing = scope3.includes.get(lib);
    if (existing !== void 0) {
      if (existing !== alias) {
        throw new Error(`<Script.Include> lib "${lib}" is already included as "${existing}", not "${alias}"`);
      }
      return;
    }
    for (const [otherLib, otherAlias] of scope3.includes) {
      if (otherAlias === alias) {
        throw new Error(`<Script.Include> alias "${alias}" is already used for lib "${otherLib}", not "${lib}"`);
      }
    }
    scope3.includes.set(lib, alias);
  }
  var Script = {
    Include,
    Globals: makePart("globals", "Script.Globals"),
    Functions: makePart("functions", "Script.Functions"),
    Main: makePart("main", "Script.Main"),
    Events: makePart("events", "Script.Events"),
    Loop: makePart("loop", "Script.Loop")
  };
  function indentBlock(parts, spaces) {
    const pad = " ".repeat(spaces);
    return parts.flatMap((p) => p.code.split("\n").map((line) => line.trim() === "" ? "" : pad + line));
  }
  function assemble(scope3, manialinkId) {
    for (const lib of scope3.libs)
      if (!scope3.includes.has(lib))
        addInclude(scope3, lib, lib);
    const { structs, globals, functions, refInit, stateInit, main, events, sync, loop } = scope3.slots;
    const count = scope3.includes.size + structs.length + globals.length + functions.length + refInit.length + stateInit.length + main.length + events.length + sync.length + loop.length;
    if (count === 0)
      return null;
    if (scope3.rawScript) {
      throw new Error(`<Manialink id="${manialinkId}"> mixes Script.* parts with a raw <script>; a page has one script`);
    }
    const lines = [];
    for (const [lib, alias] of scope3.includes)
      lines.push(`#Include "${lib}" as ${alias}`);
    lines.push(...indentBlock(structs, 0), ...indentBlock(globals, 0), ...indentBlock(functions, 0));
    if (functions.length === 0 && (globals.length > 0 || structs.length > 0))
      lines.push("Void Mtx_Noop() {}");
    lines.push("main() {", ...indentBlock(refInit, 2), ...indentBlock(stateInit, 2), ...indentBlock(main, 2), "  while (True) {", "    yield;");
    if (events.length > 0) {
      lines.push("    foreach (Event in PendingEvents) {", ...indentBlock(events, 6), "    }");
    }
    lines.push(...indentBlock(sync, 4), ...indentBlock(loop, 4), "  }", "}");
    const kept = scope3.dirtyWrites ? lines : lines.filter((line) => line.trim() !== DIRTY_MARK);
    return kept.join("\n").replaceAll(DIRTY_MARK, scope3.dirtyWrites ? "Mtx_Dirty = True;" : "").replace(/\0lib:(\w+)\0/g, (_, lib) => scope3.includes.get(lib));
  }
  function ManialinkBody(props) {
    const scope3 = createScope();
    const xml = renderChildren(props.children, { key: SCOPE_KEY, value: scope3 });
    scope3.client?.finish();
    const script = assemble(scope3, props.manialinkId);
    return [raw(xml), script === null ? null : jsx("script", { children: ms.raw(script) })];
  }
  function Manialink(props) {
    if (useRenderScope(SCOPE_KEY))
      throw new Error("<Manialink> cannot be nested inside another <Manialink>");
    if (typeof props.id !== "string" || props.id === "")
      throw new Error("<Manialink> requires an id");
    const element = jsx("manialink", {
      id: props.id,
      name: props.name,
      version: 3,
      layer: props.layer,
      children: jsx(ManialinkBody, { manialinkId: props.id, children: props.children })
    });
    return [props.prolog === false ? null : raw(PROLOG), element];
  }

  // ../gocontrolpanel/packages/maniatsx/dist/client/runtime.js
  var CLIENT_SCOPE = /* @__PURE__ */ Symbol.for("maniatsx.manialink");
  var literalText = (value) => ms`${value}`.code;
  function typeName(type) {
    if (typeof type === "string")
      return type;
    if ("array" in type)
      return `${typeName(type.array)}[]`;
    if ("record" in type)
      return `${typeName(type.record.value)}[${type.record.key}]`;
    return type.struct;
  }
  function emptyCollection(type, inner) {
    if (inner)
      throw new TypeError(`An empty ${typeName(type)} cannot be written inside an array or record literal`);
    return typeName(type);
  }
  var isEmptyCollection = (value, type) => typeof type === "object" && ("array" in type && Array.isArray(value) && value.length === 0 || "record" in type && !!value && typeof value === "object" && !Array.isArray(value) && Object.keys(value).length === 0);
  function literal2(value, type, inner = false) {
    if (typeof type !== "string") {
      if ("struct" in type) {
        if (!type.fields)
          throw new Error("struct values are not supported yet");
        if (!value || typeof value !== "object" || Array.isArray(value))
          throw new TypeError(`Expected ${type.struct} value`);
        const fields = type.fields.map((f) => [f, value[f.name]]).filter(([f, v]) => !isEmptyCollection(v, f.type)).map(([f, v]) => `${f.name} = ${literal2(v, f.type)}`);
        return fields.length ? `${type.struct} { ${fields.join(", ")} }` : `${type.struct} {}`;
      }
      if ("array" in type) {
        if (!Array.isArray(value))
          throw new TypeError("Expected an array");
        if (!value.length)
          return emptyCollection(type, inner);
        return `[${value.map((v) => literal2(v, type.array, true)).join(", ")}]`;
      }
      if (!value || typeof value !== "object" || Array.isArray(value))
        throw new TypeError("Expected a record");
      if (!Object.keys(value).length)
        return emptyCollection(type, inner);
      return `[${Object.entries(value).map(([k, v]) => `${literal2(type.record.key === "Integer" ? Number(k) : k, type.record.key)} => ${literal2(v, type.record.value, true)}`).join(", ")}]`;
    }
    switch (type) {
      case "Integer":
        return ms.int(value).code;
      case "Real":
        return ms.real(value).code;
      case "Boolean":
        if (typeof value === "boolean")
          return value ? "True" : "False";
        break;
      case "Text":
        if (typeof value === "string")
          return literalText(value);
        break;
      case "Ident":
        throw new TypeError("Ident values are not supported yet");
      case "Vec2":
      case "Vec3":
      case "Int2":
      case "Int3": {
        if (!value || typeof value !== "object")
          break;
        const v = value;
        const component = type.startsWith("Int") ? ms.int : ms.real;
        return `<${["X", "Y", ...type.endsWith("3") ? ["Z"] : []].map((k) => component(v[k]).code).join(", ")}>`;
      }
    }
    throw new TypeError(`Expected ${type} value`);
  }
  function hash(text) {
    let h = 2166136261;
    for (let i = 0; i < text.length; i++)
      h = Math.imul(h ^ text.charCodeAt(i), 16777619);
    return (h >>> 0).toString(16).padStart(8, "0");
  }
  var SHARED_KEY = /^[A-Za-z]\w*$/;
  var SHARED_SUFFIX = /_(V|Seen)$/;
  function checkSharedKey(key, site) {
    if (!SHARED_KEY.test(key) || SHARED_SUFFIX.test(key))
      throw new Error(`client.shared at ${site}: invalid key ${JSON.stringify(key)}; use letters, digits and "_", starting with a letter and not ending in _V or _Seen`);
  }
  var DIRTY_WRITE = /\bMtx_Dirty = True;/g;
  var ClientScope = class {
    host;
    states = /* @__PURE__ */ new Map();
    persistedNames = /* @__PURE__ */ new Set();
    stateCount = 0;
    // Persisted states read by the code being filled: each function body must re-bind them
    used = [];
    shareds = /* @__PURE__ */ new Map();
    refs = /* @__PURE__ */ new Map();
    attached = /* @__PURE__ */ new Map();
    functions = /* @__PURE__ */ new Set();
    handlers = /* @__PURE__ */ new Map();
    eventHandlers = /* @__PURE__ */ new Map();
    elementCount = 0;
    controlCount = 0;
    dirty = false;
    constructor(host) {
      this.host = host;
    }
    // Bindings are the only readers of the flag, so only they turn it on
    ensureDirty() {
      if (!this.dirty) {
        this.dirty = true;
        this.host.part("globals", "declare Boolean Mtx_Dirty;");
      }
    }
    // Fills code that becomes a function body and returns the declarations that re-bind its persisted states
    body(code2, indent = "") {
      const used = /* @__PURE__ */ new Set();
      this.used.push(used);
      try {
        const text = this.fill(code2);
        const declares = [...used].map((s) => s.kind === "shared" ? `${indent}declare ${typeName(s.type)} ${this.shareds.get(s.key).name} for This;
` : `${indent}declare ${typeName(s.type)} ${this.states.get(s)} for Page;
`).join("");
        return { text, declares };
      } finally {
        this.used.pop();
      }
    }
    fill(code2) {
      if (code2.code.length !== code2.holes.length + 1)
        throw new Error(`Invalid compiled code at ${code2.site}`);
      for (const struct of code2.structs)
        this.host.part("structs", struct, struct);
      let result = code2.code[0];
      code2.holes.forEach((hole, i) => {
        let value;
        switch (hole.kind) {
          case "value":
            value = literal2(hole.get(), hole.type);
            break;
          case "state":
            value = this.state(hole.get());
            break;
          case "shared":
            value = this.read(hole.get());
            break;
          case "ref":
            value = this.ref(hole.get());
            break;
          case "action":
            value = literalText(hole.get().name);
            break;
          case "fn":
            value = this.fn(hole.get());
            break;
          case "lib":
            value = this.host.lib(hole.lib);
            break;
        }
        result += value + code2.code[i + 1];
      });
      return result.replace(DIRTY_WRITE, () => this.host.dirty());
    }
    state(state) {
      if (state.persist)
        this.used.at(-1)?.add(state);
      let name = this.states.get(state);
      if (name)
        return name;
      if (state.persist)
        return this.persisted(state);
      name = `Mtx_S${++this.stateCount}`;
      this.states.set(state, name);
      this.host.part("globals", `declare ${typeName(state.type)} ${name};`);
      this.host.part("stateInit", `${name} = ${this.fill(state.initial)};`, `state:${name}`);
      return name;
    }
    sharedInfo(shared) {
      checkSharedKey(shared.key, shared.site);
      let info = this.shareds.get(shared.key);
      if (!info) {
        info = {
          shared,
          name: `Mtx_X_${shared.key}`,
          read: false,
          published: false,
          watchers: []
        };
        this.shareds.set(shared.key, info);
      } else if (typeName(info.shared.type) !== typeName(shared.type))
        throw new Error(`client.shared key "${shared.key}" is declared with two types (${typeName(info.shared.type)} at ${info.shared.site}, ${typeName(shared.type)} at ${shared.site}); a key has one type`);
      return info;
    }
    // Reading code (bindings, handlers, lifecycle, fns); function bodies re-declare it like persisted state
    read(shared) {
      const info = this.sharedInfo(shared);
      info.read = true;
      this.used.at(-1)?.add(shared);
      return info.name;
    }
    watch(shared, code2) {
      const info = this.sharedInfo(shared);
      info.read = true;
      const { text, declares } = this.body(code2);
      const body = declares + text;
      const name = this.handler(body);
      if (!info.watchers.includes(name))
        info.watchers.push(name);
    }
    publish(shared, value) {
      const info = this.sharedInfo(shared);
      info.published = true;
      this.host.part("main", `${info.name} = ${literal2(value, shared.type)};
${info.name}_V += 1;`);
    }
    // Deduped function for a handler or watcher body
    handler(body) {
      let name = this.handlers.get(body);
      if (!name) {
        name = `Mtx_H${this.handlers.size + 1}`;
        this.handlers.set(body, name);
        this.host.part("functions", `Void ${name}() {
${body}
}`);
      }
      return name;
    }
    // Deduped function for an on* handler body; it receives the event
    eventHandler(body) {
      let name = this.eventHandlers.get(body);
      if (!name) {
        name = `Mtx_E${this.eventHandlers.size + 1}`;
        this.eventHandlers.set(body, name);
        this.host.part("functions", `Void ${name}(CMlScriptEvent Event) {
${body}
}`);
      }
      return name;
    }
    // Declarations and version tracking, emitted once the page's bindings are known
    finishShared() {
      for (const info of this.shareds.values()) {
        const type = typeName(info.shared.type);
        const tracked = info.read && (info.watchers.length > 0 || this.dirty);
        for (const struct of info.shared.initial.structs)
          this.host.part("structs", struct, struct);
        this.host.part("stateInit", info.read ? `declare ${type} ${info.name} for This = ${this.fill(info.shared.initial)};` : `declare ${type} ${info.name} for This;`, `shared:${info.name}`);
        if (!tracked && !info.published)
          continue;
        this.host.part("stateInit", `declare Integer ${info.name}_V for This;`);
        if (!tracked)
          continue;
        this.host.part("globals", `declare Integer ${info.name}_Seen;`);
        this.host.part("sync", [
          `if (${info.name}_V != ${info.name}_Seen) {`,
          `  ${info.name}_Seen = ${info.name}_V;`,
          `  ${this.host.dirty()}`,
          ...info.watchers.map((w) => `  ${w}();`),
          "}"
        ].join("\n"));
      }
    }
    // `declare … for Page = init;` in main applies init once; function bodies re-bind it without a value
    persisted(state) {
      const { key, keyPrefix } = state.persist;
      let name;
      if (key !== void 0) {
        if (!/^[A-Za-z]\w*$/.test(key))
          throw new Error(`client.state at ${state.site}: invalid persist key ${JSON.stringify(key)}`);
        name = `Mtx_P_${keyPrefix ? `${keyPrefix}_${key}`.replace(/\W/g, "") : key}`;
        if (this.persistedNames.has(name))
          throw new Error(`client.state at ${state.site}: persist key "${key}" is used twice on this page; keys must be unique`);
      } else {
        const stem = state.site.replace(/:\d+:\d+$/, "").split("/").pop().replace(/\.\w+$/, "");
        const base = `Mtx_P_${keyPrefix ? `${keyPrefix}_`.replace(/\W/g, "") : ""}${stem.replace(/\W/g, "") || "state"}_${hash(state.site)}`;
        name = base;
        for (let n = 2; this.persistedNames.has(name); n++)
          name = `${base}_${n}`;
      }
      this.persistedNames.add(name);
      this.states.set(state, name);
      this.used.push(/* @__PURE__ */ new Set());
      try {
        this.host.part("stateInit", `declare ${typeName(state.type)} ${name} for Page = ${this.fill(state.initial)};`, `state:${name}`);
      } finally {
        this.used.pop();
      }
      return name;
    }
    // Global of a ref used in client code; its init is emitted in finish(), once attachment is known
    ref(ref) {
      let name = this.refs.get(ref);
      if (name)
        return name;
      if (!/^[A-Za-z]\w*$/.test(ref.cls))
        throw new Error(`Invalid control class at ${ref.site}`);
      name = `Mtx_R${this.refs.size + 1}`;
      this.refs.set(ref, name);
      this.host.part("globals", `declare ${ref.cls} ${name};`);
      return name;
    }
    fn(fn) {
      if (!this.functions.has(fn.name)) {
        this.functions.add(fn.name);
        const { text, declares } = this.body(fn.declaration, "  ");
        const open = text.indexOf("{\n") + 2;
        this.host.part("functions", declares && open > 1 ? text.slice(0, open) + declares + text.slice(open) : text, `fn:${fn.name}`);
      }
      return fn.name;
    }
    lifecycle(slot2, code2) {
      this.host.part(slot2, this.fill(code2));
    }
    element(tag2, props) {
      const entries = Object.entries(props).filter((entry) => isClient(entry[1]));
      if (!entries.length)
        return props;
      const out = { ...props };
      const id = out.id === void 0 ? `mtx-${++this.elementCount}` : out.id;
      if (typeof id !== "string" || !id)
        throw new Error(`<${tag2}> client props require a string id`);
      out.id = id;
      const events = {
        onClick: "MouseClick",
        onRightClick: "MouseRightClick",
        onMouseOver: "MouseOver",
        onMouseOut: "MouseOut",
        onSubmit: "EntrySubmit"
      };
      const bindings = {
        label: { text: "Value", hidden: "Visible", pos: "RelativePosition_V3", opacity: "Opacity" },
        quad: {
          hidden: "Visible",
          pos: "RelativePosition_V3",
          opacity: "Opacity",
          image: "ChangeImageUrl",
          bgcolor: "BgColor"
        },
        gauge: { hidden: "Visible", pos: "RelativePosition_V3", ratio: "Ratio" },
        entry: { hidden: "Visible", pos: "RelativePosition_V3", default: "Value" }
      };
      let control;
      for (const [attr, handle] of entries) {
        delete out[attr];
        if (handle.kind === "ref" && attr === "ref") {
          const ref = handle;
          const prior = this.attached.get(ref);
          if (prior)
            throw new Error(`client.ref declared at ${ref.site} is attached to two elements (<${prior.tag} id="${prior.id}"> and <${tag2} id="${id}">); a ref points at one control`);
          this.attached.set(ref, { tag: tag2, id });
        } else if (handle.kind === "handler" && events[attr] && (attr !== "onSubmit" || tag2 === "entry" || tag2 === "textedit")) {
          out.scriptevents = true;
          const { text, declares } = this.body(handle.body);
          const name = this.eventHandler(declares + text);
          this.host.part("events", `if (Event.Type == CMlScriptEvent::Type::${events[attr]} && Event.ControlId == ${literalText(id)}) ${name}(Event);`);
        } else if (handle.kind === "bind" && bindings[tag2]?.[attr]) {
          this.ensureDirty();
          if (!control) {
            control = `Mtx_C${++this.controlCount}`;
            const cls = `CMl${tag2[0].toUpperCase()}${tag2.slice(1)}`;
            this.host.part("main", `declare ${cls} ${control} <=> (Page.GetFirstChild(${literalText(id)}) as ${cls});`);
          }
          const binding = handle;
          let expr = this.fill(binding.expr);
          if (attr === "bgcolor" && binding.type === "Text") {
            expr = `${this.host.lib("ColorLib")}::HexToRgb(${expr})`;
          }
          const property = bindings[tag2][attr];
          const update = property === "ChangeImageUrl" ? `${control}.${property}(${expr});` : `${control}.${property} = ${attr === "hidden" ? `!(${expr})` : expr};`;
          this.host.part("main", update);
          this.host.part("loop", `if (Mtx_Dirty) { ${update} }`);
        } else
          throw new Error(`<${tag2}> attribute "${attr}": unsupported client ${handle.kind}`);
      }
      return out;
    }
    finish() {
      for (const [ref, name] of this.refs) {
        const target = this.attached.get(ref);
        if (!target)
          throw new Error(`client.ref declared at ${ref.site} is used in client code but never attached to an element in this <Manialink>; add ref={...} to one`);
        this.host.part("refInit", `${name} <=> (Page.MainFrame.GetFirstChild(${literalText(target.id)}) as ${ref.cls});`);
      }
      this.finishShared();
      this.host.dirtyWrites(this.dirty);
      if (this.dirty) {
        this.host.part("main", "Mtx_Dirty = True;");
        this.host.part("loop", "Mtx_Dirty = False;");
      }
    }
  };
  function isClient(value) {
    return typeof value === "object" && value !== null && value.$$typeof === CLIENT;
  }
  function scope() {
    const found = useRenderScope(CLIENT_SCOPE)?.client;
    if (!found)
      throw new Error("Client handles can only be used inside <Manialink>");
    return found;
  }
  function Publish(props) {
    if (!isClient(props.to) || props.to.kind !== "shared")
      throw new Error("<Publish> `to` must be a client.shared handle");
    scope().publish(props.to, props.value);
    return null;
  }
  var __mtx = {
    shared: (key, type, initial, site) => ({
      $$typeof: CLIENT,
      kind: "shared",
      key,
      type,
      initial,
      site,
      value: void 0
    }),
    watch: (shared, body) => scope().watch(shared, body),
    ref: (cls, site) => ({ $$typeof: CLIENT, kind: "ref", cls, site, control: void 0 }),
    state: (type, initial, site, options) => ({
      $$typeof: CLIENT,
      kind: "state",
      type,
      initial,
      site,
      ...options?.persist && {
        persist: {
          ...options.key === void 0 ? {} : { key: options.key },
          ...options.keyPrefix && { keyPrefix: options.keyPrefix }
        }
      },
      value: void 0
    }),
    handler: (body) => ({ $$typeof: CLIENT, kind: "handler", body }),
    bind: (type, expr) => ({ $$typeof: CLIENT, kind: "bind", type, expr }),
    fn: (name, declaration) => ({ $$typeof: CLIENT, kind: "fn", name, declaration }),
    onInit: (body) => scope().lifecycle("main", body),
    onFrame: (body) => scope().lifecycle("loop", body)
  };
  installClientExtension((host) => new ClientScope(host));

  // ../gocontrolpanel/packages/shared/src/themes/registry.ts
  var DEFAULT_TOKENS = {
    color: {
      surface: "222",
      surfaceAlt: "333",
      content: "DDD",
      contentAlt: "CCC",
      text: "DDD",
      textMuted: "CCC",
      contentText: "222",
      contentTextMuted: "333",
      accent: "DDD"
    },
    font: { body: "GameFontRegular", title: "GameFontSemiBold" },
    opacity: { panel: 0.85 }
  };
  var registry = [
    { id: "default", name: "Default", tokens: DEFAULT_TOKENS }
  ];
  var DEFAULT_PRESET_ID = "default";
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function clone(value) {
    if (Array.isArray(value)) return value.map(clone);
    if (isRecord(value))
      return Object.fromEntries(
        Object.entries(value).map(([key, item]) => [key, clone(item)])
      );
    return value;
  }
  function deepMerge(base, patch) {
    if (Array.isArray(patch)) return clone(patch);
    if (!isRecord(base) || !isRecord(patch)) return clone(patch);
    const result = { ...base };
    for (const [key, value] of Object.entries(patch)) {
      result[key] = key in base ? deepMerge(base[key], value) : clone(value);
    }
    return result;
  }
  function resolveFrom(definitions, id) {
    const byId = new Map(
      definitions.map((definition) => [definition.id, definition])
    );
    const selected = byId.get(id) ?? byId.get(DEFAULT_PRESET_ID);
    const lineage = [];
    let current2 = selected;
    const seen = /* @__PURE__ */ new Set();
    while (current2) {
      if (seen.has(current2.id))
        throw new Error(`Theme preset cycle at "${current2.id}"`);
      seen.add(current2.id);
      lineage.push(current2);
      current2 = current2.extends ? byId.get(current2.extends) : void 0;
    }
    if (lineage.at(-1)?.id !== DEFAULT_PRESET_ID)
      throw new Error(`Theme preset "${id}" must extend "${DEFAULT_PRESET_ID}"`);
    let tokens = clone(DEFAULT_TOKENS);
    const text = {};
    const layout = {};
    for (const definition of lineage.reverse()) {
      tokens = deepMerge(tokens, definition.tokens);
      Object.assign(text, definition.text);
      for (const [key, value] of Object.entries(definition.layout ?? {}))
        layout[key] = { ...layout[key], ...value };
    }
    return {
      id: selected.id,
      name: selected.name,
      chain: lineage.map((item) => item.id).reverse(),
      tokens,
      text,
      layout
    };
  }
  function resolvePreset(id) {
    return resolveFrom(registry, id);
  }

  // ../gocontrolpanel/packages/maniatsx/dist/theme.js
  var slotContext = createContext(null);
  var namedSlots = /* @__PURE__ */ new Set();
  function cloneMerge(base, patch) {
    if (Array.isArray(patch))
      return patch.map((value) => cloneValue(value));
    if (Array.isArray(base) || !isRecord2(base) || !isRecord2(patch)) {
      return cloneValue(patch);
    }
    const result = { ...base };
    for (const [key, value] of Object.entries(patch)) {
      result[key] = key in base ? cloneMerge(base[key], value) : cloneValue(value);
    }
    return result;
  }
  function cloneValue(value) {
    if (Array.isArray(value))
      return value.map(cloneValue);
    if (isRecord2(value))
      return Object.fromEntries(Object.entries(value).map(([key, child]) => [key, cloneValue(child)]));
    return value;
  }
  function isRecord2(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function freeze(value) {
    if (isRecord2(value) || Array.isArray(value)) {
      for (const child of Object.values(value))
        freeze(child);
      Object.freeze(value);
    }
    return value;
  }
  function mergeKeyed(base, patch) {
    return { ...base, ...patch };
  }
  function mergeLayout(base, patch) {
    const result = { ...base };
    for (const [key, value] of Object.entries(patch ?? {}))
      result[key] = { ...result[key], ...value };
    return result;
  }
  function mergeComponents(parent, child = []) {
    const result = new Map(parent.map((entry) => [entry.slotId, entry]));
    for (const entry of child)
      result.set(entry.slotId, entry);
    return [...result.values()];
  }
  function slot(name, Default, variants = {}) {
    if (namedSlots.has(name))
      throw new Error(`Duplicate theme slot name "${name}"`);
    namedSlots.add(name);
    const slotId = Symbol(name);
    const Slot = Object.assign((props) => {
      const active = useContext(slotContext);
      const custom = active?.components.find((entry) => entry.slotId === slotId);
      if (custom)
        return custom.component({ ...props, Default });
      const variant = active?.chain.map((id) => variants[id]).find((value) => value !== void 0);
      return (variant ?? Default)(props);
    }, { slotName: name, slotId, Default, variants });
    return Slot;
  }
  function createThemeKit(definition) {
    const themes = /* @__PURE__ */ new Map();
    const make = (def, parent) => {
      if (themes.has(def.id))
        throw new Error(`Duplicate theme id "${def.id}"`);
      if (def.extends && themes.get(def.extends.id) !== def.extends) {
        throw new Error(`Theme "${def.id}" extends a theme from another kit`);
      }
      const actualParent = def.extends ?? parent;
      const theme = freeze({
        id: def.id,
        name: def.name,
        chain: Object.freeze([def.id, ...actualParent?.chain ?? []]),
        tokens: cloneMerge(actualParent?.tokens ?? def.tokens, def.tokens ?? {}),
        text: mergeKeyed(actualParent?.text ?? {}, def.text),
        layout: mergeLayout(actualParent?.layout ?? {}, def.layout),
        components: mergeComponents(actualParent?.components ?? [], def.components)
      });
      themes.set(def.id, theme);
      return theme;
    };
    const base = make(definition);
    const themeContext = createContext(base);
    const wrappedProvider = ({ theme, children }) => {
      const isData = !("components" in theme);
      if (isData && (typeof theme.id !== "string" || !Array.isArray(theme.chain) || theme.chain[0] !== theme.id))
        throw new Error("Invalid ThemeData: expected a string id and a chain starting with that id.");
      const components = isData ? [] : theme.components;
      return jsx(themeContext.Provider, {
        value: theme,
        children: jsx(slotContext.Provider, {
          value: { chain: theme.chain, components, layout: theme.layout },
          children
        })
      });
    };
    return {
      base,
      toData: (theme) => structuredClone({
        id: theme.id,
        name: theme.name,
        chain: theme.chain,
        tokens: theme.tokens,
        text: theme.text,
        layout: theme.layout
      }),
      defineTheme: (def) => make(def, def.extends ?? base),
      themes: () => Object.freeze([...themes.values()]),
      useTokens: () => useContext(themeContext).tokens,
      useText: (key, fallback = key) => useContext(themeContext).text[key] ?? fallback,
      useTheme: () => useContext(themeContext),
      ThemeProvider: wrappedProvider
    };
  }

  // @tmcontrolpanel/plugin-sdk/src/ui/theme.ts
  var defaultTheme = resolvePreset("default");
  var kit = createThemeKit({
    id: defaultTheme.id,
    name: defaultTheme.name,
    tokens: defaultTheme.tokens,
    text: defaultTheme.text
  });
  var toKitTheme = (theme) => theme;

  // @tmcontrolpanel/plugin-sdk/src/render.tsx
  function renderComponent(Component, props, theme) {
    return render(
      /* @__PURE__ */ jsx(kit.ThemeProvider, { theme: toKitTheme(theme), children: /* @__PURE__ */ jsx(Component, { ...props }) })
    );
  }

  // @tmcontrolpanel/plugin-sdk/src/ui/install.ts
  var scope2 = globalThis;
  if (typeof scope2.__tmcpRegister === "function" && !scope2.__tmcpUiInstalled) {
    scope2.__tmcpUiInstalled = true;
    const register = scope2.__tmcpRegister;
    scope2.__tmcpRegister = (value) => {
      const definition = value;
      register({
        ...definition,
        create(ctx) {
          const theme = () => ctx.ui.themeData();
          const toRender = ({ component, updateComponent, ...rest }) => ({
            ...rest,
            render: (props) => renderComponent(component, props, theme()),
            renderUpdate: updateComponent ? (props) => renderComponent(updateComponent, props, theme()) : void 0
          });
          const ui = {
            ...ctx.ui,
            action: (name) => action(`${ctx.ui.actionPrefix()}${name}`),
            widget(options) {
              if (!options.component) return ctx.ui.widget(options);
              return ctx.ui.widget(toRender(options));
            },
            window(options) {
              if (!options.component) return ctx.ui.window(options);
              return ctx.ui.window(toRender(options));
            }
          };
          return definition.create({ ...ctx, ui });
        }
      });
    };
  }

  // @tmcontrolpanel/plugin-sdk/src/ui/label.tsx
  var Label = slot("ui/label", ({ tone, font, ...rest }) => {
    const tokens = kit.useTokens();
    return /* @__PURE__ */ jsx(
      "label",
      {
        ...rest,
        textcolor: tokens.color[tone],
        textfont: font ? tokens.font[font] : void 0
      }
    );
  });

  // @tmcontrolpanel/plugin-sdk/src/ui/page.tsx
  function Page(props) {
    return /* @__PURE__ */ jsx(Manialink, { id: props.id, name: `TMCP:${props.id}`, children: props.children });
  }
  function ScriptPrelude() {
    return /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx(Script.Include, { lib: "MathLib", as: "ML" }),
      /* @__PURE__ */ jsx(Script.Include, { lib: "TextLib", as: "TL" }),
      /* @__PURE__ */ jsx(Script.Include, { lib: "TimeLib", as: "TimeLib" }),
      /* @__PURE__ */ jsx(Script.Include, { lib: "ColorLib", as: "CL" }),
      /* @__PURE__ */ jsx(Script.Events, { id: "skip-controlless-events", children: "if (Event.Control == Null) continue;" })
    ] });
  }

  // @tmcontrolpanel/plugin-sdk/src/ui/panel.tsx
  var Panel = slot("ui/panel", ({ tone, ...rest }) => {
    const { color } = kit.useTokens();
    return /* @__PURE__ */ jsx("quad", { ...rest, bgcolor: color[tone] });
  });

  // @tmcontrolpanel/plugin-sdk/src/ui/table.tsx
  var PREV = " Prev";
  var NEXT = "Next ";
  var UiTable = slot(
    "ui/table",
    ({ table, prevAction, nextAction, pos }) => {
      const { color, font } = kit.useTokens();
      const { width, rowHeight, textY, pagerY } = table;
      const height = -(pagerY - 6);
      return /* @__PURE__ */ jsxs("frame", { pos: pos ?? [0, 0], size: [width, height], children: [
        /* @__PURE__ */ jsx(Panel, { tone: "surface", pos: [0, 0], size: [width, rowHeight] }),
        table.columns.map((column) => /* @__PURE__ */ jsx(
          Label,
          {
            tone: "text",
            font: "title",
            pos: [column.x, textY],
            size: [column.width, rowHeight],
            text: column.title,
            halign: column.halign,
            valign: "center2",
            textsize: 0.9
          }
        )),
        table.rows.length === 0 ? /* @__PURE__ */ jsx(
          Label,
          {
            tone: "contentText",
            font: "body",
            pos: [width / 2, -rowHeight * 2],
            size: [width, rowHeight],
            text: table.empty,
            halign: "center",
            valign: "center2",
            textsize: 1,
            opacity: 0.6
          }
        ) : table.rows.map((row) => /* @__PURE__ */ jsxs("frame", { pos: [0, row.y], size: [width, rowHeight], children: [
          row.odd && /* @__PURE__ */ jsx(
            Panel,
            {
              tone: "contentAlt",
              pos: [0, 0],
              size: [width, rowHeight],
              opacity: 0.6
            }
          ),
          row.cells.map((cell) => /* @__PURE__ */ jsx(
            "label",
            {
              pos: [cell.x, textY],
              size: [cell.width, rowHeight],
              text: cell.text,
              halign: cell.halign,
              valign: "center2",
              textsize: 0.9,
              textfont: font.body,
              textcolor: cell.color ?? color.contentText
            }
          ))
        ] })),
        table.pages !== 1 && /* @__PURE__ */ jsxs("frame", { pos: [0, pagerY], size: [width, 5], children: [
          /* @__PURE__ */ jsx(
            Panel,
            {
              tone: "surface",
              pos: [0, 0],
              size: [width, 0.25],
              opacity: 0.4
            }
          ),
          /* @__PURE__ */ jsx(
            Label,
            {
              tone: "contentText",
              font: "body",
              pos: [1, -3],
              size: [width - 30, 4],
              text: `${table.from}-${table.to} of ${table.total}`,
              valign: "center2",
              textsize: 0.9,
              opacity: 0.7
            }
          ),
          /* @__PURE__ */ jsx(
            Label,
            {
              tone: "contentText",
              font: "title",
              pos: [width - 22, -3],
              size: [10, 4],
              text: PREV,
              halign: "center",
              valign: "center2",
              textsize: 0.9,
              ...table.hasPrev ? {
                action: prevAction,
                focusareacolor1: color.textMuted,
                focusareacolor2: color.text
              } : { opacity: 0.3 }
            }
          ),
          /* @__PURE__ */ jsx(
            Label,
            {
              tone: "contentText",
              font: "body",
              pos: [width - 14, -3],
              size: [6, 4],
              text: `${table.page}/${table.pages}`,
              halign: "center",
              valign: "center2",
              textsize: 0.9
            }
          ),
          /* @__PURE__ */ jsx(
            Label,
            {
              tone: "contentText",
              font: "title",
              pos: [width - 6, -3],
              size: [10, 4],
              text: NEXT,
              halign: "center",
              valign: "center2",
              textsize: 0.9,
              ...table.hasNext ? {
                action: nextAction,
                focusareacolor1: color.textMuted,
                focusareacolor2: color.text
              } : { opacity: 0.3 }
            }
          )
        ] })
      ] });
    }
  );

  // @tmcontrolpanel/plugin-sdk/src/ui/widget-hide.tsx
  function HideWhileDriving(props) {
    return /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx(Script.Globals, { id: "hide-while-driving", children: ms`
        declare Vec2 widgetBasePosition;
        declare CMlFrame HS_Target;
        declare Boolean HS_Hidden;
      ` }),
      /* @__PURE__ */ jsx(Script.Functions, { id: "hide-while-driving", children: ms`
        Void hs_hide(Integer duration) {
          HS_Hidden = True;
          declare Real x;
          if (widgetBasePosition[0] < 0.0) {
            x = (HS_Target.Size[0] * -HS_Target.RelativeScale) - 322.0;
          } else {
            x = 322.0;
          }
          AnimMgr.Add(HS_Target, "<frame pos='" ^ x ^ " " ^ widgetBasePosition[1] ^ "' />", duration, CAnimManager::EAnimManagerEasing::ExpInOut);
        }

        Void hs_show(Integer duration) {
          HS_Hidden = False;
          AnimMgr.Add(HS_Target, "<frame pos='" ^ widgetBasePosition[0] ^ " " ^ widgetBasePosition[1] ^ "' />", duration, CAnimManager::EAnimManagerEasing::CircOut);
        }

        Void hidescript() {
          if (HS_Target == Null) {
            HS_Target <=> (Page.MainFrame.GetFirstChild(${props.target}) as CMlFrame);
          }

          declare hideSpeed = 10;

          if (InputPlayer == Null) {
            if (HS_Hidden) {
              hs_show(600);
            }
            return;
          }

          declare Boolean overHidespeed = ML::Abs(InputPlayer.Speed * 3.6) > hideSpeed;

          if (overHidespeed && !HS_Hidden) {
            hs_hide(1000);

            while (InputPlayer.Speed * 3.6 > hideSpeed) {
              yield;
              hidescript();
            }
          }

          if (!overHidespeed && HS_Hidden) {
            sleep(1000);
            hs_show(600);
          }
        }
      ` }),
      props.active !== false && /* @__PURE__ */ jsx(Script.Loop, { id: "hide-while-driving", children: "hidescript();" })
    ] });
  }

  // @tmcontrolpanel/plugin-sdk/src/ui/widget.tsx
  function WidgetFrame(props) {
    const p = props.position;
    const pos = "x" in p ? [p.x, p.y] : p;
    return /* @__PURE__ */ jsxs(Page, { id: props.id, children: [
      /* @__PURE__ */ jsx(ScriptPrelude, {}),
      /* @__PURE__ */ jsx(Script.Globals, { id: "widget", children: "declare CMlFrame widget;" }),
      /* @__PURE__ */ jsx(Script.Main, { id: "widget", children: `
        widget <=> (Page.MainFrame.GetFirstChild("widget") as CMlFrame);
        widgetBasePosition = widget.AbsolutePosition_V3;

        sleep(300);
        widget.Show();
      ` }),
      /* @__PURE__ */ jsx("frame", { id: "widget", pos, "z-index": 10, hidden: true, children: props.children }),
      /* @__PURE__ */ jsx(HideWhileDriving, { target: "widget", active: props.hideWhileDriving })
    ] });
  }

  // @tmcontrolpanel/plugin-sdk/src/ui/window.tsx
  var CLOSE_ICON = "";
  var WindowFrame = slot("ui/window", (props) => {
    const [width, height] = props.size;
    const color = kit.useTokens().color;
    return /* @__PURE__ */ jsxs(
      "frame",
      {
        id: "window",
        pos: [-width / 2, height / 2],
        size: [width, height + 5],
        "z-index": 20,
        children: [
          /* @__PURE__ */ jsx(Panel, { tone: "surface", pos: [0, 0], size: [width, 5] }),
          /* @__PURE__ */ jsx(
            Label,
            {
              tone: "text",
              font: "title",
              pos: [1.5, -2.25],
              text: props.title,
              size: [width - 9.5, 5],
              valign: "center",
              halign: "left",
              textsize: 1
            }
          ),
          /* @__PURE__ */ jsx(
            Label,
            {
              tone: "text",
              pos: [width - 1.5, -2.25],
              text: CLOSE_ICON,
              size: [5, 5],
              valign: "center",
              halign: "right",
              textsize: 1,
              action: `close-window-${props.id}`,
              focusareacolor2: `${color.text}0`
            }
          ),
          /* @__PURE__ */ jsx(Panel, { tone: "content", pos: [0, -5], size: [width, height] }),
          /* @__PURE__ */ jsx("frame", { pos: [0, -5], size: [width, height], children: props.children })
        ]
      }
    );
  });

  // plugins/match/src/ui.tsx
  var maps = __mtx.shared("match_pickban_maps", { "array": { "struct": "K_MapInfo", "fields": [{ "name": "name", "type": "Text" }, { "name": "author", "type": "Text" }, { "name": "uid", "type": "Text" }, { "name": "index", "type": "Integer" }, { "name": "selectedBy", "type": { "array": "Text" } }, { "name": "pickedBy", "type": "Text" }, { "name": "bannedBy", "type": "Text" }] } }, { code: ["", ""], holes: [{ kind: "value", type: { "array": { "struct": "K_MapInfo", "fields": [{ "name": "name", "type": "Text" }, { "name": "author", "type": "Text" }, { "name": "uid", "type": "Text" }, { "name": "index", "type": "Integer" }, { "name": "selectedBy", "type": { "array": "Text" } }, { "name": "pickedBy", "type": "Text" }, { "name": "bannedBy", "type": "Text" }] } }, get: () => [] }], structs: ["#Struct K_MapInfo {\n  Text name;\n  Text author;\n  Text uid;\n  Integer index;\n  Text[] selectedBy;\n  Text pickedBy;\n  Text bannedBy;\n}"], site: "src/ui.tsx:40:14" }, "src/ui.tsx:40:14");
  var turn = __mtx.shared("match_pickban_turn", { "struct": "K_Turn", "fields": [{ "name": "action", "type": "Text" }, { "name": "login", "type": "Text" }, { "name": "players", "type": { "array": "Text" } }, { "name": "nickName", "type": "Text" }, { "name": "timeoutSeconds", "type": "Integer" }] }, { code: ["", ""], holes: [{ kind: "value", type: { "struct": "K_Turn", "fields": [{ "name": "action", "type": "Text" }, { "name": "login", "type": "Text" }, { "name": "players", "type": { "array": "Text" } }, { "name": "nickName", "type": "Text" }, { "name": "timeoutSeconds", "type": "Integer" }] }, get: () => ({
    action: "done",
    login: "",
    players: [],
    nickName: "",
    timeoutSeconds: 0
  }) }], structs: ["#Struct K_Turn {\n  Text action;\n  Text login;\n  Text[] players;\n  Text nickName;\n  Integer timeoutSeconds;\n}"], site: "src/ui.tsx:41:14" }, "src/ui.tsx:41:14");
  var mapFrame = __mtx.ref("CMlFrame", "src/ui.tsx:48:18");
  var actionFrame = __mtx.ref("CMlFrame", "src/ui.tsx:49:21");
  var timerStart = __mtx.state("Integer", { code: ["", ""], holes: [{ kind: "value", type: "Integer", get: () => 0 }], structs: [], site: "src/ui.tsx:50:20" }, "src/ui.tsx:50:20", {});
  var lastSecond = __mtx.state("Integer", { code: ["", ""], holes: [{ kind: "value", type: "Integer", get: () => -1 }], structs: [], site: "src/ui.tsx:51:20" }, "src/ui.tsx:51:20", {});
  var completedAt = __mtx.state("Integer", { code: ["", ""], holes: [{ kind: "value", type: "Integer", get: () => -1 }], structs: [], site: "src/ui.tsx:52:21" }, "src/ui.tsx:52:21", {});
  var completionAnimated = __mtx.state("Boolean", { code: ["", ""], holes: [{ kind: "value", type: "Boolean", get: () => false }], structs: [], site: "src/ui.tsx:53:28" }, "src/ui.tsx:53:28", {});
  var selectedMapIndex = __mtx.state("Integer", { code: ["", ""], holes: [{ kind: "value", type: "Integer", get: () => -1 }], structs: [], site: "src/ui.tsx:54:26" }, "src/ui.tsx:54:26", {});
  var selectionVisible = __mtx.state("Boolean", { code: ["", ""], holes: [{ kind: "value", type: "Boolean", get: () => false }], structs: [], site: "src/ui.tsx:55:26" }, "src/ui.tsx:55:26", {});
  var pickAction = __mtx.shared("match_pickban_action", "Text", { code: ["", ""], holes: [{ kind: "value", type: "Text", get: () => "" }], structs: [], site: "src/ui.tsx:57:20" }, "src/ui.tsx:57:20");
  var selectMap = __mtx.fn("Mtx_F_ui_selectMap", { code: ['Void Mtx_F_ui_selectMap(Text _uid) {\n  if (_uid != "" && ', ' != "") {\n    TriggerPageAction(', ' ^ "-" ^ _uid);\n  }\n}'], holes: [{ kind: "shared", get: () => pickAction }, { kind: "shared", get: () => pickAction }], structs: [], site: "src/ui.tsx:58:19" });
  var flashTimer = __mtx.fn("Mtx_F_ui_flashTimer", { code: ["Text Mtx_F_ui_flashTimer(Integer _seconds) {\n  declare Text secondsText = ", '::ToText(_seconds % 60);\n  if (_seconds % 60 < 10) {\n    secondsText = "0" ^ secondsText;\n  }\n  return ', '::ToText(_seconds / 60) ^ ":" ^ secondsText;\n}'], holes: [{ kind: "lib", lib: "TextLib" }, { kind: "lib", lib: "TextLib" }], structs: [], site: "src/ui.tsx:62:20" });
  var clickRow = __mtx.fn("Mtx_F_ui_clickRow", { code: ['Void Mtx_F_ui_clickRow(CMlScriptEvent _event) {\n  declare CMlFrame row <=> (_event.Control.Parent as CMlFrame);\n  declare Text uid = row.DataAttributeGet("uid");\n  ', "(uid);\n}"], holes: [{ kind: "fn", get: () => selectMap }], structs: [], site: "src/ui.tsx:67:18" });
  var setRowHighlighted = __mtx.fn("Mtx_F_ui_setRowHighlighted", { code: ["Void Mtx_F_ui_setRowHighlighted(Integer _index, Boolean _highlighted, Text _contentColor) {\n  if (_index < 0 || _index >= ", ".Controls.count - 1) {\n    return;\n  }\n  declare CMlFrame row <=> (", '.Controls[_index + 1] as CMlFrame);\n  declare Text color = _contentColor;\n  if (_highlighted) {\n    color = "999";\n  }\n  (row.Controls[1] as CMlQuad).BgColor = ', "::Hex3ToRgb(color);\n}"], holes: [{ kind: "ref", get: () => mapFrame }, { kind: "ref", get: () => mapFrame }, { kind: "lib", lib: "ColorLib" }], structs: [], site: "src/ui.tsx:72:27" });
  var clampMapIndex = __mtx.fn("Mtx_F_ui_clampMapIndex", { code: ["Integer Mtx_F_ui_clampMapIndex(Integer _target) {\n  if (", ".count == 0) {\n    return -1;\n  }\n  if (_target < 0) {\n    return 0;\n  }\n  if (_target >= ", ".count) {\n    return ", ".count - 1;\n  }\n  return _target;\n}"], holes: [{ kind: "shared", get: () => maps }, { kind: "shared", get: () => maps }, { kind: "shared", get: () => maps }], structs: ["#Struct K_MapInfo {\n  Text name;\n  Text author;\n  Text uid;\n  Integer index;\n  Text[] selectedBy;\n  Text pickedBy;\n  Text bannedBy;\n}"], site: "src/ui.tsx:81:23" });
  var scrollToRow = __mtx.fn("Mtx_F_ui_scrollToRow", { code: ["Void Mtx_F_ui_scrollToRow(Integer _index) {\n  declare CMlFrame frame <=> ", ";\n  declare Real rowTop = ", "::ToReal(_index) * 11.5;\n  declare Real rowBottom = rowTop + 11.5;\n  declare Real viewTop = frame.ScrollOffset.Y;\n  declare Real viewBottom = viewTop + 115.;\n  if (rowTop < viewTop) {\n    frame.ScrollOffset = <0., rowTop>;\n  } else if (rowBottom > viewBottom) {\n    frame.ScrollOffset = <0., rowBottom - 115.>;\n  }\n}"], holes: [{ kind: "ref", get: () => mapFrame }, { kind: "lib", lib: "MathLib" }], structs: [], site: "src/ui.tsx:87:21" });
  var moveSelection = __mtx.fn("Mtx_F_ui_moveSelection", { code: ["Void Mtx_F_ui_moveSelection(Integer _delta, Text _contentColor) {\n  declare Integer target = ", ";\n  if (", ") {\n    target = target + _delta;\n  }\n  declare Integer next = ", "(target);\n  if (", " != next) {\n    ", "(", ", False, _contentColor);\n  }\n  ", " = next;\n  Mtx_Dirty = True;\n  ", "(next, True, _contentColor);\n  ", "(next);\n  ", " = True;\n  Mtx_Dirty = True;\n}"], holes: [{ kind: "state", get: () => selectedMapIndex }, { kind: "state", get: () => selectionVisible }, { kind: "fn", get: () => clampMapIndex }, { kind: "state", get: () => selectedMapIndex }, { kind: "fn", get: () => setRowHighlighted }, { kind: "state", get: () => selectedMapIndex }, { kind: "state", get: () => selectedMapIndex }, { kind: "fn", get: () => setRowHighlighted }, { kind: "fn", get: () => scrollToRow }, { kind: "state", get: () => selectionVisible }], structs: [], site: "src/ui.tsx:97:23" });
  var triggerSelectedMap = __mtx.fn("Mtx_F_ui_triggerSelectedMap", { code: ["Void Mtx_F_ui_triggerSelectedMap() {\n  if (!", " || ", ".count == 0 || ", " < 0) {\n    return;\n  }\n  declare CMlFrame row <=> (", ".Controls[", ' + 1] as CMlFrame);\n  declare Text uid = row.DataAttributeGet("uid");\n  ', "(uid);\n}"], holes: [{ kind: "state", get: () => selectionVisible }, { kind: "shared", get: () => maps }, { kind: "state", get: () => selectedMapIndex }, { kind: "ref", get: () => mapFrame }, { kind: "state", get: () => selectedMapIndex }, { kind: "fn", get: () => selectMap }], structs: [], site: "src/ui.tsx:110:28" });
  var mapUpdate = __mtx.fn("Mtx_F_ui_mapUpdate", { code: ["Void Mtx_F_ui_mapUpdate(Text _contentColor) {\n  declare CMlFrame frame <=> ", ";\n  declare Integer index = 0;\n  foreach (map in ", ') {\n    if (index >= 100) {\n      break;\n    }\n    declare CMlFrame row <=> (frame.Controls[index + 1] as CMlFrame);\n    declare CMlLabel number <=> (row.Controls[2] as CMlLabel);\n    declare CMlLabel status <=> (row.Controls[5] as CMlLabel);\n    declare Text oldPickedBy = row.DataAttributeGet("pickedBy");\n    (row.Controls[3] as CMlLabel).SetText(map.name);\n    (row.Controls[4] as CMlLabel).SetText(map.author);\n    row.DataAttributeSet("uid", map.uid);\n    row.DataAttributeSet("pickedBy", map.pickedBy);\n    row.DataAttributeSet("bannedBy", map.bannedBy);\n    row.DataAttributeSet("position", ', '::ToText(map.index));\n    if (map.bannedBy != "") {\n      number.SetText("");\n      status.SetText("Banned by " ^ map.bannedBy);\n      (row.Controls[1] as CMlQuad).Opacity = 0.7;\n    } else if (map.pickedBy != "") {\n      number.SetText(', `::ToText(map.index));
      declare Text Mtx_T0;
      if (map.pickedBy == "random") {
        Mtx_T0 = "Random";
      } else {
        Mtx_T0 = "Picked by " ^ map.pickedBy;
      }
      status.SetText(Mtx_T0);
      if (oldPickedBy != map.pickedBy && AnimMgr != Null) {
        AnimMgr.Add(row, "<frame pos='15 " ^ `, `::ToText(row.RelativePosition_V3.Y) ^ "' />", 600, CAnimManager::EAnimManagerEasing::ExpInOut);
      }
    } else {
      number.SetText("");
      declare Text Mtx_T1;
      if (map.selectedBy.count == 0) {
        Mtx_T1 = "";
      } else {
        Mtx_T1 = "" ^ `, "::ToText(map.selectedBy.count);\n      }\n      status.SetText(Mtx_T1);\n    }\n    row.Show();\n    index = index + 1;\n  }\n  while (index < 100) {\n    (frame.Controls[index + 1] as CMlFrame).Hide();\n    index = index + 1;\n  }\n  declare Integer oldSelection = ", ";\n  ", " = ", "(", ");\n  Mtx_Dirty = True;\n  if (", ") {\n    if (oldSelection != ", ") {\n      ", "(oldSelection, False, _contentColor);\n    }\n    ", "(", ", True, _contentColor);\n    ", "(", ");\n  }\n  declare Integer count = ", ".count;\n  if (count > 100) {\n    count = 100;\n  }\n  declare Real maxY = ", "::ToReal(count) * 11.5 - 115.;\n  if (maxY < 0.) {\n    maxY = 0.;\n  }\n  frame.ScrollMax = <0., maxY>;\n  if (", '.action == "done" && ', " < 0) {\n    ", " = GameTime;\n    Mtx_Dirty = True;\n    ", " = False;\n    Mtx_Dirty = True;\n  } else if (", '.action != "done") {\n    ', " = -1;\n    Mtx_Dirty = True;\n    ", " = False;\n    Mtx_Dirty = True;\n  }\n  declare CMlLabel label <=> (", ".Controls[2] as CMlLabel);\n  if (", '.action == "pick") {\n    label.SetText(', '.nickName ^ "$z is picking a map");\n  } else if (', '.action == "ban") {\n    label.SetText(', '.nickName ^ "$z is banning a map");\n  } else if (', '.action == "random") {\n    label.SetText("Random map is being picked");\n  } else {\n    label.SetText("Pick and ban completed");\n  }\n  ', " = GameTime;\n  Mtx_Dirty = True;\n  ", " = ", ".timeoutSeconds;\n  Mtx_Dirty = True;\n  declare CMlLabel timer <=> (", ".Controls[3] as CMlLabel);\n  declare Text Mtx_T2;\n  if (", ".timeoutSeconds > 0) {\n    Mtx_T2 = ", "(", '.timeoutSeconds);\n  } else {\n    Mtx_T2 = "";\n  }\n  timer.SetText(Mtx_T2);\n  declare CMlQuad progress <=> (', ".Controls[4] as CMlQuad);\n  if (", `.timeoutSeconds > 0) {
    progress.Size = <120., 1.>;
    progress.Opacity = 0.9;
    if (AnimMgr != Null) {
      AnimMgr.Add(progress, "<quad size='0 1' />", `, ".timeoutSeconds * 1000, CAnimManager::EAnimManagerEasing::Linear);\n    }\n  } else {\n    progress.Opacity = 0.;\n  }\n}"], holes: [{ kind: "ref", get: () => mapFrame }, { kind: "shared", get: () => maps }, { kind: "lib", lib: "TextLib" }, { kind: "lib", lib: "TextLib" }, { kind: "lib", lib: "TextLib" }, { kind: "lib", lib: "TextLib" }, { kind: "state", get: () => selectedMapIndex }, { kind: "state", get: () => selectedMapIndex }, { kind: "fn", get: () => clampMapIndex }, { kind: "state", get: () => selectedMapIndex }, { kind: "state", get: () => selectionVisible }, { kind: "state", get: () => selectedMapIndex }, { kind: "fn", get: () => setRowHighlighted }, { kind: "fn", get: () => setRowHighlighted }, { kind: "state", get: () => selectedMapIndex }, { kind: "fn", get: () => scrollToRow }, { kind: "state", get: () => selectedMapIndex }, { kind: "shared", get: () => maps }, { kind: "lib", lib: "MathLib" }, { kind: "shared", get: () => turn }, { kind: "state", get: () => completedAt }, { kind: "state", get: () => completedAt }, { kind: "state", get: () => completionAnimated }, { kind: "shared", get: () => turn }, { kind: "state", get: () => completedAt }, { kind: "state", get: () => completionAnimated }, { kind: "ref", get: () => actionFrame }, { kind: "shared", get: () => turn }, { kind: "shared", get: () => turn }, { kind: "shared", get: () => turn }, { kind: "shared", get: () => turn }, { kind: "shared", get: () => turn }, { kind: "state", get: () => timerStart }, { kind: "state", get: () => lastSecond }, { kind: "shared", get: () => turn }, { kind: "ref", get: () => actionFrame }, { kind: "shared", get: () => turn }, { kind: "fn", get: () => flashTimer }, { kind: "shared", get: () => turn }, { kind: "ref", get: () => actionFrame }, { kind: "shared", get: () => turn }, { kind: "shared", get: () => turn }], structs: ["#Struct K_Turn {\n  Text action;\n  Text login;\n  Text[] players;\n  Text nickName;\n  Integer timeoutSeconds;\n}"], site: "src/ui.tsx:121:19" });
  function Behavior({ contentColor }) {
    __mtx.onInit({ code: ["", ".ScrollActive = True;\n", ".ScrollMin = <0., 0.>;\n", ".ScrollGrid = <0., 11.5>;"], holes: [{ kind: "ref", get: () => mapFrame }, { kind: "ref", get: () => mapFrame }, { kind: "ref", get: () => mapFrame }], structs: [], site: "src/ui.tsx:217:3" });
    __mtx.watch(maps, { code: ["", "(", ");"], holes: [{ kind: "fn", get: () => mapUpdate }, { kind: "value", type: "Text", get: () => contentColor }], structs: [], site: "src/ui.tsx:222:3" });
    __mtx.watch(turn, { code: ["", "(", ");"], holes: [{ kind: "fn", get: () => mapUpdate }, { kind: "value", type: "Text", get: () => contentColor }], structs: [], site: "src/ui.tsx:225:3" });
    __mtx.onFrame({ code: ["{\n  if (", ".timeoutSeconds > 0) {\n    declare Integer seconds = ", ".timeoutSeconds - (GameTime - ", ") / 1000;\n    if (seconds < 0) {\n      seconds = 0;\n    }\n    if (seconds != ", ") {\n      ", " = seconds;\n      Mtx_Dirty = True;\n      declare Text Mtx_T0;\n      if (seconds > 0) {\n        Mtx_T0 = ", '(seconds);\n      } else {\n        Mtx_T0 = "";\n      }\n      (', ".Controls[3] as CMlLabel).SetText(Mtx_T0);\n    }\n  }\n  if (", '.action == "done" && ', " >= 0 && !", " && GameTime - ", " >= 5000) {\n    ", " = True;\n    Mtx_Dirty = True;\n    declare Integer pickedCount = 0;\n    declare Integer index = 0;\n    while (index < 100) {\n      declare CMlFrame row <=> (", `.Controls[index + 1] as CMlFrame);
      if (row.DataAttributeGet("uid") != "") {
        if (row.DataAttributeGet("pickedBy") == "") {
          if (AnimMgr != Null) {
            AnimMgr.Add(row, "<frame pos='-120 " ^ `, `::ToText(row.RelativePosition_V3.Y) ^ "' />", 600, CAnimManager::EAnimManagerEasing::ExpInOut);
          }
        } else {
          pickedCount = pickedCount + 1;
          declare Integer position = `, '::ToInteger(row.DataAttributeGet("position"));\n          declare Real y = -5. - ', `::ToReal(position - 1) * 11.5;
          if (AnimMgr != Null) {
            AnimMgr.Add(row, "<frame pos='10 " ^ `, `::ToText(y) ^ "' />", 600, CAnimManager::EAnimManagerEasing::ExpInOut);
          }
        }
      }
      index = index + 1;
    }
    declare Real maxY = `, "::ToReal(pickedCount) * 11.5 - 115.;\n    if (maxY < 0.) {\n      maxY = 0.;\n    }\n    ", ".ScrollMax = <0., maxY>;\n    declare Real backgroundY = 1150. - ", "::ToReal(pickedCount) * 11.5;\n    if (AnimMgr != Null) {\n      AnimMgr.Add((", `.Controls[0] as CMlQuad), "<quad pos='0 " ^ `, `::ToText(backgroundY) ^ "' />", 600, CAnimManager::EAnimManagerEasing::ExpInOut);
    }
  }
  if (Input != Null) {
    foreach (padEvent in Input.PendingEvents) {
      if (padEvent == Null) {
        continue;
      }
      if (padEvent.Type != CInputEvent::EType::PadButtonPress || padEvent.IsAutoRepeat) {
        continue;
      }
      if (padEvent.Button == CInputEvent::EButton::Up || padEvent.Button == CInputEvent::EButton::LeftStick_Up) {
        `, "(-1, ", ");\n      } else if (padEvent.Button == CInputEvent::EButton::Down || padEvent.Button == CInputEvent::EButton::LeftStick_Down) {\n        ", "(1, ", ");\n      } else if (padEvent.Button == CInputEvent::EButton::A) {\n        ", "();\n      }\n    }\n  }\n}"], holes: [{ kind: "shared", get: () => turn }, { kind: "shared", get: () => turn }, { kind: "state", get: () => timerStart }, { kind: "state", get: () => lastSecond }, { kind: "state", get: () => lastSecond }, { kind: "fn", get: () => flashTimer }, { kind: "ref", get: () => actionFrame }, { kind: "shared", get: () => turn }, { kind: "state", get: () => completedAt }, { kind: "state", get: () => completionAnimated }, { kind: "state", get: () => completedAt }, { kind: "state", get: () => completionAnimated }, { kind: "ref", get: () => mapFrame }, { kind: "lib", lib: "TextLib" }, { kind: "lib", lib: "TextLib" }, { kind: "lib", lib: "MathLib" }, { kind: "lib", lib: "TextLib" }, { kind: "lib", lib: "MathLib" }, { kind: "ref", get: () => mapFrame }, { kind: "lib", lib: "MathLib" }, { kind: "ref", get: () => mapFrame }, { kind: "lib", lib: "TextLib" }, { kind: "fn", get: () => moveSelection }, { kind: "value", type: "Text", get: () => contentColor }, { kind: "fn", get: () => moveSelection }, { kind: "value", type: "Text", get: () => contentColor }, { kind: "fn", get: () => triggerSelectedMap }], structs: [], site: "src/ui.tsx:228:3" });
    return null;
  }
  function BigNumber(props) {
    const { color } = kit.useTokens();
    return /* @__PURE__ */ jsx(
      "label",
      {
        pos: [5, -4.5],
        size: [10, 10],
        text: props.text,
        halign: "center",
        valign: "center",
        textsize: 3,
        textcolor: color.text,
        textfont: "GameFontBlack"
      }
    );
  }
  function MatchWidget(props) {
    const tokens = kit.useTokens();
    const data = props.data ?? {};
    const backgroundY = 1159 - (data.maps?.length ?? 0) * 11.5 - 9;
    return /* @__PURE__ */ jsxs(WidgetFrame, { ...props, children: [
      /* @__PURE__ */ jsx(Behavior, { contentColor: tokens.color.content }),
      /* @__PURE__ */ jsxs("frame", { id: "pickban-action", ref: actionFrame, size: [120, 10], children: [
        /* @__PURE__ */ jsx(Panel, { tone: "surface", size: [120, 10] }),
        /* @__PURE__ */ jsx(
          Label,
          {
            tone: "text",
            font: "body",
            pos: [5, -4.75],
            size: [10, 10],
            text: "",
            halign: "center",
            valign: "center",
            textsize: 2.5
          }
        ),
        /* @__PURE__ */ jsx(
          Label,
          {
            tone: "text",
            font: "title",
            pos: [12, -4.75],
            size: [94, 5],
            text: "Marijn. is picking a map",
            valign: "center",
            textsize: 1.75
          }
        ),
        /* @__PURE__ */ jsx(
          Label,
          {
            tone: "text",
            font: "title",
            pos: [115, -4.75],
            size: [10, 5],
            text: "",
            halign: "right",
            valign: "center",
            textsize: 1.75
          }
        ),
        /* @__PURE__ */ jsx(Panel, { tone: "content", pos: [0, -9], size: [120, 1], opacity: 0 })
      ] }),
      /* @__PURE__ */ jsxs("framemodel", { id: "map-info", children: [
        /* @__PURE__ */ jsx(Panel, { tone: "surface", size: [10, 10] }),
        /* @__PURE__ */ jsx(Panel, { tone: "content", pos: [10, 0], size: [90, 10] }),
        /* @__PURE__ */ jsx(BigNumber, { text: "" }),
        /* @__PURE__ */ jsx(
          Label,
          {
            tone: "contentText",
            font: "title",
            pos: [12, -5.25],
            size: [41, 5],
            text: "-",
            textsize: 1.75,
            valign: "bottom"
          }
        ),
        /* @__PURE__ */ jsx(
          Label,
          {
            tone: "contentText",
            font: "body",
            pos: [11.75, -5.5],
            size: [41, 5],
            text: "-",
            textprefix: "$i",
            valign: "top",
            textsize: 1
          }
        ),
        /* @__PURE__ */ jsx(
          Label,
          {
            tone: "contentText",
            font: "title",
            pos: [95, -4.75],
            size: [41, 5],
            text: "",
            textsize: 1.75,
            valign: "center",
            halign: "right"
          }
        ),
        /* @__PURE__ */ jsx(
          "quad",
          {
            class: "trigger",
            pos: [0, 0],
            size: [100, 10],
            bgcolor: tokens.color.surface,
            opacity: 0,
            scriptevents: true,
            onClick: __mtx.handler({ code: ["", "(Event);"], holes: [{ kind: "fn", get: () => clickRow }], structs: [], site: "src/ui.tsx:414:20" })
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("frame", { id: "maps", ref: mapFrame, pos: [0, -10], size: [120, 124], children: [
        /* @__PURE__ */ jsx(
          Panel,
          {
            tone: "surface",
            pos: [0, backgroundY],
            size: [120, 1159],
            opacity: 0.75,
            scriptevents: true
          }
        ),
        Array.from({ length: 100 }, (_, index) => /* @__PURE__ */ jsx("frameinstance", { modelid: "map-info", pos: [5, -5 - index * 11.5] }))
      ] })
    ] });
  }
  function MatchWidgetUpdate(props) {
    const data = props.data ?? {};
    return /* @__PURE__ */ jsxs(Manialink, { id: props.id, children: [
      /* @__PURE__ */ jsx(Publish, { to: maps, value: data.maps ?? [] }),
      /* @__PURE__ */ jsx(Publish, { to: pickAction, value: data.pickAction ?? "" }),
      /* @__PURE__ */ jsx(
        Publish,
        {
          to: turn,
          value: data.currentAction ?? {
            action: "done",
            login: "",
            players: [],
            nickName: "",
            timeoutSeconds: 0
          }
        }
      )
    ] });
  }
  function ChoosePositionWindow(props) {
    const data = props.data ?? { choosePositionAction: "" };
    return /* @__PURE__ */ jsx(Manialink, { id: props.id, children: /* @__PURE__ */ jsx(
      WindowFrame,
      {
        id: props.id,
        title: props.title,
        size: [props.size.x, props.size.y],
        children: /* @__PURE__ */ jsx(
          "frame",
          {
            id: "choose-position-window",
            pos: [2, -2],
            size: [
              (data.positionsAvailable?.length ?? 0) * 12 - 2,
              props.size.y - 4
            ],
            children: (data.positionsAvailable ?? []).map((position, index) => /* @__PURE__ */ jsxs("frame", { pos: [index * 12, 0], size: [10, 10], children: [
              /* @__PURE__ */ jsx(Panel, { tone: "surface", size: [10, 10] }),
              /* @__PURE__ */ jsx(BigNumber, { text: String(position) }),
              /* @__PURE__ */ jsx(
                Panel,
                {
                  tone: "surface",
                  pos: [0, 0],
                  size: [10, 10],
                  opacity: 0,
                  action: `${data.choosePositionAction}-${position}`
                }
              )
            ] }))
          }
        )
      }
    ) });
  }

  // plugins/match/src/config.ts
  var DEFAULT_AUTO_START_DELAY = 30;
  function normalizeConfig(raw2) {
    const config = raw2 && typeof raw2 === "object" ? raw2 : {};
    const pickAndBan = config.pickAndBan;
    if (!pickAndBan) return config;
    const timeout = Number(pickAndBan.timeout);
    const autoStartDelay = Number(pickAndBan.autoStartDelay);
    return {
      ...config,
      pickAndBan: {
        ...pickAndBan,
        order: pickAndBan.order ?? "",
        choosePosition: pickAndBan.choosePosition ?? false,
        timeout: Number.isFinite(timeout) && timeout > 0 ? timeout : void 0,
        autoStart: pickAndBan.autoStart ?? false,
        autoStartDelay: Number.isFinite(autoStartDelay) && autoStartDelay > 0 ? autoStartDelay : DEFAULT_AUTO_START_DELAY
      }
    };
  }

  // plugins/match/src/index.tsx
  function errorMessage(error) {
    return error instanceof Error ? error.message : String(error);
  }
  var PICKBAN_DONE_DELAY_MS = 1e4;
  var RANDOM_STEP_DELAY_MS = 1e3;
  var DEFAULT_AUTO_START_DELAY2 = 30;
  var eventMap = ({ uid, name, filename }) => ({
    uid,
    name,
    filename
  });
  function capitalize(text) {
    return text.charAt(0).toUpperCase() + text.slice(1);
  }
  var MatchPlugin = class {
    constructor(ctx) {
      this.ctx = ctx;
      this.maps = new MapList(ctx);
      this.widget = ctx.ui.widget({
        id: "match-pickban-widget",
        component: MatchWidget,
        updateComponent: MatchWidgetUpdate,
        position: { x: -60, y: 67 }
      });
      ctx.command("matchstart", (_, login) => this.onMatchStart(login));
      ctx.command("matchstop", (_, login) => this.onMatchStop(login));
      ctx.command("pause", (_, login) => this.onPause(login, true));
      ctx.command("unpause", (_, login) => this.onPause(login, false));
      ctx.command("pickban", (_, login) => this.onPickBanStart(login));
      ctx.command("lobby", (_, login) => this.onLobby(login));
      ctx.command("setseeds", (args, login) => this.onSetSeeds(args, login));
      ctx.action(
        "match-pickban-action-{uid}",
        (answer, params) => this.onMapSelected(answer, params.uid)
      );
      ctx.action(
        "match-pickban-choose-position-{position}",
        (answer, params) => this.onPositionChosen(answer, parseInt(params.position, 10))
      );
    }
    widget;
    positionWindows = /* @__PURE__ */ new Map();
    state = "not_started";
    pickBan = null;
    seedsOverride = [];
    cancelTurnTimeout = null;
    cancelAutoStart = null;
    maps;
    stop() {
      this.clearTurnTimeout();
      this.clearAutoStart();
    }
    get matchState() {
      return this.state;
    }
    config() {
      return normalizeConfig(this.ctx.config());
    }
    // Older panels have no ctx.emit; the match still runs there
    emit(name, payload) {
      this.ctx.emit?.(name, payload);
    }
    emitTurn() {
      const turn2 = this.pickBan?.currentTurn;
      if (!turn2) return;
      this.emit("pickBanTurn", {
        action: turn2.action,
        login: turn2.login,
        players: turn2.players,
        nickName: turn2.nickName,
        timeoutSeconds: turn2.timeoutSeconds ?? null
      });
    }
    // The map and who took it; picks carry their final position
    emitSelection(action2, map, by, timedOut = false) {
      this.emit(action2 === "pick" ? "pickBanMapPicked" : "pickBanMapBanned", {
        map: eventMap(map),
        by,
        ...action2 === "pick" ? { position: map.index } : {},
        timedOut
      });
    }
    // An empty login (automatic start) reports to everyone
    tell(login, message) {
      return login ? this.ctx.chat.sendTo(login, message) : this.ctx.chat.send(message);
    }
    authorize(login, message) {
      if (this.config().admins?.includes(login)) return true;
      void this.tell(
        login,
        message || "You are not authorized to perform this action"
      );
      return false;
    }
    // Runs a step and reports failures to the admin instead of throwing
    async attempt(login, label, step) {
      try {
        await step();
        return true;
      } catch (error) {
        this.ctx.log.error(label, { error: errorMessage(error) });
        await this.tell(login, `${label}: ${errorMessage(error)}`);
        return false;
      }
    }
    async onMatchStart(login) {
      if (!this.authorize(login, "You are not authorized to start the match"))
        return;
      await this.startMatch(login);
    }
    async startMatch(login) {
      this.clearAutoStart();
      if (this.state === "pickban") {
        return this.tell(
          login,
          "Pick and ban phase is still in progress, cannot start the match"
        );
      }
      if (this.state === "in_progress") {
        return this.tell(
          login,
          "Match has already started, cannot start the match"
        );
      }
      const config = this.config();
      if (config?.script) {
        const ok = await this.attempt(
          login,
          "Failed to load match script",
          async () => {
            await this.ctx.server.setScriptName(config.script);
            await this.ctx.chat.send(`Loaded match script: ${config.script}`);
          }
        );
        if (!ok) return;
      }
      if (this.state === "not_started" && config?.maps?.length) {
        const ok = await this.attempt(
          login,
          "Failed to set map list",
          () => this.maps.replace(config.maps)
        );
        if (!ok) return;
      }
      if (this.state === "ready") {
        const picked = this.pickBan?.pickedFileNames() ?? [];
        if (picked.length === 0) {
          return this.tell(
            login,
            "No maps have been picked, cannot start the match"
          );
        }
        const ok = await this.attempt(
          login,
          "Failed to set map list",
          () => this.maps.replace(picked)
        );
        if (!ok) return;
      }
      if (await this.goToFirstMap(login, "Failed to start the match")) {
        this.state = "in_progress";
        this.emit("started", { script: config?.script ?? null });
      }
      await this.attempt(login, "Failed to fetch map list", async () => {
        const maps2 = await this.maps.getAll();
        await this.ctx.chat.send(
          `Maps:
${maps2.map((map, index) => `$z${index + 1}. ${map.Name}`).join("\n")}`
        );
      });
    }
    async onMatchStop(login) {
      if (!this.authorize(login, "You are not authorized to stop the match"))
        return;
      this.widget.destroy();
      this.clearTurnTimeout();
      this.clearAutoStart();
      this.state = "not_started";
      this.emit("stopped");
      await this.ctx.chat.send("Match stopped");
      await this.applyLobby(login);
    }
    async onPause(login, pause) {
      const verb = pause ? "pause" : "unpause";
      if (!this.authorize(login, `You are not authorized to ${verb} the match`))
        return;
      const { liveInfo } = this.ctx.live;
      if (!liveInfo.pauseAvailable) {
        return this.tell(login, "Pausing is not available in this mode");
      }
      if (pause && liveInfo.isPaused)
        return this.tell(login, "Match is already paused");
      if (!pause && !liveInfo.isPaused)
        return this.tell(login, "Match is not paused");
      await this.attempt(login, `Failed to ${verb} the match`, async () => {
        const player = this.ctx.live.findActivePlayer(login);
        await this.ctx.server.setPaused(pause);
        this.emit("pauseChanged", { paused: pause, login });
        await this.ctx.chat.send(
          `Match ${pause ? "paused" : "unpaused"} by ${player?.nickName || login}`
        );
      });
    }
    async onPickBanStart(login) {
      if (!this.authorize(
        login,
        "You are not authorized to start the pick and ban phase"
      ))
        return;
      if (this.state === "pickban") {
        return this.tell(login, "Pick and ban phase is already in progress");
      }
      if (this.state !== "not_started") {
        return this.tell(
          login,
          "Match has already started, cannot start pick and ban phase"
        );
      }
      const config = this.config().pickAndBan;
      if (!config?.type)
        return this.tell(login, "Pick and ban configuration is not set");
      const order = applySeedsOverride(
        stringToPickAndBan(config.order),
        this.seedsOverride
      );
      this.pickBan = new PickBan(
        {
          mode: config.type,
          order,
          choosePosition: config.choosePosition,
          players: config.players ?? [],
          teams: config.teams ?? [],
          maps: await this.loadMaps(this.config().maps ?? [])
        },
        (l) => this.ctx.live.findActivePlayer(l)?.nickName
      );
      this.state = "pickban";
      this.startTurnTimer();
      this.renderPickBan(true);
      this.emit("pickBanStarted", {
        mode: config.type,
        order,
        maps: this.pickBan.maps.map(eventMap)
      });
      this.emitTurn();
      await this.ctx.chat.send(
        `Pick and ban phase started
${order.map(
          (step) => step.action !== "random" ? `${step.seed}: ${capitalize(step.action)}` : "Random"
        ).join("\n")}`
      );
      await this.runAutomaticSteps();
    }
    async onLobby(login) {
      if (!this.authorize(login, "You are not authorized to execute this command"))
        return;
      if (this.state !== "not_started") {
        return this.tell(login, "Match has already started, cannot go to lobby");
      }
      const lobby = this.config().lobby;
      if (!lobby || !lobby.map && !lobby.script) {
        return this.tell(login, "Lobby configuration is not set");
      }
      await this.applyLobby(login);
    }
    async onSetSeeds(args, login) {
      const seeds = args.map((arg) => parseInt(arg, 10));
      if (seeds.some((seed) => isNaN(seed))) {
        return this.tell(
          login,
          "Invalid seed(s) provided, please provide valid numbers"
        );
      }
      this.seedsOverride = seeds;
      await this.tell(
        login,
        seeds.length === 0 ? "Seeds for pick and ban order have been cleared" : `Seeds for pick and ban order have been set to: ${seeds.join(", ")}`
      );
    }
    async onMapSelected(answer, uid) {
      const pickBan = this.pickBan;
      if (!uid || !pickBan) return;
      const activeLogins = this.ctx.live.activePlayers.map((p) => p.login);
      const turn2 = pickBan.currentTurn;
      const result = pickBan.select(answer.login, uid, activeLogins);
      switch (result.kind) {
        case "noTurn":
          return this.tell(
            answer.login,
            "No pick and ban action is currently active"
          );
        case "mapNotFound":
          return this.tell(answer.login, "Selected map not found");
        case "notYourTurn":
        case "mapUnavailable":
          return;
        case "voteRegistered":
          return this.renderPickBan();
        case "choosePosition":
          return this.openPositionWindow(answer.login);
        case "applied":
          if (turn2 && turn2.action !== "random") {
            this.emitSelection(turn2.action, result.map, turn2.nickName);
          }
          return this.nextTurn();
      }
    }
    async onPositionChosen(answer, position) {
      const pickBan = this.pickBan;
      const turn2 = pickBan?.currentTurn;
      if (!pickBan || !turn2 || turn2.login !== answer.login || isNaN(position))
        return;
      const map = pickBan.choosePositionFor(position);
      if (!map) return;
      this.emitSelection("pick", map, turn2.nickName);
      this.closePositionWindow(turn2.login);
      await this.nextTurn();
    }
    async nextTurn() {
      const pickBan = this.pickBan;
      if (!pickBan) return;
      pickBan.advance();
      this.startTurnTimer();
      this.renderPickBan();
      this.emitTurn();
      await this.runAutomaticSteps();
    }
    // Plays random steps and finishes the phase once no turns are left
    async runAutomaticSteps() {
      const pickBan = this.pickBan;
      if (!pickBan) return;
      while (!pickBan.isDone && pickBan.currentTurn?.action === "random") {
        await this.ctx.sleep(RANDOM_STEP_DELAY_MS);
        const map = pickBan.pickRandom();
        if (!map) {
          await this.ctx.chat.send(
            "Failed to handle random pick and ban, no available maps left"
          );
          return;
        }
        this.emitSelection("pick", map, "random");
        pickBan.advance();
        this.startTurnTimer();
        this.renderPickBan();
        this.emitTurn();
      }
      if (pickBan.isDone) {
        this.clearTurnTimeout();
        await this.ctx.sleep(PICKBAN_DONE_DELAY_MS);
        if (this.state !== "pickban" || this.pickBan !== pickBan) return;
        this.state = "ready";
        this.emitCompleted(pickBan);
        await this.ctx.chat.send(
          "Pick and ban phase completed, match is ready to start"
        );
        this.widget.destroy();
        this.scheduleAutoStart();
      }
    }
    scheduleAutoStart() {
      const config = this.config().pickAndBan;
      if (!config?.autoStart) return;
      const delay = config.autoStartDelay ?? DEFAULT_AUTO_START_DELAY2;
      void this.ctx.chat.send(`Match starts automatically in ${delay} seconds`);
      this.cancelAutoStart = this.ctx.setTimeout(() => {
        this.cancelAutoStart = null;
        if (this.state === "ready") void this.startMatch("");
      }, delay * 1e3);
    }
    clearAutoStart() {
      this.cancelAutoStart?.();
      this.cancelAutoStart = null;
    }
    // The final result: picked maps in match order, and the bans
    emitCompleted(pickBan) {
      const picked = pickBan.maps.filter((map) => map.pickedBy).sort((a, b) => a.index - b.index).map((map) => ({
        ...eventMap(map),
        position: map.index,
        by: map.pickedBy
      }));
      const banned = pickBan.maps.filter((map) => map.bannedBy).map((map) => ({ ...eventMap(map), by: map.bannedBy }));
      this.emit("pickBanCompleted", { mode: pickBan.mode, picked, banned });
    }
    startTurnTimer() {
      this.clearTurnTimeout();
      const turn2 = this.pickBan?.currentTurn;
      const timeout = this.config().pickAndBan?.timeout;
      if (!turn2 || turn2.action === "random" || !timeout || timeout <= 0) return;
      turn2.timeoutSeconds = timeout;
      this.cancelTurnTimeout = this.ctx.setTimeout(() => {
        this.cancelTurnTimeout = null;
        void this.onTurnTimeout();
      }, timeout * 1e3);
    }
    clearTurnTimeout() {
      this.cancelTurnTimeout?.();
      this.cancelTurnTimeout = null;
    }
    async onTurnTimeout() {
      const pickBan = this.pickBan;
      const turn2 = pickBan?.currentTurn;
      if (!pickBan || !turn2) return;
      if (turn2.login) this.closePositionWindow(turn2.login);
      const map = pickBan.resolveTimeout();
      if (!map) {
        await this.ctx.chat.send(
          "Failed to handle pick/ban timeout, no available maps left"
        );
        return;
      }
      if (turn2.action !== "random")
        this.emitSelection(turn2.action, map, turn2.nickName, true);
      await this.ctx.chat.send(
        `${turn2.nickName || "The current player"} ran out of time, ${map.name} was randomly ${turn2.action === "ban" ? "banned" : "picked"} for them`
      );
      await this.nextTurn();
    }
    renderPickBan(display = false) {
      const pickBan = this.pickBan;
      if (!pickBan) return;
      this.widget.setData({
        maps: pickBan.maps,
        pickAction: this.ctx.ui.action("match-pickban-action").name,
        currentAction: pickBan.currentTurn ? {
          ...pickBan.currentTurn,
          timeoutSeconds: pickBan.currentTurn.timeoutSeconds ?? 0
        } : {
          action: "done",
          login: "",
          players: [],
          nickName: "",
          timeoutSeconds: 0
        }
      });
      if (display) {
        this.widget.display();
      } else {
        this.widget.update();
      }
    }
    openPositionWindow(login) {
      const pickBan = this.pickBan;
      if (!pickBan?.currentTurn || this.positionWindows.has(login)) return;
      const window = this.ctx.ui.window({
        id: "choose-position-window",
        component: ChoosePositionWindow,
        login,
        title: "Choose Position",
        withUpdate: false,
        size: { x: pickBan.positionsAvailable.length * 12 + 2, y: 14 },
        data: {
          currentAction: pickBan.currentTurn,
          positionsAvailable: pickBan.positionsAvailable,
          choosePositionAction: this.ctx.ui.action(
            "match-pickban-choose-position"
          ).name
        },
        onClose: () => this.positionWindows.delete(login)
      });
      this.positionWindows.set(login, window);
      window.display();
    }
    closePositionWindow(login) {
      this.positionWindows.get(login)?.destroy();
      this.positionWindows.delete(login);
    }
    // Prefers map rows from the database; falls back to the server for unknown files
    async loadMaps(fileNames) {
      const fromDb = new Map(
        (await this.ctx.maps.findByFileNames(fileNames)).map((map) => [
          map.fileName,
          map
        ])
      );
      const missing = fileNames.filter((fileName) => !fromDb.has(fileName));
      const fromServer = new Map(
        (missing.length > 0 ? await this.maps.getInfos(missing) : []).map(
          (map) => [map.FileName, map]
        )
      );
      const maps2 = fileNames.flatMap((fileName) => {
        const base = { index: 0, selectedBy: [], pickedBy: "", bannedBy: "" };
        const db = fromDb.get(fileName);
        if (db) {
          return [
            {
              ...base,
              name: db.name,
              author: db.authorNickname || db.author,
              uid: db.uid,
              filename: db.fileName
            }
          ];
        }
        const server = fromServer.get(fileName);
        if (!server) return [];
        return [
          {
            ...base,
            name: server.Name,
            author: server.Author,
            uid: server.UId,
            filename: server.FileName
          }
        ];
      });
      const needName = fileNames.flatMap((fileName) => {
        const db = fromDb.get(fileName);
        const login = db ? db.authorNickname ? "" : db.author : fromServer.get(fileName)?.Author;
        return login ? [login] : [];
      });
      await this.resolveAuthorNames(maps2, needName);
      return maps2;
    }
    // Replaces author logins with Nadeo account names; keeps the login on failure
    async resolveAuthorNames(maps2, logins) {
      const accountIds = /* @__PURE__ */ new Map();
      for (const login of new Set(logins)) {
        const id = loginToAccountId(login);
        if (id) accountIds.set(login, id);
      }
      if (accountIds.size === 0) return;
      try {
        const names = await this.ctx.nadeo.accountNames([...accountIds.values()]);
        for (const map of maps2) {
          const name = names[accountIds.get(map.author) ?? ""];
          if (name) map.author = name;
        }
      } catch (error) {
        this.ctx.log.error("Failed to fetch author names", {
          error: String(error)
        });
      }
    }
    async applyLobby(login) {
      const lobby = this.config().lobby;
      if (lobby?.script) {
        await this.attempt(login, "Failed to load lobby script", async () => {
          await this.ctx.server.setScriptName(lobby.script);
          await this.ctx.chat.send(`Loaded lobby script: ${lobby.script}`);
        });
      }
      if (lobby?.map) {
        await this.attempt(
          login,
          "Failed to set lobby map",
          () => this.maps.replace([lobby.map])
        );
      }
      if (await this.goToFirstMap(login, "Failed to go to lobby")) {
        this.state = "not_started";
      }
    }
    // Jumping to index 0 fails when already on it; a restart has the same effect then
    async goToFirstMap(login, failure) {
      try {
        await this.maps.jumpTo(0);
        return true;
      } catch {
        return this.attempt(login, failure, () => this.maps.restart());
      }
    }
  };
  var index_default = definePlugin({
    create: (ctx) => new MatchPlugin(ctx)
  });
})();
