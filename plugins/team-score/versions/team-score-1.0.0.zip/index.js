"use strict";
(() => {
  // @tmcontrolpanel/plugin-sdk/src/helpers.ts
  function throttle(ctx, fn, ms) {
    let waiting = false;
    let pending = false;
    const run = () => {
      fn();
      waiting = true;
      ctx.setTimeout(() => {
        waiting = false;
        if (pending) {
          pending = false;
          run();
        }
      }, ms);
    };
    return () => {
      if (waiting) pending = true;
      else run();
    };
  }

  // @tmcontrolpanel/plugin-sdk/src/index.ts
  function definePlugin(definition) {
    const register = globalThis.__tmcpRegister;
    if (typeof register === "function") register(definition);
    return definition;
  }

  // plugins/team-score/src/index.ts
  var SIDES = [0, 1];
  var SIDE_NAMES = ["Blue", "Red"];
  function teamDisplayName(gameName, side) {
    const name = (gameName ?? "").trim();
    if (!name || SIDE_NAMES.some((n) => n.toLowerCase() === name.toLowerCase())) {
      return `Team ${SIDE_NAMES[side]}`;
    }
    return name;
  }
  function normalizeColor(color) {
    const hex = (color ?? "").trim().replace(/^#/, "");
    return /^([0-9a-f]{3}|[0-9a-f]{6})$/i.test(hex) ? hex.toUpperCase() : "";
  }
  function roundPoints(finishTeams, repartition, playerCount) {
    const points = [0, 0];
    finishTeams.forEach((team, index) => {
      if (team !== 0 && team !== 1) return;
      const earned = repartition.length ? repartition[Math.min(index, repartition.length - 1)] : Math.max(playerCount - index, 0);
      points[team] += earned || 0;
    });
    return points;
  }
  function projectedTeams(runs) {
    return [...runs].sort((a, b) => {
      const aDone = a.finishedAt >= 0;
      const bDone = b.finishedAt >= 0;
      if (aDone !== bDone) return aDone ? -1 : 1;
      if (aDone) return a.finishedAt - b.finishedAt;
      if (a.checkpoints !== b.checkpoints) return b.checkpoints - a.checkpoints;
      return a.time - b.time;
    }).map((run) => run.team);
  }
  function roundLeader(points) {
    if (points[0] === points[1]) return -1;
    return points[0] > points[1] ? 0 : 1;
  }
  function fixedSide(team) {
    if (team.side === "blue") return 0;
    if (team.side === "red") return 1;
    return null;
  }
  var TeamScorePlugin = class {
    constructor(ctx) {
      this.ctx = ctx;
      this.render = throttle(ctx, () => this.sendState(), 250);
      ctx.on("playerConnect", (player) => void this.assign(player.login, player.teamId));
      ctx.on("playerDisconnect", (login) => this.releaseClaims(login));
      ctx.on("beginMap", () => this.resetRound());
      ctx.on("beginMatch", () => this.syncFromLive());
      ctx.on("startRound", () => this.resetRound());
      ctx.on("checkpoint", (waypoint) => this.onWaypoint(waypoint));
      ctx.on("finish", (waypoint) => this.onWaypoint(waypoint));
      ctx.on("giveUp", (event) => {
        if (this.runs.delete(event.login)) this.updateRound();
      });
      ctx.on("scores", (scores) => this.onScores(scores));
      ctx.on("teamUpdated", (team) => {
        if (team.id !== 0 && team.id !== 1) return;
        this.points[team.id] = team.matchPoints;
        this.names[team.id] = team.name;
        this.render();
      });
      ctx.on("updatedSettings", () => this.render());
      ctx.on("warmUpStart", () => this.render());
      ctx.on("warmUpEnd", () => this.resetRound());
    }
    widget = null;
    // Side claimed by each auto team (index into config.teams) while its players are online
    claims = /* @__PURE__ */ new Map();
    // Live runs of this round by login; players who gave up are removed
    runs = /* @__PURE__ */ new Map();
    finishCount = 0;
    points = [0, 0];
    round = [0, 0];
    names = ["", ""];
    render;
    start() {
      this.syncFromLive();
      this.applyConfig();
    }
    // Re-claims sides first so the widget shows the new teams in the same update
    applyConfig() {
      this.claims.clear();
      for (const player of this.ctx.live.activePlayers) {
        const index = this.teamIndexOf(player.login);
        if (index >= 0) this.sideFor(index);
      }
      if (this.ctx.config().showWidget === false) {
        this.widget?.destroy();
        this.widget = null;
      } else if (!this.widget) {
        this.widget = this.ctx.ui.widget({
          id: "team-score",
          template: "widgets/team-score/team-score",
          position: { x: -57, y: 88 }
        });
        this.widget.setData({ stateJson: JSON.stringify(this.state()) });
        this.widget.display();
      } else {
        this.sendState();
      }
      void this.assignAll();
    }
    customTeams() {
      return this.ctx.config().teams ?? [];
    }
    teamIndexOf(login) {
      return this.customTeams().findIndex((team) => team.players.includes(login));
    }
    // The side a custom team plays on, claiming a free one for auto teams
    sideFor(index) {
      const teams = this.customTeams();
      const fixed = fixedSide(teams[index]);
      if (fixed !== null) return fixed;
      const claimed = this.claims.get(index);
      if (claimed !== void 0) return claimed;
      const taken = new Set(this.claims.values());
      teams.forEach((team) => {
        const side = fixedSide(team);
        if (side !== null) taken.add(side);
      });
      const free = SIDES.find((side) => !taken.has(side));
      if (free === void 0) return null;
      this.claims.set(index, free);
      return free;
    }
    async assign(login, currentTeam) {
      const index = this.teamIndexOf(login);
      if (index < 0) return;
      const side = this.sideFor(index);
      this.render();
      if (side === null) {
        this.ctx.log.warn(`No free side for ${this.customTeams()[index].name}, ${login} stays put`);
        return;
      }
      if (this.ctx.config().autoAssign === false || currentTeam === side) return;
      try {
        await this.ctx.gbx.call("ForcePlayerTeam", login, side);
      } catch (error) {
        this.ctx.log.warn(`Could not move ${login} to team ${side}`, { error: String(error) });
      }
    }
    async assignAll() {
      for (const player of this.ctx.live.activePlayers) {
        await this.assign(player.login, player.teamId);
      }
      this.render();
    }
    // An auto team gives its side back once none of its players are online
    releaseClaims(leaving) {
      const online = new Set(this.ctx.live.activePlayers.map((p) => p.login));
      online.delete(leaving);
      const teams = this.customTeams();
      for (const index of [...this.claims.keys()]) {
        if (!teams[index]?.players.some((login) => online.has(login))) this.claims.delete(index);
      }
      this.render();
    }
    syncFromLive() {
      const teams = this.ctx.live.liveInfo.teams;
      for (const side of SIDES) {
        this.points[side] = teams?.[side]?.matchPoints ?? 0;
        this.names[side] = teams?.[side]?.name ?? "";
      }
      this.resetRound();
    }
    resetRound() {
      this.runs.clear();
      this.finishCount = 0;
      this.round = [0, 0];
      this.render();
    }
    teamOf(login) {
      const live = this.ctx.live;
      return live.findActivePlayer(login)?.teamId ?? live.liveInfo.players[login]?.team ?? -1;
    }
    // Every checkpoint re-projects the round, so the leader follows the race live
    onWaypoint(waypoint) {
      if (this.ctx.live.liveInfo.isWarmUp || waypoint.racetime === 0) return;
      const run = this.runs.get(waypoint.login);
      if (run && run.finishedAt >= 0) return;
      this.runs.set(waypoint.login, {
        team: run?.team ?? this.teamOf(waypoint.login),
        checkpoints: waypoint.checkpointinrace + 1,
        time: waypoint.racetime,
        finishedAt: waypoint.isendrace ? this.finishCount++ : -1
      });
      this.updateRound();
    }
    updateRound() {
      const live = this.ctx.live;
      const racing = live.activePlayers.filter((p) => p.spectatorStatus === 0).length;
      const order = projectedTeams([...this.runs.values()]);
      this.round = roundPoints(order, live.liveInfo.pointsRepartition ?? [], racing);
      this.render();
    }
    onScores(scores) {
      if (!scores.useteams) return;
      for (const team of scores.teams) {
        if (team.id !== 0 && team.id !== 1) continue;
        this.points[team.id] = team.matchpoints;
        this.names[team.id] = team.name;
      }
      if (scores.section === "PreEndRound" || scores.section === "EndRound") {
        const reported = [0, 0];
        for (const team of scores.teams) {
          if (team.id === 0 || team.id === 1) reported[team.id] = team.roundpoints;
        }
        if (reported[0] || reported[1]) this.round = reported;
      }
      this.render();
    }
    customTeamOn(side) {
      const teams = this.customTeams();
      const fixed = teams.find((team) => fixedSide(team) === side);
      if (fixed) return fixed;
      for (const [index, claimed] of this.claims) {
        if (claimed === side && teams[index]) return teams[index];
      }
      return null;
    }
    state() {
      const live = this.ctx.live;
      const view = (side) => {
        const custom = this.customTeamOn(side);
        return {
          name: custom?.name || teamDisplayName(this.names[side], side),
          color: normalizeColor(custom?.color),
          logo: custom?.logo?.trim() ?? "",
          points: this.points[side],
          roundPoints: this.round[side]
        };
      };
      const pointsLimit = live.liveInfo.pointsLimit ?? 0;
      const status = live.liveInfo.isWarmUp ? "Warm up" : [
        live.roundNumber > 0 ? `Round ${live.roundNumber}` : "",
        pointsLimit > 0 ? `Points limit ${pointsLimit}` : ""
      ].filter(Boolean).join(" · ");
      return {
        teams: [view(0), view(1)],
        leader: roundLeader(this.round),
        pointsLimit: Math.max(pointsLimit, 0),
        centerLogo: this.ctx.config().centerLogo?.trim() ?? "",
        status,
        warmUp: live.liveInfo.isWarmUp
      };
    }
    sendState() {
      if (!this.widget) return;
      this.widget.setData({ stateJson: JSON.stringify(this.state()) });
      this.widget.update();
    }
  };
  var index_default = definePlugin({
    create(ctx) {
      const plugin = new TeamScorePlugin(ctx);
      return {
        start: () => plugin.start(),
        onConfigUpdate: () => plugin.applyConfig()
      };
    }
  });
})();
